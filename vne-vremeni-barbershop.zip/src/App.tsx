const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useRef = __vite__cjsImport0_react["useRef"];const _jsxDEV = __vite__cjsImport10_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=4e619415";
import { Star, MapPin, Clock, Phone, Send, Navigation, ChevronRight, ExternalLink, Scissors, Wifi, Coffee, Droplets, Cookie, Gamepad2, ArrowUpRight, ArrowUp, Plus, Minus, Download } from "/node_modules/.vite/deps/lucide-react.js?v=02397d92";
import { BarberPole3D } from "/src/components/BarberPole3D.tsx";
import { LogoVB } from "/src/components/LogoVB.tsx";
import { GalleryModal } from "/src/components/GalleryModal.tsx";
import { AudioPlayer } from "/src/components/AudioPlayer.tsx";
import { RevealOnScroll } from "/src/components/RevealOnScroll.tsx";
import { BarberImage } from "/src/components/BarberImage.tsx";
import { ExportModal } from "/src/components/ExportModal.tsx";
import { CombIcon, StraightRazorIcon, ClipperIcon } from "/src/components/BarberToolsSVG.tsx";
var _jsxFileName = "/app/applet/src/App.tsx";
import __vite__cjsImport10_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4e619415";
// Real Dikidi Booking URLs strictly per instructions
const DIKIDI_GENERAL = "https://dikidi.net/ru/record/2089045?p=0.pi-po-sm-ssm&o=1&m=4475258&source=website&backurl=https%3A%2F%2Fdikidi.net%2Fru%2Fprofile%2Fvne_vremeni_barbershop_2089045";
const DIKIDI_MAKSUD = "https://dikidi.net/ru/record/2089045?p=3.pi-po-sm-ssm&o=1&m=4475258&source=website&backurl=https%3A%2F%2Fdikidi.net%2Fru%2Fprofile%2Fvne_vremeni_barbershop_2089045";
const DIKIDI_SIROZHIDIN = "https://dikidi.net/ru/record/2089045?p=3.pi-po-sm-ssm&o=1&m=4492089&source=website&backurl=https%3A%2F%2Fdikidi.net%2Fru%2Fprofile%2Fvne_vremeni_barbershop_2089045";
const DIKIDI_ZHAMSHID = "https://dikidi.net/2089045?p=3.pi-po-sm-ssm&o=1&m=4666127";
// 2GIS & Contacts
const DGIS_URL = "https://2gis.ru/perm/firm/70000001115643860/tab/reviews";
const TELEGRAM_URL = "https://t.me";
const PHONE_NUMBER = "+7 (996) 575-53-06";
const PHONE_LINK = "tel:+79965755306";
const ALL_WORKS = [
	(
	// Sirozhidin works
	{
		id: "w-s-1",
		src: "/assets/aistudio/IMG_7735_ce6d943f.jpeg",
		title: "Филигранный скин-фейд",
		masterId: "sirozhidin",
		masterName: "Патидинов Сирожидин",
		cropPosition: "center"
	}),
	{
		id: "w-s-2",
		src: "/assets/aistudio/IMG_7612_552d9ae0.jpeg",
		title: "Моделирование бороды и контур",
		masterId: "sirozhidin",
		masterName: "Патидинов Сирожидин",
		cropPosition: "center"
	},
	{
		id: "w-s-3",
		src: "/assets/aistudio/IMG_7610_11c99004.jpeg",
		title: "Детская модельная стрижка ножницами",
		masterId: "sirozhidin",
		masterName: "Патидинов Сирожидин",
		cropPosition: "center"
	},
	(
	// Jamshid works
	{
		id: "w-j-1",
		src: "/assets/aistudio/IMG_7608_cc31f2de.jpeg",
		title: "Классическая мужская стрижка и укладка",
		masterId: "jamshid",
		masterName: "Бахридинов Жамшид",
		cropPosition: "center"
	}),
	{
		id: "w-j-2",
		src: "/assets/aistudio/IMG_7607_774e71ae.jpeg",
		title: "Текстурный кроп",
		masterId: "jamshid",
		masterName: "Бахридинов Жамшид",
		cropPosition: "center 35%"
	},
	(
	// Maksud works
	{
		id: "w-m-1",
		src: "/assets/aistudio/IMG_2003_6a9be5a3.jpeg",
		title: "Фейд и оформление бороды",
		masterId: "maksud",
		masterName: "Бахридинов Максуд",
		cropPosition: "center"
	}),
	{
		id: "w-m-2",
		src: "/assets/aistudio/IMG_2002_9c817200.jpeg",
		title: "Контуринг бороды опасной бритвой",
		masterId: "maksud",
		masterName: "Бахридинов Максуд",
		cropPosition: "center"
	},
	{
		id: "w-m-3",
		src: "/assets/aistudio/IMG_1997_32102296.jpeg",
		title: "Мужской фейд и распаривание",
		masterId: "maksud",
		masterName: "Бахридинов Максуд",
		cropPosition: "center"
	}
];
const SERVICES_DATA = [
	{
		name: "Мужская стрижка + моделирование бороды / бритье",
		duration: "1 ч 20 мин",
		priceJunior: "от 790 ₽",
		priceBarber: "от 1 100 ₽",
		priceBrand: "от 1 400 ₽"
	},
	{
		name: "Отец + сын (ребенок до 10 лет)",
		duration: "1 ч 40 мин",
		priceJunior: "от 790 ₽",
		priceBarber: "от 1 100 ₽",
		priceBrand: "от 1 400 ₽"
	},
	{
		name: "Стрижка ножницами",
		duration: "1 ч 20 мин",
		priceJunior: "от 590 ₽",
		priceBarber: "от 800 ₽",
		priceBrand: "от 1 000 ₽"
	},
	{
		name: "Детская стрижка до 10 лет",
		duration: "40 мин",
		priceJunior: "от 390 ₽",
		priceBarber: "от 600 ₽",
		priceBrand: "от 800 ₽"
	},
	{
		name: "Моделирование бороды / бритье",
		duration: "30 мин",
		priceJunior: "от 290 ₽",
		priceBarber: "от 450 ₽",
		priceBrand: "от 600 ₽"
	},
	{
		name: "Стрижка машинкой (1 насадка)",
		duration: "30 мин",
		priceJunior: "от 290 ₽",
		priceBarber: "от 400 ₽",
		priceBrand: "от 500 ₽"
	}
];
// Real reviews from 2GIS
const REVIEWS_DATA = [
	{
		name: "Дмитрий Смирнов",
		date: "14 октября 2024",
		rating: 5,
		text: "Отличный барбершоп! Был у мастера Сирожидина. Сделал все быстро, аккуратно и именно так, как я просил. Атмосфера классная, чай/кофе предложили. Однозначно рекомендую!"
	},
	{
		name: "Артем Попов",
		date: "28 сентября 2024",
		rating: 5,
		text: "Максуд — настоящий профи! 10 лет опыта сразу видно, фейд сделал филигранно. Приятное место, удобное расположение на Компросе. Теперь стригусь только здесь."
	},
	{
		name: "Илья В.",
		date: "3 сентября 2024",
		rating: 5,
		text: "Приходил с сыном. Жамшид нашел подход к ребенку с первых минут, подстриг спокойно и качественно. Цены абсолютно адекватные за такой уровень сервиса."
	},
	{
		name: "Сергей К.",
		date: "19 августа 2024",
		rating: 5,
		text: "Очень чистый и стильный барбершоп. Мастера внимательные, никакого пафоса, только честная качественная работа. 5 из 5 без сомнений."
	}
];
// 6 Free Amenities (Flat 1px border, 120px height)
const AMENITIES_LIST = [
	{
		title: "Двукратное мытьё головы",
		icon: Droplets
	},
	{
		title: "Кофе",
		icon: Coffee
	},
	{
		title: "Снеки",
		icon: Cookie
	},
	{
		title: "Парковка",
		customP: true
	},
	{
		title: "Wi-Fi",
		icon: Wifi
	},
	{
		title: "PlayStation 5",
		icon: Gamepad2
	}
];
// FAQ items based strictly on 2GIS card and salon specifications
const FAQ_DATA = [
	{
		q: "За сколько времени нужно записываться на стрижку?",
		a: "Запись осуществляется по предварительной договорённости. Рекомендуем записываться заранее через онлайн-запись в Dikidi или по телефону +7 (996) 575-53-06, чтобы выбрать наиболее удобный временной слот и нужного мастера."
	},
	{
		q: "Что входит в стоимость стрижки?",
		a: "В любую стрижку уже включено двукратное мытьё головы профессиональным шампунем, очищение кожи и финальная укладка профессиональным стайлингом. Никаких скрытых доплат за мытьё, сушку или укладочные средства нет."
	},
	{
		q: "Чем отличаются категории мастеров (BRAND, Барбер, Начинающий)?",
		a: "BRAND-барбер Максуд имеет 10 лет профессионального стажа и выполняет стрижки и бороды любой сложности. Барбер Сирожидин — мастер новой школы с подтверждённым рейтингом 5.0 в 2ГИС. Начинающий барбер Жамшид стрижёт по строгим фирменным стандартам под контролем бренда по доступной стоимости."
	},
	{
		q: "Какие удобства предоставляются бесплатно в каждый визит?",
		a: "Для всех гостей бесплатно: чашка кофе или чая, снеки, высокоскоростной Wi-Fi, зона отдыха с консолью PlayStation 5, парковка у входа и двукратное мытьё головы."
	},
	{
		q: "С какого возраста вы стрижёте детей?",
		a: "Мы выполняем детские стрижки до 10 лет, а также предлагаем комплекс «Отец + сын». Мастера находят подход к каждому ребёнку и работают бережно, аккуратно и спокойно."
	},
	{
		q: "Какой у вас график работы и где находится барбершоп?",
		a: "Мы находимся в Перми по адресу Комсомольский проспект, 87 (Свердловский район, перекрёсток с ул. Коминтерна). График работы: Пн–Чт 10:00–22:00, Пт 10:00–13:00 и 15:00–22:00, Сб–Вс 10:00–22:00."
	},
	{
		q: "Можно ли записаться к конкретному мастеру?",
		a: "Да. В блоке «Записаться к специалисту» или прямо в Dikidi вы можете выбрать персональную запись к Максуду, Сирожидину или Жамшиду, либо выбрать общую запись к любому свободному мастеру."
	}
];
export default function App() {
	const [loading, setLoading] = useState(true);
	const [scrollProgress, setScrollProgress] = useState(0);
	const [scrollYPos, setScrollYPos] = useState(0);
	// Header auto-hide state
	const [headerVisible, setHeaderVisible] = useState(true);
	const lastScrollY = useRef(0);
	// Modals & filters
	const [selectedCategory, setSelectedCategory] = useState("junior");
	const [worksFilter, setWorksFilter] = useState("all");
	const [galleryOpen, setGalleryOpen] = useState(false);
	const [galleryImages, setGalleryImages] = useState([]);
	const [galleryIndex, setGalleryIndex] = useState(0);
	const [showStickyBooking, setShowStickyBooking] = useState(false);
	const [openFaq, setOpenFaq] = useState(0);
	const [exportModalOpen, setExportModalOpen] = useState(false);
	// Animated counters
	const [ratingCount, setRatingCount] = useState(0);
	const [litStars, setLitStars] = useState(0);
	const heroRef = useRef(null);
	const contactsRef = useRef(null);
	const aboutRef = useRef(null);
	// Lenis initialization & smooth scroll
	useEffect(() => {
		const win = window;
		let lenisInstance = null;
		if (win.Lenis) {
			lenisInstance = new win.Lenis({
				duration: 1.1,
				easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
				orientation: "vertical",
				smoothWheel: true
			});
			function raf(time) {
				lenisInstance.raf(time);
				requestAnimationFrame(raf);
			}
			requestAnimationFrame(raf);
		}
		const timer = setTimeout(() => {
			setLoading(false);
		}, 900);
		return () => {
			clearTimeout(timer);
			if (lenisInstance) lenisInstance.destroy();
		};
	}, []);
	// Scroll listener
	useEffect(() => {
		let ticking = false;
		const onScroll = () => {
			if (!ticking) {
				window.requestAnimationFrame(() => {
					const totalHeight = document.documentElement.scrollHeight - window.innerHeight;
					const currentScroll = window.scrollY;
					const progress = totalHeight > 0 ? currentScroll / totalHeight * 100 : 0;
					setScrollProgress(progress);
					setScrollYPos(currentScroll);
					// Header hide on scroll down, show on scroll up
					if (currentScroll > 120) {
						if (currentScroll > lastScrollY.current + 6) {
							setHeaderVisible(false);
						} else if (currentScroll < lastScrollY.current - 6) {
							setHeaderVisible(true);
						}
					} else {
						setHeaderVisible(true);
					}
					lastScrollY.current = currentScroll;
					// Sticky booking button visibility
					const hero = heroRef.current;
					const contacts = contactsRef.current;
					if (hero && contacts) {
						const heroBottom = hero.getBoundingClientRect().bottom;
						const contactsTop = contacts.getBoundingClientRect().top;
						const windowHeight = window.innerHeight;
						const afterHero = heroBottom < 0;
						const beforeContacts = contactsTop > windowHeight - 90;
						setShowStickyBooking(afterHero && beforeContacts);
					}
					ticking = false;
				});
				ticking = true;
			}
		};
		window.addEventListener("scroll", onScroll, { passive: true });
		return () => window.removeEventListener("scroll", onScroll);
	}, []);
	// Counting rating & lighting stars in About & Reviews
	useEffect(() => {
		const observer = new IntersectionObserver(([entry]) => {
			if (entry.isIntersecting) {
				let current = 0;
				const interval = setInterval(() => {
					current += .5;
					if (current >= 5) {
						setRatingCount(5);
						clearInterval(interval);
					} else {
						setRatingCount(Number(current.toFixed(1)));
					}
				}, 60);
				for (let i = 1; i <= 5; i++) {
					setTimeout(() => {
						setLitStars(i);
					}, i * 150);
				}
				observer.disconnect();
			}
		}, { threshold: .3 });
		if (aboutRef.current) {
			observer.observe(aboutRef.current);
		}
		return () => observer.disconnect();
	}, []);
	// Filtered works
	const filteredWorks = worksFilter === "all" ? ALL_WORKS : ALL_WORKS.filter((w) => w.masterId === worksFilter);
	const openWorkModal = (item) => {
		const images = filteredWorks.map((w) => ({
			src: w.src,
			title: w.title,
			master: w.masterName
		}));
		const index = filteredWorks.findIndex((w) => w.id === item.id);
		setGalleryImages(images);
		setGalleryIndex(index >= 0 ? index : 0);
		setGalleryOpen(true);
	};
	const openMasterWorkModal = (masterWorks, idx) => {
		const images = masterWorks.map((w) => ({
			src: w.src,
			title: w.title,
			master: w.masterName
		}));
		setGalleryImages(images);
		setGalleryIndex(idx);
		setGalleryOpen(true);
	};
	const scrollToTop = () => {
		window.scrollTo({
			top: 0,
			behavior: "smooth"
		});
	};
	// Price CTA button link & title mapped to active tab
	const priceButtonConfig = {
		brand: {
			text: "Записаться к Максуду",
			url: DIKIDI_MAKSUD
		},
		barber: {
			text: "Записаться к Сирожидину",
			url: DIKIDI_SIROZHIDIN
		},
		junior: {
			text: "Записаться к Жамшиду",
			url: DIKIDI_ZHAMSHID
		}
	}[selectedCategory];
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "relative min-h-screen bg-[#FBF8F4] text-[#111111] overflow-x-hidden",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: `fixed inset-0 z-50 bg-[#111111] flex flex-col items-center justify-center transition-transform duration-800 ease-[cubic-bezier(0.22,1,0.36,1)] ${loading ? "translate-y-0" : "-translate-y-full pointer-events-none"}`,
				"aria-hidden": !loading,
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "flex flex-col items-center",
					children: [
						/* @__PURE__ */ _jsxDEV(LogoVB, {
							size: 88,
							className: "w-22 h-22 shadow-2xl border-2 border-white/20"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 457,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("span", {
							className: "font-display text-white text-2xl sm:text-3xl tracking-widest mt-5 uppercase",
							children: "ВНЕ ВРЕМЕНИ"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 458,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("span", {
							className: "text-white/60 text-xs font-mono tracking-widest mt-1.5 uppercase",
							children: "Барбершоп · Пермь"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 461,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 456,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 450,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "fixed top-0 left-0 z-50 h-1 barber-pole-stripe transition-all duration-150 ease-out pointer-events-none",
				style: { width: `${scrollProgress}%` },
				"aria-hidden": "true"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 468,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("header", {
				className: `sticky top-0 z-40 bg-[#FBF8F4]/95 backdrop-blur-md border-b border-black/8 px-4 sm:px-8 py-3.5 transition-transform duration-300 ease-in-out ${headerVisible ? "translate-y-0" : "-translate-y-full"}`,
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "max-w-7xl mx-auto flex items-center justify-between gap-4",
					children: [
						/* @__PURE__ */ _jsxDEV("a", {
							href: "#",
							className: "flex items-center gap-3 shrink-0 group focus-visible:outline-2 focus-visible:outline-[#C8102E]",
							"aria-label": "Барбершоп Вне Времени Главная",
							children: [/* @__PURE__ */ _jsxDEV(LogoVB, {
								size: 44,
								className: "group-hover:scale-105 transition-transform duration-300"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 487,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "font-display text-lg sm:text-xl tracking-tight text-[#111111] whitespace-nowrap",
								children: "ВНЕ ВРЕМЕНИ"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 488,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 482,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("nav", {
							className: "hidden lg:flex items-center gap-8 text-sm font-medium text-black/75",
							children: [
								/* @__PURE__ */ _jsxDEV("a", {
									href: "#about",
									className: "hover:text-[#C8102E] transition-colors whitespace-nowrap",
									children: "О нас"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 495,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("a", {
									href: "#free",
									className: "hover:text-[#C8102E] transition-colors whitespace-nowrap",
									children: "Бесплатно"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 498,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("a", {
									href: "#masters",
									className: "hover:text-[#C8102E] transition-colors whitespace-nowrap",
									children: "Мастера"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 501,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("a", {
									href: "#works",
									className: "hover:text-[#C8102E] transition-colors whitespace-nowrap",
									children: "Работы"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 504,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("a", {
									href: "#pricing",
									className: "hover:text-[#C8102E] transition-colors whitespace-nowrap",
									children: "Прайс"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 507,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("a", {
									href: "#reviews",
									className: "hover:text-[#C8102E] transition-colors whitespace-nowrap",
									children: "Отзывы"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 510,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("a", {
									href: "#booking",
									className: "hover:text-[#C8102E] transition-colors whitespace-nowrap",
									children: "Запись"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 513,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("a", {
									href: "#faq",
									className: "hover:text-[#C8102E] transition-colors whitespace-nowrap",
									children: "FAQ"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 516,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("a", {
									href: "#contacts",
									className: "hover:text-[#C8102E] transition-colors whitespace-nowrap",
									children: "Контакты"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 519,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 494,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-3 shrink-0",
							children: /* @__PURE__ */ _jsxDEV("a", {
								href: DIKIDI_GENERAL,
								target: "_blank",
								rel: "noopener noreferrer",
								className: "btn-barber px-5 py-2.5 bg-black text-white text-xs sm:text-sm font-semibold tracking-wider uppercase whitespace-nowrap shadow-sm focus-visible:outline-2 focus-visible:outline-[#C8102E]",
								"aria-label": "Записаться онлайн в барбершоп Вне времени через Dikidi",
								children: [/* @__PURE__ */ _jsxDEV("span", { className: "btn-fill" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 533,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "relative z-10 flex items-center gap-1.5",
									children: [/* @__PURE__ */ _jsxDEV("span", { children: "Записаться" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 535,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV(ArrowUpRight, { className: "w-4 h-4 btn-arrow" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 536,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 534,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 526,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 525,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 480,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 475,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("section", {
				ref: heroRef,
				id: "hero",
				className: "relative pt-2 pb-12 sm:pb-20 px-4 sm:px-8 max-w-7xl mx-auto overflow-hidden",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "absolute -top-6 left-1/2 -translate-x-1/2 select-none pointer-events-none font-display text-[15vw] leading-none whitespace-nowrap tracking-tighter text-stroke-subtle z-0",
						style: { transform: `translate(-50%, ${scrollYPos * .18}px)` },
						"aria-hidden": "true",
						children: "ВНЕ ВРЕМЕНИ"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 550,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "absolute right-8 top-16 select-none pointer-events-none opacity-20 hidden md:block text-black",
						style: { transform: `translateY(${scrollYPos * -.12}px) rotate(15deg)` },
						"aria-hidden": "true",
						children: /* @__PURE__ */ _jsxDEV(StraightRazorIcon, { size: 72 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 564,
							columnNumber: 11
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 559,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "relative w-full aspect-[4/3] rounded-xl overflow-visible shadow-2xl border border-black/10 bg-black/5 z-10 my-4 sm:my-6",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "w-full h-full rounded-xl overflow-hidden",
							children: /* @__PURE__ */ _jsxDEV("img", {
								src: "/assets/aistudio/IMG_7740_aa44e714.jpeg",
								alt: "Вход и фасад барбершопа Вне времени с вывеской и барбер-полом на Комсомольском проспекте, 87",
								loading: "eager",
								className: "w-full h-full object-cover transition-transform duration-1000 ease-out hover:scale-103",
								style: { objectPosition: "center 35%" }
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 571,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 570,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "absolute -bottom-7 -right-3 sm:-bottom-10 sm:-right-6 z-30 w-24 h-24 sm:w-32 sm:h-32 select-none overflow-visible",
							children: /* @__PURE__ */ _jsxDEV("div", {
								className: "relative w-full h-full flex items-center justify-center",
								children: [
									/* @__PURE__ */ _jsxDEV("div", { className: "absolute inset-0 rounded-full bg-black shadow-2xl border border-white/20" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 584,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("svg", {
										viewBox: "0 0 160 160",
										className: "w-full h-full animate-spin-slow overflow-visible relative z-10",
										style: { animationDuration: `${Math.max(6, 20 - scrollProgress * .2)}s` },
										children: [/* @__PURE__ */ _jsxDEV("path", {
											id: "sealCirclePath",
											d: "M 80, 80 m -62, 0 a 62,62 0 1,1 124,0 a 62,62 0 1,1 -124,0",
											fill: "none"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 592,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("text", {
											className: "text-[12px] font-display font-extrabold tracking-[3.8px] fill-white uppercase",
											children: /* @__PURE__ */ _jsxDEV("textPath", {
												href: "#sealCirclePath",
												startOffset: "0%",
												children: "ВНЕ ВРЕМЕНИ · БАРБЕРШОП · ПЕРМЬ ·"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 598,
												columnNumber: 19
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 597,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 587,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "absolute inset-0 m-auto w-12 h-12 sm:w-16 sm:h-16 rounded-full bg-black flex items-center justify-center overflow-hidden z-20",
										children: /* @__PURE__ */ _jsxDEV(LogoVB, {
											size: 60,
											className: "w-full h-full border border-white/30 rounded-full"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 606,
											columnNumber: 17
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 605,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 582,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 581,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 569,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "mt-8 sm:mt-12 max-w-3xl relative z-10",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2 text-xs sm:text-sm font-semibold tracking-wider uppercase mb-3 text-black/70",
								children: [
									/* @__PURE__ */ _jsxDEV("span", { children: "ПЕРМЬ" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 616,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[#C8102E]",
										children: "·"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 617,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV("a", {
										href: DGIS_URL,
										target: "_blank",
										rel: "noopener noreferrer",
										className: "inline-flex items-center gap-1.5 text-[#12306B] font-bold hover:underline",
										children: [/* @__PURE__ */ _jsxDEV(Star, { className: "w-4 h-4 fill-[#C8102E] text-[#C8102E]" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 624,
											columnNumber: 15
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "5.0 В 2ГИС" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 625,
											columnNumber: 15
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 618,
										columnNumber: 13
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 615,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV(RevealOnScroll, {
								as: "h1",
								delay: 100,
								className: "text-4xl sm:text-6xl lg:text-7xl font-display leading-[0.95] text-black tracking-tighter mb-4",
								children: "ВНЕ ВРЕМЕНИ"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 630,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV(RevealOnScroll, {
								as: "p",
								delay: 200,
								className: "text-lg sm:text-2xl text-black/80 font-normal leading-relaxed mb-8",
								children: "Мужские стрижки и бритьё в Перми на Комсомольском проспекте."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 635,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex flex-col sm:flex-row items-stretch sm:items-center gap-4",
								children: [/* @__PURE__ */ _jsxDEV("a", {
									href: DIKIDI_GENERAL,
									target: "_blank",
									rel: "noopener noreferrer",
									className: "btn-barber px-8 py-4 bg-black text-white text-center text-sm tracking-widest shadow-lg focus-visible:outline-2 focus-visible:outline-[#C8102E]",
									"aria-label": "Записаться онлайн на стрижку",
									children: [
										/* @__PURE__ */ _jsxDEV("span", { className: "btn-fill" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 648,
											columnNumber: 15
										}, this),
										/* @__PURE__ */ _jsxDEV("span", { className: "absolute inset-y-0 w-20 bg-gradient-to-r from-transparent via-white/18 to-transparent pointer-events-none animate-glare" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 650,
											columnNumber: 15
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "relative z-10 flex items-center gap-2",
											children: [/* @__PURE__ */ _jsxDEV("span", { children: "Записаться онлайн" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 652,
												columnNumber: 17
											}, this), /* @__PURE__ */ _jsxDEV(ArrowUpRight, { className: "w-4 h-4 btn-arrow" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 653,
												columnNumber: 17
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 651,
											columnNumber: 15
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 641,
									columnNumber: 13
								}, this), /* @__PURE__ */ _jsxDEV("a", {
									href: "#pricing",
									className: "px-6 py-4 border border-black/20 hover:border-black text-black font-semibold text-sm tracking-wide flex items-center justify-center gap-2 hover:bg-black/5 transition-colors min-h-[48px] focus-visible:outline-2 focus-visible:outline-[#C8102E]",
									children: [/* @__PURE__ */ _jsxDEV("span", { children: "Смотреть цены" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 661,
										columnNumber: 15
									}, this), /* @__PURE__ */ _jsxDEV(ChevronRight, { className: "w-4 h-4 rotate-90" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 662,
										columnNumber: 15
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 657,
									columnNumber: 13
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 640,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 613,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "mt-14 sm:mt-18 relative w-full h-8 flex items-center",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "absolute left-0 top-1/2 -translate-y-1/2 h-0.5 bg-[#C8102E] transition-all duration-100 ease-out",
								style: { width: `${Math.min(100, Math.max(6, scrollProgress * 1.8))}%` }
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 669,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "absolute right-0 top-1/2 -translate-y-1/2 h-0.5 bg-black/10",
								style: { width: `${Math.max(0, 100 - Math.min(100, Math.max(6, scrollProgress * 1.8)))}%` }
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 673,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "absolute top-1/2 -translate-y-1/2 -translate-x-1/2 text-[#C8102E] transition-all duration-100 ease-out",
								style: {
									left: `${Math.min(98, Math.max(2, scrollProgress * 1.8))}%`,
									transform: `translate(-50%, -50%) rotate(${Math.sin(scrollYPos * .05) * 15 - 45}deg)`
								},
								children: /* @__PURE__ */ _jsxDEV(Scissors, { className: "w-5 h-5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 684,
									columnNumber: 13
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 677,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 668,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 544,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("section", {
				className: "py-4 border-y border-black/10 overflow-hidden bg-black/3 select-none",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "animate-marquee-left flex items-center gap-6 whitespace-nowrap text-stroke-dark font-display text-2xl sm:text-3xl tracking-wider uppercase",
					children: [...Array(6)].map((_, i) => /* @__PURE__ */ _jsxDEV("span", {
						className: "flex items-center gap-6",
						children: [/* @__PURE__ */ _jsxDEV("span", { children: "BARBERSHOP · ВНЕ ВРЕМЕНИ · ПЕРМЬ ·" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 695,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "text-[#C8102E] text-lg font-sans",
							children: "✦"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 696,
							columnNumber: 15
						}, this)]
					}, i, true, {
						fileName: _jsxFileName,
						lineNumber: 694,
						columnNumber: 13
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 692,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "animate-marquee-right flex items-center gap-6 whitespace-nowrap text-stroke-dark font-display text-2xl sm:text-3xl tracking-wider uppercase mt-2",
					children: [...Array(6)].map((_, i) => /* @__PURE__ */ _jsxDEV("span", {
						className: "flex items-center gap-6",
						children: [/* @__PURE__ */ _jsxDEV("span", { children: "FADE · BEARD · STYLE · CLASSIC ·" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 705,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "text-[#12306B] text-lg font-sans",
							children: "✦"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 706,
							columnNumber: 15
						}, this)]
					}, i, true, {
						fileName: _jsxFileName,
						lineNumber: 704,
						columnNumber: 13
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 702,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 690,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("section", {
				id: "free",
				className: "py-12 sm:py-16 px-4 sm:px-8 max-w-7xl mx-auto relative",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "mb-8",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2 text-xs sm:text-sm font-semibold text-black/60 tracking-wider uppercase mb-2",
						children: [
							/* @__PURE__ */ _jsxDEV("span", {
								className: "text-[#C8102E] font-bold",
								children: "02"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 716,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("span", { children: "/" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 717,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("span", { children: "Сервис" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 718,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 715,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV(RevealOnScroll, {
						as: "h2",
						className: "text-3xl sm:text-5xl font-display text-black leading-tight",
						children: "В КАЖДЫЙ ВИЗИТ — БЕСПЛАТНО"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 720,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 714,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "grid grid-cols-2 md:grid-cols-3 gap-3 sm:gap-4",
					children: AMENITIES_LIST.map((item, idx) => {
						const Icon = item.icon;
						return /* @__PURE__ */ _jsxDEV("div", {
							className: "group relative h-[120px] p-4 bg-white border border-black/15 rounded-md transition-colors duration-200 hover:bg-[#12306B] active:bg-[#12306B] flex flex-col justify-between cursor-pointer select-none",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-start",
								children: item.customP ? /* @__PURE__ */ _jsxDEV("span", {
									className: "font-display font-black text-xl text-black/75 group-hover:text-white transition-colors",
									children: "P"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 736,
									columnNumber: 21
								}, this) : Icon ? /* @__PURE__ */ _jsxDEV(Icon, { className: "w-5 h-5 text-black/75 group-hover:text-white transition-colors" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 740,
									columnNumber: 21
								}, this) : null
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 734,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "font-semibold text-sm sm:text-base text-black group-hover:text-white transition-colors leading-snug",
								children: item.title
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 744,
								columnNumber: 17
							}, this)]
						}, idx, true, {
							fileName: _jsxFileName,
							lineNumber: 730,
							columnNumber: 15
						}, this);
					})
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 726,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 713,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("section", {
				ref: aboutRef,
				id: "about",
				className: "py-12 sm:py-16 px-4 sm:px-8 max-w-7xl mx-auto relative overflow-hidden",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "absolute -top-10 right-10 select-none pointer-events-none font-display text-[18vw] leading-none text-stroke-subtle z-0",
						style: { transform: `translateY(${(scrollYPos - 1200) * .15}px)` },
						"aria-hidden": "true",
						children: "5.0"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 760,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "absolute left-6 top-20 select-none pointer-events-none opacity-15 hidden md:block text-black",
						style: { transform: `translateY(${(scrollYPos - 1200) * -.1}px)` },
						"aria-hidden": "true",
						children: /* @__PURE__ */ _jsxDEV(CombIcon, { size: 64 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 774,
							columnNumber: 11
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 769,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "absolute right-1.5 sm:right-3 top-10 z-30 w-14 h-64 sm:h-80 hidden sm:block",
						children: /* @__PURE__ */ _jsxDEV(BarberPole3D, {
							side: "right",
							className: "w-full h-full"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 779,
							columnNumber: 11
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 778,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "sm:pr-16 relative z-10",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2 text-xs sm:text-sm font-semibold text-black/60 tracking-wider uppercase mb-3",
								children: [
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[#C8102E] font-bold",
										children: "03"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 784,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV("span", { children: "/" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 785,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV("span", { children: "О нас" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 786,
										columnNumber: 13
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 783,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV(RevealOnScroll, {
								as: "h2",
								className: "text-3xl sm:text-5xl font-display text-black mb-4 leading-tight",
								children: "ВНЕ ВРЕМЕНИ"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 789,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV(RevealOnScroll, {
								as: "p",
								delay: 100,
								className: "text-xl sm:text-2xl text-black/85 max-w-3xl leading-relaxed mb-10",
								children: "Здесь не спешат. Точность в деталях, спокойный разговор и стрижка, с которой хочется выйти на улицу."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 793,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-1 sm:grid-cols-3 gap-6 sm:gap-8 mb-12",
								children: [
									"ТОЧНОСТЬ",
									"СПОКОЙСТВИЕ",
									"ВНИМАНИЕ"
								].map((word, idx) => /* @__PURE__ */ _jsxDEV("div", {
									className: "group",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-2xl sm:text-3xl font-display tracking-tight text-black block mb-2",
										children: word
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 802,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("div", { className: "h-0.5 bg-[#C8102E] w-16 group-hover:w-full transition-all duration-500 ease-out" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 805,
										columnNumber: 17
									}, this)]
								}, idx, true, {
									fileName: _jsxFileName,
									lineNumber: 801,
									columnNumber: 15
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 799,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-2xl",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "p-6 bg-white border border-black/10 rounded-lg",
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-baseline gap-2",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "text-4xl sm:text-5xl font-display text-[#C8102E] tabular-nums",
												children: ratingCount.toFixed(1)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 815,
												columnNumber: 17
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												className: "text-sm font-bold text-black/60 uppercase",
												children: "в 2ГИС"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 818,
												columnNumber: 17
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 814,
											columnNumber: 15
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center gap-1 my-2",
											children: [
												1,
												2,
												3,
												4,
												5
											].map((starNum) => /* @__PURE__ */ _jsxDEV(Star, { className: `w-4 h-4 transition-colors duration-300 ${starNum <= litStars ? "fill-[#C8102E] text-[#C8102E]" : "text-black/15"}` }, starNum, false, {
												fileName: _jsxFileName,
												lineNumber: 822,
												columnNumber: 19
											}, this))
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 820,
											columnNumber: 15
										}, this),
										/* @__PURE__ */ _jsxDEV("p", {
											className: "text-xs uppercase font-medium text-black/60",
											children: "Рейтинг в 2ГИС"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 832,
											columnNumber: 15
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 813,
									columnNumber: 13
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "p-6 bg-white border border-black/10 rounded-lg flex flex-col justify-between",
									children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-3xl sm:text-4xl font-display text-[#12306B] block tabular-nums",
										children: "10:00 – 22:00"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 840,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-xs uppercase font-medium text-black/60 block mt-2",
										children: "График"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 843,
										columnNumber: 17
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 839,
										columnNumber: 15
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "text-[11px] text-black/50 mt-3 italic",
										children: "Пт: 10:00-13:00 и 15:00-22:00. По договорённости."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 847,
										columnNumber: 15
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 838,
									columnNumber: 13
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 811,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 782,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 754,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("section", {
				id: "masters",
				className: "py-12 sm:py-16 px-4 sm:px-8 max-w-7xl mx-auto relative overflow-hidden",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "absolute -top-10 left-10 select-none pointer-events-none font-display text-[15vw] leading-none text-stroke-subtle z-0",
						style: { transform: `translateY(${(scrollYPos - 1900) * .12}px)` },
						"aria-hidden": "true",
						children: "BRAND"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 858,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "absolute bottom-10 right-4 select-none pointer-events-none font-display text-[12vw] leading-none text-stroke-subtle z-0",
						style: { transform: `translateY(${(scrollYPos - 2200) * -.1}px)` },
						"aria-hidden": "true",
						children: "NEW SCHOOL"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 865,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "absolute left-1.5 sm:left-3 top-10 z-30 w-14 h-64 sm:h-80 hidden sm:block",
						children: /* @__PURE__ */ _jsxDEV(BarberPole3D, {
							side: "left",
							className: "w-full h-full"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 875,
							columnNumber: 11
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 874,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "relative z-10",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2 text-xs sm:text-sm font-semibold text-black/60 tracking-wider uppercase mb-3",
								children: [
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[#C8102E] font-bold",
										children: "04"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 880,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV("span", { children: "/" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 881,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV("span", { children: "Мастера" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 882,
										columnNumber: 13
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 879,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV(RevealOnScroll, {
								as: "h2",
								className: "text-3xl sm:text-5xl font-display text-black mb-8 leading-tight",
								children: "МАСТЕРА САЛОНА"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 885,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-1 lg:grid-cols-3 gap-8",
								children: [
									/* @__PURE__ */ _jsxDEV(RevealOnScroll, {
										delay: 0,
										className: "h-full",
										children: /* @__PURE__ */ _jsxDEV("div", {
											className: "relative bg-white border border-black/10 rounded-lg overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between group h-full",
											children: [
												/* @__PURE__ */ _jsxDEV("div", { className: "absolute left-0 top-0 bottom-0 w-1 barber-pole-stripe" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 894,
													columnNumber: 15
												}, this),
												/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
													className: "relative aspect-[3/4] overflow-hidden bg-black/5",
													children: [
														/* @__PURE__ */ _jsxDEV("img", {
															src: "/assets/aistudio/IMG_7605_2dc15615.jpeg",
															alt: "Патидинов Сирожидин, Барбер салона Вне времени",
															loading: "lazy",
															className: "w-full h-full object-cover object-top transition-transform duration-500 group-hover:scale-104"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 898,
															columnNumber: 19
														}, this),
														/* @__PURE__ */ _jsxDEV("div", {
															className: "absolute top-3 left-4 bg-black text-white px-3 py-1 text-xs font-mono uppercase tracking-wider",
															children: "Барбер"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 904,
															columnNumber: 19
														}, this),
														/* @__PURE__ */ _jsxDEV("div", {
															className: "absolute top-3 right-3 bg-white/95 text-black px-2.5 py-1 text-xs font-semibold flex items-center gap-1 shadow-sm",
															children: [
																/* @__PURE__ */ _jsxDEV(Star, { className: "w-3.5 h-3.5 fill-[#C8102E] text-[#C8102E]" }, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 908,
																	columnNumber: 21
																}, this),
																/* @__PURE__ */ _jsxDEV("span", { children: "5.0" }, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 909,
																	columnNumber: 21
																}, this),
																/* @__PURE__ */ _jsxDEV("span", {
																	className: "text-black/50 text-[10px]",
																	children: "(8 оценок)"
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 910,
																	columnNumber: 21
																}, this)
															]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 907,
															columnNumber: 19
														}, this)
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 897,
													columnNumber: 17
												}, this), /* @__PURE__ */ _jsxDEV("div", {
													className: "p-6",
													children: [
														/* @__PURE__ */ _jsxDEV("h3", {
															className: "font-display text-xl text-black",
															children: "Патидинов Сирожидин"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 915,
															columnNumber: 19
														}, this),
														/* @__PURE__ */ _jsxDEV("span", {
															className: "text-xs text-[#C8102E] font-bold uppercase tracking-wider block mt-1",
															children: "Барбер"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 916,
															columnNumber: 19
														}, this),
														/* @__PURE__ */ _jsxDEV("p", {
															className: "text-sm text-black/75 mt-3 leading-relaxed",
															children: "«Молодой мастер новой школы, который постоянно совершенствует свои навыки и следит за современными тенденциями. Аккуратность, внимание к деталям и искренний подход к каждому гостю — то, что отличает его работу. Начало большого пути начинается здесь.»"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 919,
															columnNumber: 19
														}, this),
														/* @__PURE__ */ _jsxDEV("div", {
															className: "mt-5 pt-4 border-t border-black/10",
															children: [/* @__PURE__ */ _jsxDEV("span", {
																className: "text-[11px] font-mono uppercase text-black/50 block mb-2",
																children: "Работы"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 927,
																columnNumber: 21
															}, this), /* @__PURE__ */ _jsxDEV("div", {
																className: "grid grid-cols-3 gap-2",
																children: ALL_WORKS.filter((w) => w.masterId === "sirozhidin").map((work, idx) => /* @__PURE__ */ _jsxDEV("button", {
																	onClick: () => openMasterWorkModal(ALL_WORKS.filter((w) => w.masterId === "sirozhidin"), idx),
																	className: "aspect-[4/5] overflow-hidden rounded bg-black/5 border border-black/10 hover:opacity-85 transition-opacity cursor-pointer focus-visible:outline-2 focus-visible:outline-[#C8102E]",
																	"aria-label": `Открыть работу: ${work.title}`,
																	children: /* @__PURE__ */ _jsxDEV(BarberImage, {
																		src: work.src,
																		alt: work.title,
																		containerClassName: "w-full h-full",
																		showSpinner: false
																	}, void 0, false, {
																		fileName: _jsxFileName,
																		lineNumber: 943,
																		columnNumber: 27
																	}, this)
																}, idx, false, {
																	fileName: _jsxFileName,
																	lineNumber: 932,
																	columnNumber: 25
																}, this))
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 930,
																columnNumber: 21
															}, this)]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 926,
															columnNumber: 19
														}, this)
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 914,
													columnNumber: 17
												}, this)] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 896,
													columnNumber: 15
												}, this),
												/* @__PURE__ */ _jsxDEV("div", {
													className: "p-6 pt-0",
													children: /* @__PURE__ */ _jsxDEV("a", {
														href: DIKIDI_SIROZHIDIN,
														target: "_blank",
														rel: "noopener noreferrer",
														className: "btn-barber w-full py-3 bg-black text-white text-xs font-bold uppercase tracking-wider focus-visible:outline-2 focus-visible:outline-[#C8102E]",
														"aria-label": "Записаться к Сирожидину",
														children: [/* @__PURE__ */ _jsxDEV("span", { className: "btn-fill" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 964,
															columnNumber: 19
														}, this), /* @__PURE__ */ _jsxDEV("span", {
															className: "relative z-10 flex items-center gap-2",
															children: [/* @__PURE__ */ _jsxDEV("span", { children: "Записаться к Сирожидину" }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 966,
																columnNumber: 21
															}, this), /* @__PURE__ */ _jsxDEV(ArrowUpRight, { className: "w-4 h-4 btn-arrow" }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 967,
																columnNumber: 21
															}, this)]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 965,
															columnNumber: 19
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 957,
														columnNumber: 17
													}, this)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 956,
													columnNumber: 15
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 893,
											columnNumber: 15
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 892,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV(RevealOnScroll, {
										delay: 150,
										className: "h-full",
										children: /* @__PURE__ */ _jsxDEV("div", {
											className: "relative bg-white border border-black/10 rounded-lg overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between group h-full",
											children: [
												/* @__PURE__ */ _jsxDEV("div", { className: "absolute left-0 top-0 bottom-0 w-1 barber-pole-stripe" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 977,
													columnNumber: 15
												}, this),
												/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
													className: "relative aspect-[3/4] overflow-hidden bg-black/5",
													children: [/* @__PURE__ */ _jsxDEV("img", {
														src: "/assets/aistudio/IMG_7604_63e264c8.jpeg",
														alt: "Бахридинов Жамшид, Начинающий барбер салона Вне времени",
														loading: "lazy",
														className: "w-full h-full object-cover object-top transition-transform duration-500 group-hover:scale-104"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 981,
														columnNumber: 19
													}, this), /* @__PURE__ */ _jsxDEV("div", {
														className: "absolute top-3 left-4 bg-black text-white px-3 py-1 text-xs font-mono uppercase tracking-wider",
														children: "Начинающий барбер"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 987,
														columnNumber: 19
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 980,
													columnNumber: 17
												}, this), /* @__PURE__ */ _jsxDEV("div", {
													className: "p-6",
													children: [
														/* @__PURE__ */ _jsxDEV("h3", {
															className: "font-display text-xl text-black",
															children: "Бахридинов Жамшид"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 993,
															columnNumber: 19
														}, this),
														/* @__PURE__ */ _jsxDEV("span", {
															className: "text-xs text-[#12306B] font-bold uppercase tracking-wider block mt-1",
															children: "Начинающий барбер"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 994,
															columnNumber: 19
														}, this),
														/* @__PURE__ */ _jsxDEV("p", {
															className: "text-sm text-black/75 mt-3 leading-relaxed",
															children: "«Создаю стиль, подчёркиваю индивидуальность. Каждый день становлюсь лучше ради вашего идеального образа. Качество, аккуратность и любовь к своему делу.»"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 997,
															columnNumber: 19
														}, this),
														/* @__PURE__ */ _jsxDEV("div", {
															className: "mt-5 pt-4 border-t border-black/10",
															children: [/* @__PURE__ */ _jsxDEV("span", {
																className: "text-[11px] font-mono uppercase text-black/50 block mb-2",
																children: "Работы"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 1004,
																columnNumber: 21
															}, this), /* @__PURE__ */ _jsxDEV("div", {
																className: "grid grid-cols-2 gap-2",
																children: ALL_WORKS.filter((w) => w.masterId === "jamshid").map((work, idx) => /* @__PURE__ */ _jsxDEV("button", {
																	onClick: () => openMasterWorkModal(ALL_WORKS.filter((w) => w.masterId === "jamshid"), idx),
																	className: "aspect-[4/5] overflow-hidden rounded bg-black/5 border border-black/10 hover:opacity-85 transition-opacity cursor-pointer focus-visible:outline-2 focus-visible:outline-[#C8102E]",
																	"aria-label": `Открыть работу: ${work.title}`,
																	children: /* @__PURE__ */ _jsxDEV(BarberImage, {
																		src: work.src,
																		alt: work.title,
																		containerClassName: "w-full h-full",
																		showSpinner: false,
																		style: { objectPosition: work.cropPosition || "center" }
																	}, void 0, false, {
																		fileName: _jsxFileName,
																		lineNumber: 1020,
																		columnNumber: 27
																	}, this)
																}, idx, false, {
																	fileName: _jsxFileName,
																	lineNumber: 1009,
																	columnNumber: 25
																}, this))
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 1007,
																columnNumber: 21
															}, this)]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 1003,
															columnNumber: 19
														}, this)
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 992,
													columnNumber: 17
												}, this)] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 979,
													columnNumber: 15
												}, this),
												/* @__PURE__ */ _jsxDEV("div", {
													className: "p-6 pt-0",
													children: /* @__PURE__ */ _jsxDEV("a", {
														href: DIKIDI_ZHAMSHID,
														target: "_blank",
														rel: "noopener noreferrer",
														className: "btn-barber w-full py-3 bg-black text-white text-xs font-bold uppercase tracking-wider focus-visible:outline-2 focus-visible:outline-[#C8102E]",
														"aria-label": "Записаться к Жамшиду",
														children: [/* @__PURE__ */ _jsxDEV("span", { className: "btn-fill" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1042,
															columnNumber: 19
														}, this), /* @__PURE__ */ _jsxDEV("span", {
															className: "relative z-10 flex items-center gap-2",
															children: [/* @__PURE__ */ _jsxDEV("span", { children: "Записаться к Жамшиду" }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 1044,
																columnNumber: 21
															}, this), /* @__PURE__ */ _jsxDEV(ArrowUpRight, { className: "w-4 h-4 btn-arrow" }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 1045,
																columnNumber: 21
															}, this)]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 1043,
															columnNumber: 19
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1035,
														columnNumber: 17
													}, this)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1034,
													columnNumber: 15
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 976,
											columnNumber: 13
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 975,
										columnNumber: 11
									}, this),
									/* @__PURE__ */ _jsxDEV(RevealOnScroll, {
										delay: 300,
										className: "h-full",
										children: /* @__PURE__ */ _jsxDEV("div", {
											className: "relative bg-white border border-black/10 rounded-lg overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between group h-full",
											children: [
												/* @__PURE__ */ _jsxDEV("div", { className: "absolute left-0 top-0 bottom-0 w-1 barber-pole-stripe" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1055,
													columnNumber: 15
												}, this),
												/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
													className: "relative aspect-[3/4] overflow-hidden bg-black/5",
													children: [
														/* @__PURE__ */ _jsxDEV("img", {
															src: "/assets/aistudio/IMG_1977_ce6b0484.jpeg",
															alt: "Бахридинов Максуд, BRAND-барбер салона Вне времени",
															loading: "lazy",
															className: "w-full h-full object-cover object-top transition-transform duration-500 group-hover:scale-104"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1059,
															columnNumber: 19
														}, this),
														/* @__PURE__ */ _jsxDEV("div", {
															className: "absolute top-3 left-4 bg-[#12306B] text-white px-3 py-1 text-xs font-mono uppercase tracking-wider",
															children: "BRAND-барбер"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1065,
															columnNumber: 19
														}, this),
														/* @__PURE__ */ _jsxDEV("div", {
															className: "absolute top-3 right-3 bg-white/95 text-black px-2.5 py-1 text-xs font-semibold shadow-sm",
															children: "10 лет опыта"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1068,
															columnNumber: 19
														}, this)
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1058,
													columnNumber: 17
												}, this), /* @__PURE__ */ _jsxDEV("div", {
													className: "p-6",
													children: [
														/* @__PURE__ */ _jsxDEV("h3", {
															className: "font-display text-xl text-black",
															children: "Бахридинов Максуд"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1074,
															columnNumber: 19
														}, this),
														/* @__PURE__ */ _jsxDEV("span", {
															className: "text-xs text-[#C8102E] font-bold uppercase tracking-wider block mt-1",
															children: "BRAND-барбер"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1075,
															columnNumber: 19
														}, this),
														/* @__PURE__ */ _jsxDEV("p", {
															className: "text-sm text-black/75 mt-3 leading-relaxed",
															children: "«10 лет опыта, сотни довольных клиентов и любовь к своему делу. Мастер, который знает всё о чистых фейдах, аккуратных бородах и стильных удлинённых стрижках. Спокойный в работе, уверенный в результате и всегда внимательный к пожеланиям гостя. Если нужен образ, который будет выглядеть достойно каждый день, вы по адресу.»"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1078,
															columnNumber: 19
														}, this),
														/* @__PURE__ */ _jsxDEV("div", {
															className: "mt-5 pt-4 border-t border-black/10",
															children: [/* @__PURE__ */ _jsxDEV("span", {
																className: "text-[11px] font-mono uppercase text-black/50 block mb-2",
																children: "Работы"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 1087,
																columnNumber: 21
															}, this), /* @__PURE__ */ _jsxDEV("div", {
																className: "grid grid-cols-3 gap-2",
																children: ALL_WORKS.filter((w) => w.masterId === "maksud").map((work, idx) => /* @__PURE__ */ _jsxDEV("button", {
																	onClick: () => openMasterWorkModal(ALL_WORKS.filter((w) => w.masterId === "maksud"), idx),
																	className: "aspect-[4/5] overflow-hidden rounded bg-black/5 border border-black/10 hover:opacity-85 transition-opacity cursor-pointer focus-visible:outline-2 focus-visible:outline-[#C8102E]",
																	"aria-label": `Открыть работу: ${work.title}`,
																	children: /* @__PURE__ */ _jsxDEV(BarberImage, {
																		src: work.src,
																		alt: work.title,
																		containerClassName: "w-full h-full",
																		showSpinner: false
																	}, void 0, false, {
																		fileName: _jsxFileName,
																		lineNumber: 1103,
																		columnNumber: 27
																	}, this)
																}, idx, false, {
																	fileName: _jsxFileName,
																	lineNumber: 1092,
																	columnNumber: 25
																}, this))
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 1090,
																columnNumber: 21
															}, this)]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 1086,
															columnNumber: 19
														}, this)
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1073,
													columnNumber: 17
												}, this)] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1057,
													columnNumber: 15
												}, this),
												/* @__PURE__ */ _jsxDEV("div", {
													className: "p-6 pt-0",
													children: /* @__PURE__ */ _jsxDEV("a", {
														href: DIKIDI_MAKSUD,
														target: "_blank",
														rel: "noopener noreferrer",
														className: "btn-barber w-full py-3 bg-black text-white text-xs font-bold uppercase tracking-wider focus-visible:outline-2 focus-visible:outline-[#C8102E]",
														"aria-label": "Записаться к Максуду",
														children: [/* @__PURE__ */ _jsxDEV("span", { className: "btn-fill" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1124,
															columnNumber: 19
														}, this), /* @__PURE__ */ _jsxDEV("span", {
															className: "relative z-10 flex items-center gap-2",
															children: [/* @__PURE__ */ _jsxDEV("span", { children: "Записаться к Максуду" }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 1126,
																columnNumber: 21
															}, this), /* @__PURE__ */ _jsxDEV(ArrowUpRight, { className: "w-4 h-4 btn-arrow" }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 1127,
																columnNumber: 21
															}, this)]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 1125,
															columnNumber: 19
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1117,
														columnNumber: 17
													}, this)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1116,
													columnNumber: 15
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1054,
											columnNumber: 13
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1053,
										columnNumber: 11
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 890,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 878,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 856,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("section", {
				id: "works",
				className: "py-12 sm:py-16 px-4 sm:px-8 max-w-7xl mx-auto relative overflow-hidden",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "absolute -top-10 right-4 select-none pointer-events-none font-display text-[16vw] leading-none text-stroke-subtle z-0",
						style: { transform: `translateY(${(scrollYPos - 2700) * .14}px)` },
						"aria-hidden": "true",
						children: "WORKS"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 1140,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "absolute bottom-6 left-10 select-none pointer-events-none font-display text-[12vw] leading-none text-stroke-subtle z-0",
						style: { transform: `translateY(${(scrollYPos - 3e3) * -.1}px)` },
						"aria-hidden": "true",
						children: "STYLE"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 1147,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "absolute right-12 top-24 select-none pointer-events-none opacity-20 hidden md:block text-black",
						style: { transform: `translateY(${(scrollYPos - 2700) * -.1}px)` },
						"aria-hidden": "true",
						children: /* @__PURE__ */ _jsxDEV(ClipperIcon, { size: 64 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1161,
							columnNumber: 11
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 1156,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "relative z-10",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2 text-xs sm:text-sm font-semibold text-black/60 tracking-wider uppercase mb-3",
								children: [
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[#C8102E] font-bold",
										children: "05"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1166,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV("span", { children: "/" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1167,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV("span", { children: "Портфолио" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1168,
										columnNumber: 13
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1165,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV(RevealOnScroll, {
								as: "h2",
								className: "text-3xl sm:text-5xl font-display text-black mb-6 leading-tight",
								children: "РАБОТЫ"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1171,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2 overflow-x-auto pb-3 mb-8 no-scrollbar",
								children: [
									{
										id: "all",
										label: "Все работы"
									},
									{
										id: "sirozhidin",
										label: "Сирожидин"
									},
									{
										id: "jamshid",
										label: "Жамшид"
									},
									{
										id: "maksud",
										label: "Максуд"
									}
								].map((chip) => /* @__PURE__ */ _jsxDEV("button", {
									onClick: () => setWorksFilter(chip.id),
									className: `px-5 py-2.5 text-xs sm:text-sm font-semibold uppercase tracking-wider transition-colors rounded-full shrink-0 min-h-[42px] cursor-pointer focus-visible:outline-2 focus-visible:outline-[#C8102E] ${worksFilter === chip.id ? "bg-black text-white shadow-sm" : "bg-black/5 hover:bg-black/10 text-black/75"}`,
									children: chip.label
								}, chip.id, false, {
									fileName: _jsxFileName,
									lineNumber: 1183,
									columnNumber: 15
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1176,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-5",
								children: filteredWorks.map((work, idx) => {
									const isLastOdd = filteredWorks.length % 2 !== 0 && idx === filteredWorks.length - 1;
									return /* @__PURE__ */ _jsxDEV("div", {
										onClick: () => openWorkModal(work),
										className: `group relative aspect-[3/4] overflow-hidden rounded-lg bg-black/5 border border-black/10 cursor-pointer shadow-sm hover:shadow-lg transition-all focus-visible:outline-2 focus-visible:outline-[#C8102E] ${isLastOdd ? "col-span-2 md:col-span-1" : ""}`,
										role: "button",
										tabIndex: 0,
										"aria-label": `Открыть работу: ${work.title}`,
										onKeyDown: (e) => {
											if (e.key === "Enter" || e.key === " ") openWorkModal(work);
										},
										children: [/* @__PURE__ */ _jsxDEV(BarberImage, {
											src: work.src,
											alt: work.title,
											containerClassName: "w-full h-full",
											className: "transition-transform duration-500 group-hover:scale-104",
											style: { objectPosition: work.cropPosition || "center" }
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1215,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity p-3 sm:p-4 flex flex-col justify-end text-white",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "text-xs font-bold leading-tight",
												children: work.title
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1223,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												className: "text-[10px] sm:text-[11px] text-[#C8102E] font-medium mt-1 uppercase tracking-wider",
												children: work.masterName
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1224,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1222,
											columnNumber: 19
										}, this)]
									}, work.id, true, {
										fileName: _jsxFileName,
										lineNumber: 1202,
										columnNumber: 17
									}, this);
								})
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1198,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "mt-10",
								children: /* @__PURE__ */ _jsxDEV("a", {
									href: DIKIDI_GENERAL,
									target: "_blank",
									rel: "noopener noreferrer",
									className: "btn-barber w-full py-4 bg-black text-white font-display text-sm tracking-widest uppercase shadow-md focus-visible:outline-2 focus-visible:outline-[#C8102E]",
									"aria-label": "Записаться онлайн на стрижку",
									children: [/* @__PURE__ */ _jsxDEV("span", { className: "btn-fill" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1242,
										columnNumber: 15
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "relative z-10 flex items-center gap-2",
										children: [/* @__PURE__ */ _jsxDEV("span", { children: "Записаться онлайн" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1244,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV(ArrowUpRight, { className: "w-4 h-4 btn-arrow" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1245,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1243,
										columnNumber: 15
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1235,
									columnNumber: 13
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1234,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1164,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 1138,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("section", {
				id: "pricing",
				className: "py-12 sm:py-16 px-4 sm:px-8 bg-[#12306B] text-white relative overflow-hidden",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "absolute -top-10 left-1/2 -translate-x-1/2 select-none pointer-events-none font-display text-[18vw] leading-none text-stroke-blue z-0",
					style: { transform: `translate(-50%, ${(scrollYPos - 3500) * .15}px)` },
					"aria-hidden": "true",
					children: "PRICE"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 1258,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "max-w-4xl mx-auto relative z-10",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2 text-xs sm:text-sm font-semibold text-white/60 tracking-wider uppercase mb-3",
							children: [
								/* @__PURE__ */ _jsxDEV("span", {
									className: "text-[#FF5C6C] font-bold",
									children: "06"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1268,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("span", { children: "/" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1269,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("span", { children: "Прайс" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1270,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1267,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV(RevealOnScroll, {
							as: "h2",
							className: "text-3xl sm:text-5xl font-display text-white mb-2 leading-tight",
							children: "УСЛУГИ И ЦЕНЫ"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1273,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "mb-8",
							children: /* @__PURE__ */ _jsxDEV("a", {
								href: "#free",
								className: "inline-flex items-center gap-2 text-sm sm:text-base text-white/90 hover:text-white underline decoration-[#FF5C6C] decoration-2 underline-offset-4 font-medium transition-colors",
								children: /* @__PURE__ */ _jsxDEV("span", { children: "Мытьё головы, кофе, снеки, парковка, Wi-Fi и PS5 бесплатно →" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1282,
									columnNumber: 15
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1278,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1277,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "bg-black/25 p-1.5 rounded-lg flex items-center justify-between gap-1 mb-8 max-w-lg",
							children: [
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => setSelectedCategory("brand"),
									className: `flex-1 py-3 text-xs sm:text-sm font-semibold rounded uppercase tracking-wider transition-colors min-h-[48px] cursor-pointer ${selectedCategory === "brand" ? "bg-white text-[#12306B] shadow-md" : "text-white/80 hover:text-white"}`,
									children: "BRAND-Барбер"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1288,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => setSelectedCategory("barber"),
									className: `flex-1 py-3 text-xs sm:text-sm font-semibold rounded uppercase tracking-wider transition-colors min-h-[48px] cursor-pointer ${selectedCategory === "barber" ? "bg-white text-[#12306B] shadow-md" : "text-white/80 hover:text-white"}`,
									children: "Барбер"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1298,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => setSelectedCategory("junior"),
									className: `flex-1 py-3 text-xs sm:text-sm font-semibold rounded uppercase tracking-wider transition-colors min-h-[48px] cursor-pointer ${selectedCategory === "junior" ? "bg-white text-[#12306B] shadow-md" : "text-white/80 hover:text-white"}`,
									children: "Начинающий"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1308,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1287,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "mb-6 pb-3 border-b border-white/15 flex items-center justify-between text-xs sm:text-sm text-white/80",
							children: [/* @__PURE__ */ _jsxDEV("div", { children: /* @__PURE__ */ _jsxDEV("span", {
								className: "font-semibold text-white",
								children: selectedCategory === "brand" ? "BRAND-Барбер — Бахридинов Максуд (10 лет опыта)" : selectedCategory === "barber" ? "Барбер — Патидинов Сирожидин (Рейтинг 5.0)" : "Начинающий барбер — Бахридинов Жамшид (Доступная стоимость)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1323,
								columnNumber: 15
							}, this) }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1322,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-[#FF5C6C] font-bold uppercase text-xs",
								children: "Прайс 2ГИС"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1331,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1321,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-3 sm:space-y-4",
							children: SERVICES_DATA.map((srv, idx) => {
								const currentPrice = selectedCategory === "brand" ? srv.priceBrand : selectedCategory === "barber" ? srv.priceBarber : srv.priceJunior;
								return /* @__PURE__ */ _jsxDEV("div", {
									className: "group relative p-4 sm:p-5 bg-white/5 hover:bg-white/10 border-l-2 border-transparent hover:border-[#FF5C6C] transition-all duration-200 rounded-r-lg flex flex-col sm:flex-row sm:items-center justify-between gap-2",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex-1 pr-4",
										children: [/* @__PURE__ */ _jsxDEV("h3", {
											className: "font-semibold text-base sm:text-lg text-white group-hover:text-white transition-colors",
											children: srv.name
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1350,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center gap-2 text-xs text-white/60 font-mono mt-1",
											children: [/* @__PURE__ */ _jsxDEV(Clock, { className: "w-3.5 h-3.5 text-[#FF5C6C]" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1354,
												columnNumber: 23
											}, this), /* @__PURE__ */ _jsxDEV("span", { children: srv.duration }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1355,
												columnNumber: 23
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1353,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1349,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "text-right sm:pl-4 border-t sm:border-t-0 border-white/10 pt-2 sm:pt-0",
										children: /* @__PURE__ */ _jsxDEV("span", {
											className: "font-display text-xl sm:text-2xl text-white block tabular-nums group-hover:-translate-x-1.5 transition-transform duration-200",
											children: currentPrice
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1360,
											columnNumber: 21
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1359,
										columnNumber: 19
									}, this)]
								}, idx, true, {
									fileName: _jsxFileName,
									lineNumber: 1345,
									columnNumber: 17
								}, this);
							})
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1335,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "mt-8 text-center sm:text-left",
							children: /* @__PURE__ */ _jsxDEV("a", {
								href: priceButtonConfig.url,
								target: "_blank",
								rel: "noopener noreferrer",
								className: "group px-8 py-4 bg-[#C8102E] hover:bg-[#a60b24] active:bg-[#0a1e4a] text-white font-display text-sm tracking-widest uppercase transition-all duration-200 inline-flex items-center justify-center gap-2 min-h-[48px] shadow-lg focus-visible:outline-2 focus-visible:outline-white",
								"aria-label": priceButtonConfig.text,
								children: [/* @__PURE__ */ _jsxDEV("span", { children: priceButtonConfig.text }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1378,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV(ArrowUpRight, { className: "w-4 h-4 group-hover:rotate-45 transition-transform duration-200 text-[#FF5C6C] group-hover:text-white" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1379,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1371,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1370,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 1266,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 1253,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("section", {
				id: "reviews",
				className: "py-12 sm:py-16 px-4 sm:px-8 max-w-7xl mx-auto relative overflow-hidden",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "absolute -top-10 left-10 select-none pointer-events-none font-display text-[16vw] leading-none text-stroke-subtle z-0",
						style: { transform: `translateY(${(scrollYPos - 4300) * .14}px)` },
						"aria-hidden": "true",
						children: "REVIEWS"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 1388,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "absolute right-4 top-6 select-none pointer-events-none font-serif text-[18vw] leading-none text-[#C8102E] opacity-10 font-bold z-0",
						"aria-hidden": "true",
						children: "“"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 1397,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2 text-xs sm:text-sm font-semibold text-black/60 tracking-wider uppercase mb-3 relative z-10",
						children: [
							/* @__PURE__ */ _jsxDEV("span", {
								className: "text-[#C8102E] font-bold",
								children: "07"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1405,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("span", { children: "/" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1406,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("span", { children: "Отзывы" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1407,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1404,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-col sm:flex-row sm:items-end justify-between gap-6 mb-8 relative z-10",
						children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV(RevealOnScroll, {
							as: "h2",
							className: "text-3xl sm:text-5xl font-display text-black leading-tight",
							children: "ОТЗЫВЫ КЛИЕНТОВ"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1412,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-3 mt-3",
							children: [
								/* @__PURE__ */ _jsxDEV("span", {
									className: "text-4xl font-display text-[#C8102E] tabular-nums",
									children: "5.0"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1416,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-1 text-[#C8102E]",
									children: [...Array(5)].map((_, i) => /* @__PURE__ */ _jsxDEV(Star, { className: "w-5 h-5 fill-current" }, i, false, {
										fileName: _jsxFileName,
										lineNumber: 1421,
										columnNumber: 19
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1419,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: "text-sm font-bold uppercase text-black/60",
									children: "в 2ГИС"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1424,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1415,
							columnNumber: 13
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1411,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("a", {
							href: DGIS_URL,
							target: "_blank",
							rel: "noopener noreferrer",
							className: "px-5 py-3 border border-black/30 hover:border-black text-black font-semibold text-xs uppercase tracking-wider transition-colors inline-flex items-center gap-2 min-h-[48px] self-start sm:self-auto focus-visible:outline-2 focus-visible:outline-[#C8102E]",
							children: [/* @__PURE__ */ _jsxDEV("span", { children: "Все отзывы в 2ГИС" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1436,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV(ExternalLink, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1437,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1430,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1410,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex gap-6 overflow-x-auto pb-6 snap-x snap-mandatory scroll-smooth no-scrollbar select-none relative z-10",
						children: REVIEWS_DATA.map((rev, idx) => {
							const tilt = idx % 2 === 0 ? "rotate-[-0.6deg]" : "rotate-[0.6deg]";
							return /* @__PURE__ */ _jsxDEV("div", {
								className: `snap-center shrink-0 w-[290px] sm:w-[360px] p-6 bg-white border border-black/10 rounded-lg shadow-sm flex flex-col justify-between relative overflow-hidden transition-transform duration-300 hover:rotate-0 hover:shadow-md ${tilt}`,
								children: [
									/* @__PURE__ */ _jsxDEV("div", { className: "absolute top-0 inset-x-0 h-1 barber-pole-stripe" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1450,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-1 text-[#C8102E] mb-3",
										children: [...Array(rev.rating)].map((_, i) => /* @__PURE__ */ _jsxDEV(Star, { className: "w-4 h-4 fill-current" }, i, false, {
											fileName: _jsxFileName,
											lineNumber: 1455,
											columnNumber: 23
										}, this))
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1453,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "text-sm text-black/85 italic leading-relaxed",
										children: [
											"«",
											rev.text,
											"»"
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1458,
										columnNumber: 19
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1452,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "mt-6 pt-4 border-t border-black/5 flex items-center justify-between text-xs text-black/50",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "font-semibold text-black",
											children: rev.name
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1464,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "font-mono",
											children: rev.date
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1465,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1463,
										columnNumber: 17
									}, this)
								]
							}, idx, true, {
								fileName: _jsxFileName,
								lineNumber: 1446,
								columnNumber: 15
							}, this);
						})
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 1442,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center justify-center gap-2 mt-2 relative z-10",
						children: REVIEWS_DATA.map((_, i) => /* @__PURE__ */ _jsxDEV("div", { className: "w-2 h-2 rounded-full bg-black/20" }, i, false, {
							fileName: _jsxFileName,
							lineNumber: 1475,
							columnNumber: 13
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 1473,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 1386,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("section", {
				id: "booking",
				className: "py-12 sm:py-16 px-4 sm:px-8 max-w-7xl mx-auto relative overflow-hidden",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "absolute -top-10 right-10 select-none pointer-events-none font-display text-[18vw] leading-none text-stroke-subtle z-0",
					style: { transform: `translateY(${(scrollYPos - 5e3) * .15}px)` },
					"aria-hidden": "true",
					children: "BOOK"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 1483,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "relative z-10 max-w-4xl mx-auto",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2 text-xs sm:text-sm font-semibold text-black/60 tracking-wider uppercase mb-3",
							children: [
								/* @__PURE__ */ _jsxDEV("span", {
									className: "text-[#C8102E] font-bold",
									children: "08"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1493,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("span", { children: "/" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1494,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("span", { children: "Запись" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1495,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1492,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV(RevealOnScroll, {
							as: "h2",
							className: "text-3xl sm:text-5xl font-display text-black mb-2 leading-tight",
							children: "ЗАПИСАТЬСЯ К СПЕЦИАЛИСТУ"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1498,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV(RevealOnScroll, {
							as: "p",
							delay: 100,
							className: "text-black/70 text-base sm:text-lg mb-8",
							children: "Выберите мастера, запись откроется в Dikidi"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1501,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-3 sm:space-y-4",
							children: [
								/* @__PURE__ */ _jsxDEV("a", {
									href: DIKIDI_MAKSUD,
									target: "_blank",
									rel: "noopener noreferrer",
									className: "group relative min-h-[96px] p-4 sm:p-5 bg-white border border-black/15 rounded-xl shadow-sm hover:border-[#C8102E] flex items-center justify-between gap-4 overflow-hidden transition-all duration-300 active:scale-[0.99] focus-visible:outline-2 focus-visible:outline-[#C8102E]",
									"aria-label": "Записаться к Максуду в Dikidi",
									children: [
										/* @__PURE__ */ _jsxDEV("span", { className: "absolute inset-0 bg-[#C8102E] translate-x-[-100%] group-hover:translate-x-0 transition-transform duration-350 ease-out" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1516,
											columnNumber: 15
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "relative z-10 flex items-center gap-4 sm:gap-6",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "w-16 h-16 rounded-full overflow-hidden shrink-0 border-2 border-black/10 group-hover:border-white transition-colors bg-black/5",
												children: /* @__PURE__ */ _jsxDEV("img", {
													src: "/assets/aistudio/IMG_1977_ce6b0484.jpeg",
													alt: "Бахридинов Максуд",
													className: "w-full h-full object-cover object-top"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1520,
													columnNumber: 19
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1519,
												columnNumber: 17
											}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
												className: "font-display text-lg sm:text-xl text-black group-hover:text-white transition-colors",
												children: "Бахридинов Максуд"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1527,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center gap-2 mt-1",
												children: [/* @__PURE__ */ _jsxDEV("span", {
													className: "text-xs font-bold uppercase tracking-wider text-[#12306B] group-hover:text-white/90 transition-colors",
													children: "BRAND-барбер"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1531,
													columnNumber: 21
												}, this), /* @__PURE__ */ _jsxDEV("span", {
													className: "text-xs text-black/50 group-hover:text-white/70 transition-colors",
													children: "· 10 лет опыта"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1534,
													columnNumber: 21
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1530,
												columnNumber: 19
											}, this)] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1526,
												columnNumber: 17
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1518,
											columnNumber: 15
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "relative z-10 flex items-center gap-3",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "hidden sm:inline text-xs font-semibold uppercase tracking-wider text-black/70 group-hover:text-white transition-colors",
												children: "Записаться"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1542,
												columnNumber: 17
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "w-10 h-10 rounded-full bg-black/5 group-hover:bg-white text-black group-hover:text-[#C8102E] flex items-center justify-center transition-all duration-200",
												children: /* @__PURE__ */ _jsxDEV(ArrowUpRight, { className: "w-5 h-5 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1546,
													columnNumber: 19
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1545,
												columnNumber: 17
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1541,
											columnNumber: 15
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1508,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("a", {
									href: DIKIDI_SIROZHIDIN,
									target: "_blank",
									rel: "noopener noreferrer",
									className: "group relative min-h-[96px] p-4 sm:p-5 bg-white border border-black/15 rounded-xl shadow-sm hover:border-[#C8102E] flex items-center justify-between gap-4 overflow-hidden transition-all duration-300 active:scale-[0.99] focus-visible:outline-2 focus-visible:outline-[#C8102E]",
									"aria-label": "Записаться к Сирожидину в Dikidi",
									children: [
										/* @__PURE__ */ _jsxDEV("span", { className: "absolute inset-0 bg-[#C8102E] translate-x-[-100%] group-hover:translate-x-0 transition-transform duration-350 ease-out" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1559,
											columnNumber: 15
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "relative z-10 flex items-center gap-4 sm:gap-6",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "w-16 h-16 rounded-full overflow-hidden shrink-0 border-2 border-black/10 group-hover:border-white transition-colors bg-black/5",
												children: /* @__PURE__ */ _jsxDEV("img", {
													src: "/assets/aistudio/IMG_7605_2dc15615.jpeg",
													alt: "Патидинов Сирожидин",
													className: "w-full h-full object-cover object-top"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1563,
													columnNumber: 19
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1562,
												columnNumber: 17
											}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
												className: "font-display text-lg sm:text-xl text-black group-hover:text-white transition-colors",
												children: "Патидинов Сирожидин"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1570,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center gap-2 mt-1",
												children: [/* @__PURE__ */ _jsxDEV("span", {
													className: "text-xs font-bold uppercase tracking-wider text-[#C8102E] group-hover:text-white/90 transition-colors",
													children: "Барбер"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1574,
													columnNumber: 21
												}, this), /* @__PURE__ */ _jsxDEV("span", {
													className: "text-xs text-black/50 group-hover:text-white/70 transition-colors",
													children: "· Рейтинг 5.0"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1577,
													columnNumber: 21
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1573,
												columnNumber: 19
											}, this)] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1569,
												columnNumber: 17
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1561,
											columnNumber: 15
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "relative z-10 flex items-center gap-3",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "hidden sm:inline text-xs font-semibold uppercase tracking-wider text-black/70 group-hover:text-white transition-colors",
												children: "Записаться"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1585,
												columnNumber: 17
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "w-10 h-10 rounded-full bg-black/5 group-hover:bg-white text-black group-hover:text-[#C8102E] flex items-center justify-center transition-all duration-200",
												children: /* @__PURE__ */ _jsxDEV(ArrowUpRight, { className: "w-5 h-5 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1589,
													columnNumber: 19
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1588,
												columnNumber: 17
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1584,
											columnNumber: 15
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1552,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("a", {
									href: DIKIDI_ZHAMSHID,
									target: "_blank",
									rel: "noopener noreferrer",
									className: "group relative min-h-[96px] p-4 sm:p-5 bg-white border border-black/15 rounded-xl shadow-sm hover:border-[#C8102E] flex items-center justify-between gap-4 overflow-hidden transition-all duration-300 active:scale-[0.99] focus-visible:outline-2 focus-visible:outline-[#C8102E]",
									"aria-label": "Записаться к Жамшиду в Dikidi",
									children: [
										/* @__PURE__ */ _jsxDEV("span", { className: "absolute inset-0 bg-[#C8102E] translate-x-[-100%] group-hover:translate-x-0 transition-transform duration-350 ease-out" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1602,
											columnNumber: 15
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "relative z-10 flex items-center gap-4 sm:gap-6",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "w-16 h-16 rounded-full overflow-hidden shrink-0 border-2 border-black/10 group-hover:border-white transition-colors bg-black/5",
												children: /* @__PURE__ */ _jsxDEV("img", {
													src: "/assets/aistudio/IMG_7604_63e264c8.jpeg",
													alt: "Бахридинов Жамшид",
													className: "w-full h-full object-cover object-top"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1606,
													columnNumber: 19
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1605,
												columnNumber: 17
											}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
												className: "font-display text-lg sm:text-xl text-black group-hover:text-white transition-colors",
												children: "Бахридинов Жамшид"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1613,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center gap-2 mt-1",
												children: [/* @__PURE__ */ _jsxDEV("span", {
													className: "text-xs font-bold uppercase tracking-wider text-black/75 group-hover:text-white/90 transition-colors",
													children: "Начинающий барбер"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1617,
													columnNumber: 21
												}, this), /* @__PURE__ */ _jsxDEV("span", {
													className: "text-xs text-black/50 group-hover:text-white/70 transition-colors",
													children: "· Доступная стоимость"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1620,
													columnNumber: 21
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1616,
												columnNumber: 19
											}, this)] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1612,
												columnNumber: 17
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1604,
											columnNumber: 15
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "relative z-10 flex items-center gap-3",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "hidden sm:inline text-xs font-semibold uppercase tracking-wider text-black/70 group-hover:text-white transition-colors",
												children: "Записаться"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1628,
												columnNumber: 17
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "w-10 h-10 rounded-full bg-black/5 group-hover:bg-white text-black group-hover:text-[#C8102E] flex items-center justify-center transition-all duration-200",
												children: /* @__PURE__ */ _jsxDEV(ArrowUpRight, { className: "w-5 h-5 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1632,
													columnNumber: 19
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1631,
												columnNumber: 17
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1627,
											columnNumber: 15
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1595,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1506,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "mt-8 text-center",
							children: /* @__PURE__ */ _jsxDEV("a", {
								href: DIKIDI_GENERAL,
								target: "_blank",
								rel: "noopener noreferrer",
								className: "w-full sm:w-auto px-8 py-4 border-2 border-black/20 hover:border-black text-black font-semibold text-xs sm:text-sm uppercase tracking-wider inline-flex items-center justify-center gap-2 hover:bg-black hover:text-white transition-all duration-200 min-h-[48px] rounded-lg focus-visible:outline-2 focus-visible:outline-[#C8102E]",
								children: [/* @__PURE__ */ _jsxDEV("span", { children: "Записаться в барбершоп (любой мастер)" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1646,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV(ArrowUpRight, { className: "w-4 h-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1647,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1640,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1639,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 1491,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 1481,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("section", {
				id: "faq",
				className: "py-12 sm:py-16 px-4 sm:px-8 max-w-7xl mx-auto relative overflow-hidden",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "absolute -top-8 left-1/2 -translate-x-1/2 select-none pointer-events-none font-display text-[22vw] leading-none text-stroke-subtle z-0",
					style: { transform: `translate(-50%, ${(scrollYPos - 5400) * .14}px)` },
					"aria-hidden": "true",
					children: "FAQ"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 1656,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "relative z-10 max-w-4xl mx-auto",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2 text-xs sm:text-sm font-semibold text-black/60 tracking-wider uppercase mb-3",
							children: [
								/* @__PURE__ */ _jsxDEV("span", {
									className: "text-[#C8102E] font-bold",
									children: "09"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1666,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("span", { children: "/" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1667,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("span", { children: "Вопросы и ответы" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1668,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1665,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV(RevealOnScroll, {
							as: "h2",
							className: "text-3xl sm:text-5xl font-display text-black mb-3 leading-tight",
							children: "ЧАСТЫЕ ВОПРОСЫ"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1671,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV(RevealOnScroll, {
							as: "p",
							delay: 100,
							className: "text-black/70 text-base sm:text-lg mb-8",
							children: "Всё, что важно знать перед визитом в барбершоп «Вне времени»"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1674,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-3",
							children: FAQ_DATA.map((item, idx) => {
								const isOpen = openFaq === idx;
								return /* @__PURE__ */ _jsxDEV(RevealOnScroll, {
									delay: idx * 60,
									children: /* @__PURE__ */ _jsxDEV("div", {
										className: `bg-white border rounded-xl overflow-hidden transition-all duration-200 ${isOpen ? "border-black/30 shadow-md ring-1 ring-black/5" : "border-black/15 shadow-sm hover:border-black/30"}`,
										children: [/* @__PURE__ */ _jsxDEV("button", {
											onClick: () => setOpenFaq(isOpen ? null : idx),
											className: "w-full p-5 sm:p-6 text-left flex items-center justify-between gap-4 cursor-pointer select-none focus-visible:outline-2 focus-visible:outline-[#C8102E]",
											"aria-expanded": isOpen,
											"aria-controls": `faq-answer-${idx}`,
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "font-display text-base sm:text-lg text-black font-bold tracking-tight",
												children: item.q
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1694,
												columnNumber: 23
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: `w-9 h-9 rounded-full flex items-center justify-center shrink-0 transition-colors duration-200 ${isOpen ? "bg-[#C8102E] text-white" : "bg-black/5 text-black/70"}`,
												children: isOpen ? /* @__PURE__ */ _jsxDEV(Minus, { className: "w-4 h-4" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1702,
													columnNumber: 35
												}, this) : /* @__PURE__ */ _jsxDEV(Plus, { className: "w-4 h-4" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1702,
													columnNumber: 67
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1697,
												columnNumber: 23
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1688,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											id: `faq-answer-${idx}`,
											className: `grid transition-all duration-300 ease-out ${isOpen ? "grid-rows-[1fr] opacity-100 pb-5 sm:pb-6 px-5 sm:px-6" : "grid-rows-[0fr] opacity-0 px-5 sm:px-6"}`,
											children: /* @__PURE__ */ _jsxDEV("div", {
												className: "overflow-hidden",
												children: /* @__PURE__ */ _jsxDEV("div", {
													className: "pt-2 border-t border-black/8 text-sm sm:text-base text-black/80 leading-relaxed font-normal",
													children: item.a
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1713,
													columnNumber: 25
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1712,
												columnNumber: 23
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1706,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1683,
										columnNumber: 19
									}, this)
								}, idx, false, {
									fileName: _jsxFileName,
									lineNumber: 1682,
									columnNumber: 17
								}, this);
							})
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1678,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "mt-8 p-5 bg-black/4 rounded-xl border border-black/8 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4",
							children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "font-display text-sm sm:text-base text-black block font-bold",
								children: "Остались вопросы по записи или услугам?"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1727,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs sm:text-sm text-black/60",
								children: "Позвоните нам или напишите в Telegram — ответим в течение нескольких минут."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1730,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1726,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("a", {
								href: PHONE_LINK,
								className: "btn-barber px-5 py-2.5 bg-black text-white text-xs font-semibold tracking-wider uppercase whitespace-nowrap shadow-sm focus-visible:outline-2 focus-visible:outline-[#C8102E]",
								children: [/* @__PURE__ */ _jsxDEV("span", { className: "btn-fill" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1738,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "relative z-10 flex items-center gap-1.5",
									children: /* @__PURE__ */ _jsxDEV("span", { children: PHONE_NUMBER }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1740,
										columnNumber: 17
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1739,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1734,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1725,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 1664,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 1654,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("section", {
				ref: contactsRef,
				id: "contacts",
				className: "py-12 sm:py-16 px-4 sm:px-8 bg-[#12306B] text-white relative",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "max-w-7xl mx-auto",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2 text-xs sm:text-sm font-semibold text-white/60 tracking-wider uppercase mb-3",
							children: [
								/* @__PURE__ */ _jsxDEV("span", {
									className: "text-[#FF5C6C] font-bold",
									children: "10"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1755,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("span", { children: "/" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1756,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("span", { children: "Контакты" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1757,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1754,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV(RevealOnScroll, {
							as: "h2",
							className: "text-3xl sm:text-5xl font-display text-white mb-8 leading-tight",
							children: "КАК НАС НАЙТИ"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1760,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "max-w-3xl space-y-6",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "p-6 bg-white/5 border border-white/10 rounded-lg space-y-4",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-start gap-3",
										children: [/* @__PURE__ */ _jsxDEV(MapPin, { className: "w-5 h-5 text-[#FF5C6C] shrink-0 mt-1" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1767,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("div", { children: [
											/* @__PURE__ */ _jsxDEV("span", {
												className: "text-xs uppercase text-white/60 font-mono block",
												children: "Адрес"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1769,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("span", {
												className: "text-lg font-semibold text-white",
												children: "Пермь, Комсомольский проспект, 87"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1770,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("p", {
												className: "text-xs text-white/70 mt-1",
												children: "Свердловский район, перекрёсток с улицей Коминтерна"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1773,
												columnNumber: 19
											}, this)
										] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1768,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1766,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-start gap-3 pt-4 border-t border-white/10",
										children: [/* @__PURE__ */ _jsxDEV(Clock, { className: "w-5 h-5 text-[#FF5C6C] shrink-0 mt-1" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1780,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("div", { children: [
											/* @__PURE__ */ _jsxDEV("span", {
												className: "text-xs uppercase text-white/60 font-mono block",
												children: "График работы"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1782,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "text-sm text-white/90 space-y-0.5 mt-1",
												children: [
													/* @__PURE__ */ _jsxDEV("div", { children: "Пн–Чт: 10:00 – 22:00" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1786,
														columnNumber: 21
													}, this),
													/* @__PURE__ */ _jsxDEV("div", { children: "Пт: 10:00 – 13:00 и 15:00 – 22:00" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1787,
														columnNumber: 21
													}, this),
													/* @__PURE__ */ _jsxDEV("div", { children: "Сб–Вс: 10:00 – 22:00" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1788,
														columnNumber: 21
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1785,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("span", {
												className: "text-xs text-white/50 block mt-1 italic",
												children: "Запись по предварительной договорённости"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1790,
												columnNumber: 19
											}, this)
										] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1781,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1779,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-start gap-3 pt-4 border-t border-white/10",
										children: [/* @__PURE__ */ _jsxDEV(Phone, { className: "w-5 h-5 text-[#FF5C6C] shrink-0 mt-1" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1797,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "text-xs uppercase text-white/60 font-mono block",
											children: "Телефон"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1799,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("a", {
											href: PHONE_LINK,
											className: "text-xl font-display text-white hover:text-[#FF5C6C] transition-colors block mt-0.5 tabular-nums focus-visible:outline-2 focus-visible:outline-white",
											children: PHONE_NUMBER
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1800,
											columnNumber: 19
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1798,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1796,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1765,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-1 sm:grid-cols-3 gap-3",
								children: [
									/* @__PURE__ */ _jsxDEV("a", {
										href: DGIS_URL,
										target: "_blank",
										rel: "noopener noreferrer",
										className: "group w-full py-4 px-4 border border-white/30 hover:bg-white hover:text-[#12306B] active:bg-white active:text-[#12306B] text-white font-semibold text-xs tracking-wider uppercase transition-all duration-200 flex items-center justify-center gap-2 min-h-[48px] text-center focus-visible:outline-2 focus-visible:outline-white",
										"aria-label": "Открыть карточку в 2ГИС",
										children: [/* @__PURE__ */ _jsxDEV(Navigation, { className: "w-4 h-4 text-[#FF5C6C] group-hover:text-[#12306B] group-hover:translate-x-1 transition-all" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1819,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Открыть в 2ГИС" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1820,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1812,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("a", {
										href: `https://2gis.ru/routeSearch/rsType/car/to/56.2586,57.9942`,
										target: "_blank",
										rel: "noopener noreferrer",
										className: "group w-full py-4 px-4 border border-white/30 hover:bg-white hover:text-[#12306B] active:bg-white active:text-[#12306B] text-white font-semibold text-xs tracking-wider uppercase transition-all duration-200 flex items-center justify-center gap-2 min-h-[48px] text-center focus-visible:outline-2 focus-visible:outline-white",
										"aria-label": "Построить маршрут к барбершопу",
										children: [/* @__PURE__ */ _jsxDEV("span", { children: "Построить маршрут" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1830,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV(ArrowUpRight, { className: "w-4 h-4 text-[#FF5C6C] group-hover:text-[#12306B] group-hover:translate-x-1 transition-all" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1831,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1823,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("a", {
										href: TELEGRAM_URL,
										target: "_blank",
										rel: "noopener noreferrer",
										className: "group w-full py-4 px-4 border border-white/30 hover:bg-white hover:text-[#12306B] active:bg-white active:text-[#12306B] text-white font-semibold text-xs tracking-wider uppercase transition-all duration-200 flex items-center justify-center gap-2 min-h-[48px] text-center focus-visible:outline-2 focus-visible:outline-white",
										"aria-label": "Наш Telegram-канал",
										children: [/* @__PURE__ */ _jsxDEV(Send, { className: "w-4 h-4 text-[#FF5C6C] group-hover:text-[#12306B] group-hover:translate-x-1 transition-all" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1841,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Наш Telegram" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1842,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1834,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1811,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1764,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 1753,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 1748,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "w-full h-2 barber-pole-stripe",
				"aria-hidden": "true"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 1850,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("footer", {
				className: "relative bg-[#081633] text-white pt-8 pb-16 px-4 sm:px-8 overflow-hidden",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "absolute -bottom-10 left-1/2 -translate-x-1/2 select-none pointer-events-none font-display text-[16vw] leading-none whitespace-nowrap tracking-tighter text-stroke-blue opacity-50 z-0",
					"aria-hidden": "true",
					children: "ВНЕ ВРЕМЕНИ"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 1855,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "max-w-7xl mx-auto pt-6 relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-8",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ _jsxDEV(LogoVB, {
								size: 44,
								className: "border-white/30"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1865,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "font-display text-xl text-white block",
								children: "ВНЕ ВРЕМЕНИ"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1867,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-white/60",
								children: "Пермь, Комсомольский проспект, 87"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1868,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1866,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1864,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-wrap items-center gap-6 text-xs text-white/70",
							children: [
								/* @__PURE__ */ _jsxDEV("a", {
									href: TELEGRAM_URL,
									target: "_blank",
									rel: "noopener noreferrer",
									className: "hover:text-white transition-colors",
									children: "Telegram"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1876,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("a", {
									href: DGIS_URL,
									target: "_blank",
									rel: "noopener noreferrer",
									className: "hover:text-white transition-colors",
									children: "2ГИС"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1884,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("a", {
									href: PHONE_LINK,
									className: "hover:text-white transition-colors tabular-nums",
									children: PHONE_NUMBER
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1892,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("a", {
									href: DIKIDI_GENERAL,
									target: "_blank",
									rel: "noopener noreferrer",
									className: "text-[#FF5C6C] font-semibold hover:underline",
									children: "Онлайн-запись в Dikidi"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1895,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => setExportModalOpen(true),
									className: "inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/10 hover:bg-[#C8102E] text-white text-xs font-semibold tracking-wider uppercase transition-colors cursor-pointer border border-white/15",
									"aria-label": "Экспорт и скачивание проекта в архиве",
									children: [/* @__PURE__ */ _jsxDEV(Download, { className: "w-3.5 h-3.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1908,
										columnNumber: 15
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Скачать проект (.ZIP)" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1909,
										columnNumber: 15
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1903,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1875,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-4",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-[11px] text-white/40 font-mono",
								children: [
									"© ",
									new Date().getFullYear(),
									" «Вне времени»"
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1915,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: scrollToTop,
								className: "p-3 rounded-full bg-white/10 hover:bg-[#C8102E] text-white transition-colors cursor-pointer min-h-[44px] min-w-[44px] flex items-center justify-center focus-visible:outline-2 focus-visible:outline-white",
								"aria-label": "Наверх страницы",
								children: /* @__PURE__ */ _jsxDEV(ArrowUp, { className: "w-4 h-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1923,
									columnNumber: 15
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1918,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1914,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 1862,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 1853,
				columnNumber: 7
			}, this),
			showStickyBooking && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed bottom-3 inset-x-4 z-50 md:hidden animate-in fade-in slide-in-from-bottom duration-300 pb-[env(safe-area-inset-bottom)]",
				children: /* @__PURE__ */ _jsxDEV("a", {
					href: DIKIDI_GENERAL,
					target: "_blank",
					rel: "noopener noreferrer",
					className: "btn-barber w-full h-14 bg-black text-white text-center font-display text-sm tracking-widest uppercase shadow-[0_8px_30px_rgb(0,0,0,0.35)] rounded-lg",
					"aria-label": "Записаться онлайн на стрижку",
					children: [/* @__PURE__ */ _jsxDEV("span", { className: "btn-fill" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 1939,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "relative z-10 flex items-center gap-2",
						children: [/* @__PURE__ */ _jsxDEV("span", { children: "Записаться онлайн" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1941,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV(ArrowUpRight, { className: "w-4 h-4 btn-arrow" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1942,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1940,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 1932,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 1931,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV(AudioPlayer, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 1949,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(GalleryModal, {
				images: galleryImages,
				initialIndex: galleryIndex,
				isOpen: galleryOpen,
				onClose: () => setGalleryOpen(false)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 1952,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(ExportModal, {
				isOpen: exportModalOpen,
				onClose: () => setExportModalOpen(false)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 1960,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 448,
		columnNumber: 5
	}, this);
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsV0FBVyxjQUFjO0FBQ25ELFNBQ0UsTUFDQSxRQUNBLE9BQ0EsT0FDQSxNQUNBLFlBQ0EsY0FDQSxjQUNBLFVBQ0EsTUFDQSxRQUNBLFVBQ0EsUUFDQSxVQUNBLGNBQ0EsU0FDQSxNQUNBLE9BRUEsZ0JBRUs7QUFDUCxTQUFTLG9CQUFvQjtBQUM3QixTQUFTLGNBQWM7QUFDdkIsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyxzQkFBc0I7QUFDL0IsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyxtQkFBbUI7QUFDNUIsU0FFRSxVQUNBLG1CQUNBLG1CQUNLOzs7O0FBR1AsTUFBTSxpQkFDSjtBQUVGLE1BQU0sZ0JBQ0o7QUFFRixNQUFNLG9CQUNKO0FBRUYsTUFBTSxrQkFDSjs7QUFHRixNQUFNLFdBQVc7QUFDakIsTUFBTSxlQUFlO0FBQ3JCLE1BQU0sZUFBZTtBQUNyQixNQUFNLGFBQWE7QUFZbkIsTUFBTSxZQUF3Qjs7O0NBRTVCO0VBQ0UsSUFBSTtFQUNKLEtBQUs7RUFDTCxPQUFPO0VBQ1AsVUFBVTtFQUNWLFlBQVk7RUFDWixjQUFjO0NBQ2hCO0NBQ0E7RUFDRSxJQUFJO0VBQ0osS0FBSztFQUNMLE9BQU87RUFDUCxVQUFVO0VBQ1YsWUFBWTtFQUNaLGNBQWM7Q0FDaEI7Q0FDQTtFQUNFLElBQUk7RUFDSixLQUFLO0VBQ0wsT0FBTztFQUNQLFVBQVU7RUFDVixZQUFZO0VBQ1osY0FBYztDQUNoQjs7O0NBRUE7RUFDRSxJQUFJO0VBQ0osS0FBSztFQUNMLE9BQU87RUFDUCxVQUFVO0VBQ1YsWUFBWTtFQUNaLGNBQWM7Q0FDaEI7Q0FDQTtFQUNFLElBQUk7RUFDSixLQUFLO0VBQ0wsT0FBTztFQUNQLFVBQVU7RUFDVixZQUFZO0VBQ1osY0FBYztDQUNoQjs7O0NBRUE7RUFDRSxJQUFJO0VBQ0osS0FBSztFQUNMLE9BQU87RUFDUCxVQUFVO0VBQ1YsWUFBWTtFQUNaLGNBQWM7Q0FDaEI7Q0FDQTtFQUNFLElBQUk7RUFDSixLQUFLO0VBQ0wsT0FBTztFQUNQLFVBQVU7RUFDVixZQUFZO0VBQ1osY0FBYztDQUNoQjtDQUNBO0VBQ0UsSUFBSTtFQUNKLEtBQUs7RUFDTCxPQUFPO0VBQ1AsVUFBVTtFQUNWLFlBQVk7RUFDWixjQUFjO0NBQ2hCO0FBQ0Y7QUFhQSxNQUFNLGdCQUErQjtDQUNuQztFQUNFLE1BQU07RUFDTixVQUFVO0VBQ1YsYUFBYTtFQUNiLGFBQWE7RUFDYixZQUFZO0NBQ2Q7Q0FDQTtFQUNFLE1BQU07RUFDTixVQUFVO0VBQ1YsYUFBYTtFQUNiLGFBQWE7RUFDYixZQUFZO0NBQ2Q7Q0FDQTtFQUNFLE1BQU07RUFDTixVQUFVO0VBQ1YsYUFBYTtFQUNiLGFBQWE7RUFDYixZQUFZO0NBQ2Q7Q0FDQTtFQUNFLE1BQU07RUFDTixVQUFVO0VBQ1YsYUFBYTtFQUNiLGFBQWE7RUFDYixZQUFZO0NBQ2Q7Q0FDQTtFQUNFLE1BQU07RUFDTixVQUFVO0VBQ1YsYUFBYTtFQUNiLGFBQWE7RUFDYixZQUFZO0NBQ2Q7Q0FDQTtFQUNFLE1BQU07RUFDTixVQUFVO0VBQ1YsYUFBYTtFQUNiLGFBQWE7RUFDYixZQUFZO0NBQ2Q7QUFDRjs7QUFHQSxNQUFNLGVBQWU7Q0FDbkI7RUFDRSxNQUFNO0VBQ04sTUFBTTtFQUNOLFFBQVE7RUFDUixNQUFNO0NBQ1I7Q0FDQTtFQUNFLE1BQU07RUFDTixNQUFNO0VBQ04sUUFBUTtFQUNSLE1BQU07Q0FDUjtDQUNBO0VBQ0UsTUFBTTtFQUNOLE1BQU07RUFDTixRQUFRO0VBQ1IsTUFBTTtDQUNSO0NBQ0E7RUFDRSxNQUFNO0VBQ04sTUFBTTtFQUNOLFFBQVE7RUFDUixNQUFNO0NBQ1I7QUFDRjs7QUFHQSxNQUFNLGlCQUFpQjtDQUNyQjtFQUFFLE9BQU87RUFBMkIsTUFBTTtDQUFTO0NBQ25EO0VBQUUsT0FBTztFQUFRLE1BQU07Q0FBTztDQUM5QjtFQUFFLE9BQU87RUFBUyxNQUFNO0NBQU87Q0FDL0I7RUFBRSxPQUFPO0VBQVksU0FBUztDQUFLO0NBQ25DO0VBQUUsT0FBTztFQUFTLE1BQU07Q0FBSztDQUM3QjtFQUFFLE9BQU87RUFBaUIsTUFBTTtDQUFTO0FBQzNDOztBQUdBLE1BQU0sV0FBVztDQUNmO0VBQ0UsR0FBRztFQUNILEdBQUc7Q0FDTDtDQUNBO0VBQ0UsR0FBRztFQUNILEdBQUc7Q0FDTDtDQUNBO0VBQ0UsR0FBRztFQUNILEdBQUc7Q0FDTDtDQUNBO0VBQ0UsR0FBRztFQUNILEdBQUc7Q0FDTDtDQUNBO0VBQ0UsR0FBRztFQUNILEdBQUc7Q0FDTDtDQUNBO0VBQ0UsR0FBRztFQUNILEdBQUc7Q0FDTDtDQUNBO0VBQ0UsR0FBRztFQUNILEdBQUc7Q0FDTDtBQUNGO0FBRUEsZUFBZSxTQUFTLE1BQU07Q0FDNUIsTUFBTSxDQUFDLFNBQVMsY0FBYyxTQUFTLElBQUk7Q0FDM0MsTUFBTSxDQUFDLGdCQUFnQixxQkFBcUIsU0FBUyxDQUFDO0NBQ3RELE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFTLENBQUM7O0NBRzlDLE1BQU0sQ0FBQyxlQUFlLG9CQUFvQixTQUFTLElBQUk7Q0FDdkQsTUFBTSxjQUFjLE9BQU8sQ0FBQzs7Q0FHNUIsTUFBTSxDQUFDLGtCQUFrQix1QkFBdUIsU0FBeUIsUUFBUTtDQUNqRixNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBc0QsS0FBSztDQUNqRyxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBUyxLQUFLO0NBQ3BELE1BQU0sQ0FBQyxlQUFlLG9CQUFvQixTQUE0RCxDQUFDLENBQUM7Q0FDeEcsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQVMsQ0FBQztDQUNsRCxNQUFNLENBQUMsbUJBQW1CLHdCQUF3QixTQUFTLEtBQUs7Q0FDaEUsTUFBTSxDQUFDLFNBQVMsY0FBYyxTQUF3QixDQUFDO0NBQ3ZELE1BQU0sQ0FBQyxpQkFBaUIsc0JBQXNCLFNBQVMsS0FBSzs7Q0FHNUQsTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQVMsQ0FBQztDQUNoRCxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQVMsQ0FBQztDQUUxQyxNQUFNLFVBQVUsT0FBb0IsSUFBSTtDQUN4QyxNQUFNLGNBQWMsT0FBb0IsSUFBSTtDQUM1QyxNQUFNLFdBQVcsT0FBb0IsSUFBSTs7Q0FHekMsZ0JBQWdCO0VBQ2QsTUFBTSxNQUFNO0VBQ1osSUFBSSxnQkFBcUI7RUFDekIsSUFBSSxJQUFJLE9BQU87R0FDYixnQkFBZ0IsSUFBSSxJQUFJLE1BQU07SUFDNUIsVUFBVTtJQUNWLFNBQVMsTUFBYyxLQUFLLElBQUksR0FBRyxRQUFRLEtBQUssSUFBSSxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDL0QsYUFBYTtJQUNiLGFBQWE7R0FDZixDQUFDO0dBRUQsU0FBUyxJQUFJLE1BQWM7SUFDekIsY0FBYyxJQUFJLElBQUk7SUFDdEIsc0JBQXNCLEdBQUc7R0FDM0I7R0FDQSxzQkFBc0IsR0FBRztFQUMzQjtFQUVBLE1BQU0sUUFBUSxpQkFBaUI7R0FDN0IsV0FBVyxLQUFLO0VBQ2xCLEdBQUcsR0FBRztFQUVOLGFBQWE7R0FDWCxhQUFhLEtBQUs7R0FDbEIsSUFBSSxlQUFlLGNBQWMsUUFBUTtFQUMzQztDQUNGLEdBQUcsQ0FBQyxDQUFDOztDQUdMLGdCQUFnQjtFQUNkLElBQUksVUFBVTtFQUVkLE1BQU0saUJBQWlCO0dBQ3JCLElBQUksQ0FBQyxTQUFTO0lBQ1osT0FBTyw0QkFBNEI7S0FDakMsTUFBTSxjQUFjLFNBQVMsZ0JBQWdCLGVBQWUsT0FBTztLQUNuRSxNQUFNLGdCQUFnQixPQUFPO0tBQzdCLE1BQU0sV0FBVyxjQUFjLElBQUssZ0JBQWdCLGNBQWUsTUFBTTtLQUN6RSxrQkFBa0IsUUFBUTtLQUMxQixjQUFjLGFBQWE7O0tBRzNCLElBQUksZ0JBQWdCLEtBQUs7TUFDdkIsSUFBSSxnQkFBZ0IsWUFBWSxVQUFVLEdBQUc7T0FDM0MsaUJBQWlCLEtBQUs7TUFDeEIsT0FBTyxJQUFJLGdCQUFnQixZQUFZLFVBQVUsR0FBRztPQUNsRCxpQkFBaUIsSUFBSTtNQUN2QjtLQUNGLE9BQU87TUFDTCxpQkFBaUIsSUFBSTtLQUN2QjtLQUNBLFlBQVksVUFBVTs7S0FHdEIsTUFBTSxPQUFPLFFBQVE7S0FDckIsTUFBTSxXQUFXLFlBQVk7S0FDN0IsSUFBSSxRQUFRLFVBQVU7TUFDcEIsTUFBTSxhQUFhLEtBQUssc0JBQXNCLENBQUMsQ0FBQztNQUNoRCxNQUFNLGNBQWMsU0FBUyxzQkFBc0IsQ0FBQyxDQUFDO01BQ3JELE1BQU0sZUFBZSxPQUFPO01BQzVCLE1BQU0sWUFBWSxhQUFhO01BQy9CLE1BQU0saUJBQWlCLGNBQWMsZUFBZTtNQUNwRCxxQkFBcUIsYUFBYSxjQUFjO0tBQ2xEO0tBRUEsVUFBVTtJQUNaLENBQUM7SUFDRCxVQUFVO0dBQ1o7RUFDRjtFQUVBLE9BQU8saUJBQWlCLFVBQVUsVUFBVSxFQUFFLFNBQVMsS0FBSyxDQUFDO0VBQzdELGFBQWEsT0FBTyxvQkFBb0IsVUFBVSxRQUFRO0NBQzVELEdBQUcsQ0FBQyxDQUFDOztDQUdMLGdCQUFnQjtFQUNkLE1BQU0sV0FBVyxJQUFJLHNCQUNsQixDQUFDLFdBQVc7R0FDWCxJQUFJLE1BQU0sZ0JBQWdCO0lBQ3hCLElBQUksVUFBVTtJQUNkLE1BQU0sV0FBVyxrQkFBa0I7S0FDakMsV0FBVztLQUNYLElBQUksV0FBVyxHQUFLO01BQ2xCLGVBQWUsQ0FBRztNQUNsQixjQUFjLFFBQVE7S0FDeEIsT0FBTztNQUNMLGVBQWUsT0FBTyxRQUFRLFFBQVEsQ0FBQyxDQUFDLENBQUM7S0FDM0M7SUFDRixHQUFHLEVBQUU7SUFFTCxLQUFLLElBQUksSUFBSSxHQUFHLEtBQUssR0FBRyxLQUFLO0tBQzNCLGlCQUFpQjtNQUNmLFlBQVksQ0FBQztLQUNmLEdBQUcsSUFBSSxHQUFHO0lBQ1o7SUFDQSxTQUFTLFdBQVc7R0FDdEI7RUFDRixHQUNBLEVBQUUsV0FBVyxHQUFJLENBQ25CO0VBRUEsSUFBSSxTQUFTLFNBQVM7R0FDcEIsU0FBUyxRQUFRLFNBQVMsT0FBTztFQUNuQztFQUNBLGFBQWEsU0FBUyxXQUFXO0NBQ25DLEdBQUcsQ0FBQyxDQUFDOztDQUdMLE1BQU0sZ0JBQ0osZ0JBQWdCLFFBQVEsWUFBWSxVQUFVLFFBQVEsTUFBTSxFQUFFLGFBQWEsV0FBVztDQUV4RixNQUFNLGlCQUFpQixTQUFtQjtFQUN4QyxNQUFNLFNBQVMsY0FBYyxLQUFLLE9BQU87R0FDdkMsS0FBSyxFQUFFO0dBQ1AsT0FBTyxFQUFFO0dBQ1QsUUFBUSxFQUFFO0VBQ1osRUFBRTtFQUNGLE1BQU0sUUFBUSxjQUFjLFdBQVcsTUFBTSxFQUFFLE9BQU8sS0FBSyxFQUFFO0VBQzdELGlCQUFpQixNQUFNO0VBQ3ZCLGdCQUFnQixTQUFTLElBQUksUUFBUSxDQUFDO0VBQ3RDLGVBQWUsSUFBSTtDQUNyQjtDQUVBLE1BQU0sdUJBQXVCLGFBQXlCLFFBQWdCO0VBQ3BFLE1BQU0sU0FBUyxZQUFZLEtBQUssT0FBTztHQUNyQyxLQUFLLEVBQUU7R0FDUCxPQUFPLEVBQUU7R0FDVCxRQUFRLEVBQUU7RUFDWixFQUFFO0VBQ0YsaUJBQWlCLE1BQU07RUFDdkIsZ0JBQWdCLEdBQUc7RUFDbkIsZUFBZSxJQUFJO0NBQ3JCO0NBRUEsTUFBTSxvQkFBb0I7RUFDeEIsT0FBTyxTQUFTO0dBQUUsS0FBSztHQUFHLFVBQVU7RUFBUyxDQUFDO0NBQ2hEOztDQUdBLE1BQU0sb0JBQW9CO0VBQ3hCLE9BQU87R0FDTCxNQUFNO0dBQ04sS0FBSztFQUNQO0VBQ0EsUUFBUTtHQUNOLE1BQU07R0FDTixLQUFLO0VBQ1A7RUFDQSxRQUFRO0dBQ04sTUFBTTtHQUNOLEtBQUs7RUFDUDtDQUNGLEVBQUU7Q0FFRixPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FFRSx3QkFBQyxPQUFEO0lBQ0UsV0FBVyxrSkFDVCxVQUFVLGtCQUFrQjtJQUU5QixlQUFhLENBQUM7Y0FFZCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0Usd0JBQUMsUUFBRDtPQUFRLE1BQU07T0FBSSxXQUFVO01BQWlEOzs7OztNQUM3RSx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBOEU7TUFFeEY7Ozs7O01BQ04sd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQW1FO01BRTdFOzs7OztLQUNIOzs7Ozs7R0FDRjs7Ozs7R0FHTCx3QkFBQyxPQUFEO0lBQ0UsV0FBVTtJQUNWLE9BQU8sRUFBRSxPQUFPLEdBQUcsZUFBZSxHQUFHO0lBQ3JDLGVBQVk7R0FDYjs7Ozs7R0FHRCx3QkFBQyxVQUFEO0lBQ0UsV0FBVyxnSkFDVCxnQkFBZ0Isa0JBQWtCO2NBR3BDLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFFRSx3QkFBQyxLQUFEO09BQ0UsTUFBSztPQUNMLFdBQVU7T0FDVixjQUFXO2lCQUhiLENBS0Usd0JBQUMsUUFBRDtRQUFRLE1BQU07UUFBSSxXQUFVO09BQTJEOzs7O2lCQUN2Rix3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBa0Y7T0FFNUY7Ozs7ZUFDTDs7Ozs7O01BR0gsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxLQUFEO1NBQUcsTUFBSztTQUFTLFdBQVU7bUJBQTJEO1FBRW5GOzs7OztRQUNILHdCQUFDLEtBQUQ7U0FBRyxNQUFLO1NBQVEsV0FBVTttQkFBMkQ7UUFFbEY7Ozs7O1FBQ0gsd0JBQUMsS0FBRDtTQUFHLE1BQUs7U0FBVyxXQUFVO21CQUEyRDtRQUVyRjs7Ozs7UUFDSCx3QkFBQyxLQUFEO1NBQUcsTUFBSztTQUFTLFdBQVU7bUJBQTJEO1FBRW5GOzs7OztRQUNILHdCQUFDLEtBQUQ7U0FBRyxNQUFLO1NBQVcsV0FBVTttQkFBMkQ7UUFFckY7Ozs7O1FBQ0gsd0JBQUMsS0FBRDtTQUFHLE1BQUs7U0FBVyxXQUFVO21CQUEyRDtRQUVyRjs7Ozs7UUFDSCx3QkFBQyxLQUFEO1NBQUcsTUFBSztTQUFXLFdBQVU7bUJBQTJEO1FBRXJGOzs7OztRQUNILHdCQUFDLEtBQUQ7U0FBRyxNQUFLO1NBQU8sV0FBVTttQkFBMkQ7UUFFakY7Ozs7O1FBQ0gsd0JBQUMsS0FBRDtTQUFHLE1BQUs7U0FBWSxXQUFVO21CQUEyRDtRQUV0Rjs7Ozs7T0FDQTs7Ozs7O01BR0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQ2Isd0JBQUMsS0FBRDtRQUNFLE1BQU07UUFDTixRQUFPO1FBQ1AsS0FBSTtRQUNKLFdBQVU7UUFDVixjQUFXO2tCQUxiLENBT0Usd0JBQUMsUUFBRCxFQUFNLFdBQVUsV0FBWTs7OztrQkFDNUIsd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQWhCLENBQ0Usd0JBQUMsUUFBRCxZQUFNLGFBQWdCOzs7O21CQUN0Qix3QkFBQyxjQUFELEVBQWMsV0FBVSxvQkFBcUI7Ozs7aUJBQ3pDOzs7OztnQkFDTDs7Ozs7O01BQ0E7Ozs7O0tBQ0Y7Ozs7OztHQUNDOzs7OztHQUdSLHdCQUFDLFdBQUQ7SUFDRSxLQUFLO0lBQ0wsSUFBRztJQUNILFdBQVU7Y0FIWjtLQU1FLHdCQUFDLE9BQUQ7TUFDRSxXQUFVO01BQ1YsT0FBTyxFQUFFLFdBQVcsbUJBQW1CLGFBQWEsSUFBSyxLQUFLO01BQzlELGVBQVk7Z0JBQ2I7S0FFSTs7Ozs7S0FHTCx3QkFBQyxPQUFEO01BQ0UsV0FBVTtNQUNWLE9BQU8sRUFBRSxXQUFXLGNBQWMsYUFBYSxDQUFDLElBQUssbUJBQW1CO01BQ3hFLGVBQVk7Z0JBRVosd0JBQUMsbUJBQUQsRUFBbUIsTUFBTSxHQUFLOzs7OztLQUMzQjs7Ozs7S0FJTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNiLHdCQUFDLE9BQUQ7UUFDRSxLQUFJO1FBQ0osS0FBSTtRQUNKLFNBQVE7UUFDUixXQUFVO1FBQ1YsT0FBTyxFQUFFLGdCQUFnQixhQUFhO09BQ3ZDOzs7OztNQUNFOzs7O2dCQUdMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNiLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBRUUsd0JBQUMsT0FBRCxFQUFLLFdBQVUsMkVBQTRFOzs7OztTQUczRix3QkFBQyxPQUFEO1VBQ0UsU0FBUTtVQUNSLFdBQVU7VUFDVixPQUFPLEVBQUUsbUJBQW1CLEdBQUcsS0FBSyxJQUFJLEdBQUcsS0FBSyxpQkFBaUIsRUFBRyxFQUFFLEdBQUc7b0JBSDNFLENBS0Usd0JBQUMsUUFBRDtXQUNFLElBQUc7V0FDSCxHQUFFO1dBQ0YsTUFBSztVQUNOOzs7O29CQUNELHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUNkLHdCQUFDLFlBQUQ7WUFBVSxNQUFLO1lBQWtCLGFBQVk7c0JBQUs7V0FFeEM7Ozs7O1VBQ047Ozs7a0JBQ0g7Ozs7OztTQUdMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUNiLHdCQUFDLFFBQUQ7V0FBUSxNQUFNO1dBQUksV0FBVTtVQUFxRDs7Ozs7U0FDOUU7Ozs7O1FBQ0Y7Ozs7OztNQUNGOzs7O2NBQ0Y7Ozs7OztLQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BRUUsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxRQUFELFlBQU0sUUFBVzs7Ozs7U0FDakIsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWlCO1NBQU87Ozs7O1NBQ3hDLHdCQUFDLEtBQUQ7VUFDRSxNQUFNO1VBQ04sUUFBTztVQUNQLEtBQUk7VUFDSixXQUFVO29CQUpaLENBTUUsd0JBQUMsTUFBRCxFQUFNLFdBQVUsd0NBQXlDOzs7O29CQUN6RCx3QkFBQyxRQUFELFlBQU0sYUFBZ0I7Ozs7a0JBQ3JCOzs7Ozs7UUFDQTs7Ozs7O09BR0wsd0JBQUMsZ0JBQUQ7UUFBZ0IsSUFBRztRQUFLLE9BQU87UUFBSyxXQUFVO2tCQUFnRztPQUU5SDs7Ozs7T0FHaEIsd0JBQUMsZ0JBQUQ7UUFBZ0IsSUFBRztRQUFJLE9BQU87UUFBSyxXQUFVO2tCQUFxRTtPQUVsRzs7Ozs7T0FHaEIsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxLQUFEO1NBQ0UsTUFBTTtTQUNOLFFBQU87U0FDUCxLQUFJO1NBQ0osV0FBVTtTQUNWLGNBQVc7bUJBTGI7VUFPRSx3QkFBQyxRQUFELEVBQU0sV0FBVSxXQUFZOzs7OztVQUU1Qix3QkFBQyxRQUFELEVBQU0sV0FBVSwwSEFBMkg7Ozs7O1VBQzNJLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUFoQixDQUNFLHdCQUFDLFFBQUQsWUFBTSxvQkFBdUI7Ozs7cUJBQzdCLHdCQUFDLGNBQUQsRUFBYyxXQUFVLG9CQUFxQjs7OzttQkFDekM7Ozs7OztTQUNMOzs7OztrQkFFSCx3QkFBQyxLQUFEO1NBQ0UsTUFBSztTQUNMLFdBQVU7bUJBRlosQ0FJRSx3QkFBQyxRQUFELFlBQU0sZ0JBQW1COzs7O21CQUN6Qix3QkFBQyxjQUFELEVBQWMsV0FBVSxvQkFBcUI7Ozs7aUJBQzVDOzs7OztnQkFDQTs7Ozs7O01BQ0Y7Ozs7OztLQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsT0FBRDtRQUNFLFdBQVU7UUFDVixPQUFPLEVBQUUsT0FBTyxHQUFHLEtBQUssSUFBSSxLQUFLLEtBQUssSUFBSSxHQUFHLGlCQUFpQixHQUFHLENBQUMsRUFBRSxHQUFHO09BQ3hFOzs7OztPQUNELHdCQUFDLE9BQUQ7UUFDRSxXQUFVO1FBQ1YsT0FBTyxFQUFFLE9BQU8sR0FBRyxLQUFLLElBQUksR0FBRyxNQUFNLEtBQUssSUFBSSxLQUFLLEtBQUssSUFBSSxHQUFHLGlCQUFpQixHQUFHLENBQUMsQ0FBQyxFQUFFLEdBQUc7T0FDM0Y7Ozs7O09BQ0Qsd0JBQUMsT0FBRDtRQUNFLFdBQVU7UUFDVixPQUFPO1NBQ0wsTUFBTSxHQUFHLEtBQUssSUFBSSxJQUFJLEtBQUssSUFBSSxHQUFHLGlCQUFpQixHQUFHLENBQUMsRUFBRTtTQUN6RCxXQUFXLGdDQUFnQyxLQUFLLElBQUksYUFBYSxHQUFJLElBQUksS0FBSyxHQUFHO1FBQ25GO2tCQUVBLHdCQUFDLFVBQUQsRUFBVSxXQUFVLFVBQVc7Ozs7O09BQzVCOzs7OztNQUNGOzs7Ozs7SUFDRTs7Ozs7O0dBR1Qsd0JBQUMsV0FBRDtJQUFTLFdBQVU7Y0FBbkIsQ0FFRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNaLENBQUMsR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLE1BQ3JCLHdCQUFDLFFBQUQ7TUFBYyxXQUFVO2dCQUF4QixDQUNFLHdCQUFDLFFBQUQsWUFBTSxxQ0FBd0M7Ozs7Z0JBQzlDLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFtQztNQUFPOzs7O2NBQ3REO1FBSEs7Ozs7WUFHTCxDQUNQO0lBQ0U7Ozs7Y0FHTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNaLENBQUMsR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLE1BQ3JCLHdCQUFDLFFBQUQ7TUFBYyxXQUFVO2dCQUF4QixDQUNFLHdCQUFDLFFBQUQsWUFBTSxtQ0FBc0M7Ozs7Z0JBQzVDLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFtQztNQUFPOzs7O2NBQ3REO1FBSEs7Ozs7WUFHTCxDQUNQO0lBQ0U7Ozs7WUFDRTs7Ozs7O0dBR1Qsd0JBQUMsV0FBRDtJQUFTLElBQUc7SUFBTyxXQUFVO2NBQTdCLENBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQTJCO09BQVE7Ozs7O09BQ25ELHdCQUFDLFFBQUQsWUFBTSxJQUFPOzs7OztPQUNiLHdCQUFDLFFBQUQsWUFBTSxTQUFZOzs7OztNQUNmOzs7OztlQUNMLHdCQUFDLGdCQUFEO01BQWdCLElBQUc7TUFBSyxXQUFVO2dCQUE2RDtLQUUvRTs7OzthQUNiOzs7OztjQUdMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ1osZUFBZSxLQUFLLE1BQU0sUUFBUTtNQUNqQyxNQUFNLE9BQU8sS0FBSztNQUNsQixPQUNFLHdCQUFDLE9BQUQ7T0FFRSxXQUFVO2lCQUZaLENBSUUsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ1osS0FBSyxVQUNKLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUF5RjtRQUVuRzs7OzttQkFDSixPQUNGLHdCQUFDLE1BQUQsRUFBTSxXQUFVLGlFQUFrRTs7OzttQkFDaEY7T0FDRDs7OztpQkFFTCx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFDYixLQUFLO09BQ0Y7Ozs7ZUFDSDtTQWhCRTs7OzthQWdCRjtLQUVULENBQUM7SUFDRTs7OztZQUNFOzs7Ozs7R0FHVCx3QkFBQyxXQUFEO0lBQ0UsS0FBSztJQUNMLElBQUc7SUFDSCxXQUFVO2NBSFo7S0FNRSx3QkFBQyxPQUFEO01BQ0UsV0FBVTtNQUNWLE9BQU8sRUFBRSxXQUFXLGVBQWUsYUFBYSxRQUFRLElBQUssS0FBSztNQUNsRSxlQUFZO2dCQUNiO0tBRUk7Ozs7O0tBR0wsd0JBQUMsT0FBRDtNQUNFLFdBQVU7TUFDVixPQUFPLEVBQUUsV0FBVyxlQUFlLGFBQWEsUUFBUSxDQUFDLEdBQUksS0FBSztNQUNsRSxlQUFZO2dCQUVaLHdCQUFDLFVBQUQsRUFBVSxNQUFNLEdBQUs7Ozs7O0tBQ2xCOzs7OztLQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNiLHdCQUFDLGNBQUQ7T0FBYyxNQUFLO09BQVEsV0FBVTtNQUFpQjs7Ozs7S0FDbkQ7Ozs7O0tBRUwsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUEyQjtTQUFROzs7OztTQUNuRCx3QkFBQyxRQUFELFlBQU0sSUFBTzs7Ozs7U0FDYix3QkFBQyxRQUFELFlBQU0sUUFBVzs7Ozs7UUFDZDs7Ozs7O09BRUwsd0JBQUMsZ0JBQUQ7UUFBZ0IsSUFBRztRQUFLLFdBQVU7a0JBQWtFO09BRXBGOzs7OztPQUVoQix3QkFBQyxnQkFBRDtRQUFnQixJQUFHO1FBQUksT0FBTztRQUFLLFdBQVU7a0JBQW9FO09BR2pHOzs7OztPQUdoQix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDWjtTQUFDO1NBQVk7U0FBZTtRQUFVLENBQUMsQ0FBQyxLQUFLLE1BQU0sUUFDbEQsd0JBQUMsT0FBRDtTQUFlLFdBQVU7bUJBQXpCLENBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQ2I7U0FDRzs7OzttQkFDTix3QkFBQyxPQUFELEVBQUssV0FBVSxrRkFBbUY7Ozs7aUJBQy9GO1dBTEs7Ozs7ZUFLTCxDQUNOO09BQ0U7Ozs7O09BR0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FFRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZjtVQUNFLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0Usd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQ2IsWUFBWSxRQUFRLENBQUM7V0FDbEI7Ozs7cUJBQ04sd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQTRDO1dBQVk7Ozs7bUJBQ3JFOzs7Ozs7VUFDTCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFDWjtZQUFDO1lBQUc7WUFBRztZQUFHO1lBQUc7V0FBQyxDQUFDLENBQUMsS0FBSyxZQUNwQix3QkFBQyxNQUFELEVBRUUsV0FBVywwQ0FDVCxXQUFXLFdBQ1Asa0NBQ0Esa0JBRVAsR0FOTTs7OztrQkFNTixDQUNGO1VBQ0U7Ozs7O1VBQ0wsd0JBQUMsS0FBRDtXQUFHLFdBQVU7cUJBQThDO1VBRXhEOzs7OztTQUNBOzs7OztrQkFHTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBc0U7U0FFaEY7Ozs7bUJBQ04sd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQXlEO1NBRW5FOzs7O2lCQUNIOzs7O21CQUNMLHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUF3QztTQUVsRDs7OztpQkFDQTs7Ozs7Z0JBQ0Y7Ozs7OztNQUNGOzs7Ozs7SUFDRTs7Ozs7O0dBR1Qsd0JBQUMsV0FBRDtJQUFTLElBQUc7SUFBVSxXQUFVO2NBQWhDO0tBRUUsd0JBQUMsT0FBRDtNQUNFLFdBQVU7TUFDVixPQUFPLEVBQUUsV0FBVyxlQUFlLGFBQWEsUUFBUSxJQUFLLEtBQUs7TUFDbEUsZUFBWTtnQkFDYjtLQUVJOzs7OztLQUNMLHdCQUFDLE9BQUQ7TUFDRSxXQUFVO01BQ1YsT0FBTyxFQUFFLFdBQVcsZUFBZSxhQUFhLFFBQVEsQ0FBQyxHQUFJLEtBQUs7TUFDbEUsZUFBWTtnQkFDYjtLQUVJOzs7OztLQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNiLHdCQUFDLGNBQUQ7T0FBYyxNQUFLO09BQU8sV0FBVTtNQUFpQjs7Ozs7S0FDbEQ7Ozs7O0tBRUwsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUEyQjtTQUFROzs7OztTQUNuRCx3QkFBQyxRQUFELFlBQU0sSUFBTzs7Ozs7U0FDYix3QkFBQyxRQUFELFlBQU0sVUFBYTs7Ozs7UUFDaEI7Ozs7OztPQUVMLHdCQUFDLGdCQUFEO1FBQWdCLElBQUc7UUFBSyxXQUFVO2tCQUFrRTtPQUVwRjs7Ozs7T0FHaEIsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FFRSx3QkFBQyxnQkFBRDtVQUFnQixPQUFPO1VBQUcsV0FBVTtvQkFDbEMsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWY7WUFDQSx3QkFBQyxPQUFELEVBQUssV0FBVSx3REFBeUQ7Ozs7O1lBRXhFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxPQUFEO2FBQUssV0FBVTt1QkFBZjtjQUNFLHdCQUFDLE9BQUQ7ZUFDRSxLQUFJO2VBQ0osS0FBSTtlQUNKLFNBQVE7ZUFDUixXQUFVO2NBQ1g7Ozs7O2NBQ0Qsd0JBQUMsT0FBRDtlQUFLLFdBQVU7eUJBQWlHO2NBRTNHOzs7OztjQUNMLHdCQUFDLE9BQUQ7ZUFBSyxXQUFVO3lCQUFmO2dCQUNFLHdCQUFDLE1BQUQsRUFBTSxXQUFVLDRDQUE2Qzs7Ozs7Z0JBQzdELHdCQUFDLFFBQUQsWUFBTSxNQUFTOzs7OztnQkFDZix3QkFBQyxRQUFEO2lCQUFNLFdBQVU7MkJBQTRCO2dCQUFnQjs7Ozs7ZUFDekQ7Ozs7OzthQUNGOzs7OztzQkFFTCx3QkFBQyxPQUFEO2FBQUssV0FBVTt1QkFBZjtjQUNFLHdCQUFDLE1BQUQ7ZUFBSSxXQUFVO3lCQUFrQztjQUF1Qjs7Ozs7Y0FDdkUsd0JBQUMsUUFBRDtlQUFNLFdBQVU7eUJBQXVFO2NBRWpGOzs7OztjQUNOLHdCQUFDLEtBQUQ7ZUFBRyxXQUFVO3lCQUE2QztjQUl2RDs7Ozs7Y0FHSCx3QkFBQyxPQUFEO2VBQUssV0FBVTt5QkFBZixDQUNFLHdCQUFDLFFBQUQ7Z0JBQU0sV0FBVTswQkFBMkQ7ZUFFckU7Ozs7eUJBQ04sd0JBQUMsT0FBRDtnQkFBSyxXQUFVOzBCQUNaLFVBQVUsUUFBUSxNQUFNLEVBQUUsYUFBYSxZQUFZLENBQUMsQ0FBQyxLQUFLLE1BQU0sUUFDL0Qsd0JBQUMsVUFBRDtpQkFFRSxlQUNFLG9CQUNFLFVBQVUsUUFBUSxNQUFNLEVBQUUsYUFBYSxZQUFZLEdBQ25ELEdBQ0Y7aUJBRUYsV0FBVTtpQkFDVixjQUFZLG1CQUFtQixLQUFLOzJCQUVwQyx3QkFBQyxhQUFEO2tCQUNFLEtBQUssS0FBSztrQkFDVixLQUFLLEtBQUs7a0JBQ1Ysb0JBQW1CO2tCQUNuQixhQUFhO2lCQUNkOzs7OztnQkFDSyxHQWhCRDs7Ozt1QkFnQkMsQ0FDVDtlQUNFOzs7O3VCQUNGOzs7Ozs7YUFDRjs7Ozs7b0JBQ0Y7Ozs7O1lBRUwsd0JBQUMsT0FBRDthQUFLLFdBQVU7dUJBQ2Isd0JBQUMsS0FBRDtjQUNFLE1BQU07Y0FDTixRQUFPO2NBQ1AsS0FBSTtjQUNKLFdBQVU7Y0FDVixjQUFXO3dCQUxiLENBT0Usd0JBQUMsUUFBRCxFQUFNLFdBQVUsV0FBWTs7Ozt3QkFDNUIsd0JBQUMsUUFBRDtlQUFNLFdBQVU7eUJBQWhCLENBQ0Usd0JBQUMsUUFBRCxZQUFNLDBCQUE2Qjs7Ozt5QkFDbkMsd0JBQUMsY0FBRCxFQUFjLFdBQVUsb0JBQXFCOzs7O3VCQUN6Qzs7Ozs7c0JBQ0w7Ozs7OztZQUNBOzs7OztXQUNGOzs7Ozs7U0FDUzs7Ozs7U0FHaEIsd0JBQUMsZ0JBQUQ7VUFBZ0IsT0FBTztVQUFLLFdBQVU7b0JBQ3BDLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmO1lBQ0Usd0JBQUMsT0FBRCxFQUFLLFdBQVUsd0RBQXlEOzs7OztZQUV4RSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsT0FBRDthQUFLLFdBQVU7dUJBQWYsQ0FDRSx3QkFBQyxPQUFEO2NBQ0UsS0FBSTtjQUNKLEtBQUk7Y0FDSixTQUFRO2NBQ1IsV0FBVTthQUNYOzs7O3VCQUNELHdCQUFDLE9BQUQ7Y0FBSyxXQUFVO3dCQUFpRzthQUUzRzs7OztxQkFDRjs7Ozs7c0JBRUwsd0JBQUMsT0FBRDthQUFLLFdBQVU7dUJBQWY7Y0FDRSx3QkFBQyxNQUFEO2VBQUksV0FBVTt5QkFBa0M7Y0FBcUI7Ozs7O2NBQ3JFLHdCQUFDLFFBQUQ7ZUFBTSxXQUFVO3lCQUF1RTtjQUVqRjs7Ozs7Y0FDTix3QkFBQyxLQUFEO2VBQUcsV0FBVTt5QkFBNkM7Y0FHdkQ7Ozs7O2NBR0gsd0JBQUMsT0FBRDtlQUFLLFdBQVU7eUJBQWYsQ0FDRSx3QkFBQyxRQUFEO2dCQUFNLFdBQVU7MEJBQTJEO2VBRXJFOzs7O3lCQUNOLHdCQUFDLE9BQUQ7Z0JBQUssV0FBVTswQkFDWixVQUFVLFFBQVEsTUFBTSxFQUFFLGFBQWEsU0FBUyxDQUFDLENBQUMsS0FBSyxNQUFNLFFBQzVELHdCQUFDLFVBQUQ7aUJBRUUsZUFDRSxvQkFDRSxVQUFVLFFBQVEsTUFBTSxFQUFFLGFBQWEsU0FBUyxHQUNoRCxHQUNGO2lCQUVGLFdBQVU7aUJBQ1YsY0FBWSxtQkFBbUIsS0FBSzsyQkFFcEMsd0JBQUMsYUFBRDtrQkFDRSxLQUFLLEtBQUs7a0JBQ1YsS0FBSyxLQUFLO2tCQUNWLG9CQUFtQjtrQkFDbkIsYUFBYTtrQkFDYixPQUFPLEVBQUUsZ0JBQWdCLEtBQUssZ0JBQWdCLFNBQVM7aUJBQ3hEOzs7OztnQkFDSyxHQWpCRDs7Ozt1QkFpQkMsQ0FDVDtlQUNFOzs7O3VCQUNGOzs7Ozs7YUFDRjs7Ozs7b0JBQ0Y7Ozs7O1lBRUwsd0JBQUMsT0FBRDthQUFLLFdBQVU7dUJBQ2Isd0JBQUMsS0FBRDtjQUNFLE1BQU07Y0FDTixRQUFPO2NBQ1AsS0FBSTtjQUNKLFdBQVU7Y0FDVixjQUFXO3dCQUxiLENBT0Usd0JBQUMsUUFBRCxFQUFNLFdBQVUsV0FBWTs7Ozt3QkFDNUIsd0JBQUMsUUFBRDtlQUFNLFdBQVU7eUJBQWhCLENBQ0Usd0JBQUMsUUFBRCxZQUFNLHVCQUEwQjs7Ozt5QkFDaEMsd0JBQUMsY0FBRCxFQUFjLFdBQVUsb0JBQXFCOzs7O3VCQUN6Qzs7Ozs7c0JBQ0w7Ozs7OztZQUNBOzs7OztXQUNGOzs7Ozs7U0FDUzs7Ozs7U0FHaEIsd0JBQUMsZ0JBQUQ7VUFBZ0IsT0FBTztVQUFLLFdBQVU7b0JBQ3BDLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmO1lBQ0Usd0JBQUMsT0FBRCxFQUFLLFdBQVUsd0RBQXlEOzs7OztZQUV4RSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsT0FBRDthQUFLLFdBQVU7dUJBQWY7Y0FDRSx3QkFBQyxPQUFEO2VBQ0UsS0FBSTtlQUNKLEtBQUk7ZUFDSixTQUFRO2VBQ1IsV0FBVTtjQUNYOzs7OztjQUNELHdCQUFDLE9BQUQ7ZUFBSyxXQUFVO3lCQUFxRztjQUUvRzs7Ozs7Y0FDTCx3QkFBQyxPQUFEO2VBQUssV0FBVTt5QkFBNEY7Y0FFdEc7Ozs7O2FBQ0Y7Ozs7O3NCQUVMLHdCQUFDLE9BQUQ7YUFBSyxXQUFVO3VCQUFmO2NBQ0Usd0JBQUMsTUFBRDtlQUFJLFdBQVU7eUJBQWtDO2NBQXFCOzs7OztjQUNyRSx3QkFBQyxRQUFEO2VBQU0sV0FBVTt5QkFBdUU7Y0FFakY7Ozs7O2NBQ04sd0JBQUMsS0FBRDtlQUFHLFdBQVU7eUJBQTZDO2NBS3ZEOzs7OztjQUdILHdCQUFDLE9BQUQ7ZUFBSyxXQUFVO3lCQUFmLENBQ0Usd0JBQUMsUUFBRDtnQkFBTSxXQUFVOzBCQUEyRDtlQUVyRTs7Ozt5QkFDTix3QkFBQyxPQUFEO2dCQUFLLFdBQVU7MEJBQ1osVUFBVSxRQUFRLE1BQU0sRUFBRSxhQUFhLFFBQVEsQ0FBQyxDQUFDLEtBQUssTUFBTSxRQUMzRCx3QkFBQyxVQUFEO2lCQUVFLGVBQ0Usb0JBQ0UsVUFBVSxRQUFRLE1BQU0sRUFBRSxhQUFhLFFBQVEsR0FDL0MsR0FDRjtpQkFFRixXQUFVO2lCQUNWLGNBQVksbUJBQW1CLEtBQUs7MkJBRXBDLHdCQUFDLGFBQUQ7a0JBQ0UsS0FBSyxLQUFLO2tCQUNWLEtBQUssS0FBSztrQkFDVixvQkFBbUI7a0JBQ25CLGFBQWE7aUJBQ2Q7Ozs7O2dCQUNLLEdBaEJEOzs7O3VCQWdCQyxDQUNUO2VBQ0U7Ozs7dUJBQ0Y7Ozs7OzthQUNGOzs7OztvQkFDRjs7Ozs7WUFFTCx3QkFBQyxPQUFEO2FBQUssV0FBVTt1QkFDYix3QkFBQyxLQUFEO2NBQ0UsTUFBTTtjQUNOLFFBQU87Y0FDUCxLQUFJO2NBQ0osV0FBVTtjQUNWLGNBQVc7d0JBTGIsQ0FPRSx3QkFBQyxRQUFELEVBQU0sV0FBVSxXQUFZOzs7O3dCQUM1Qix3QkFBQyxRQUFEO2VBQU0sV0FBVTt5QkFBaEIsQ0FDRSx3QkFBQyxRQUFELFlBQU0sdUJBQTBCOzs7O3lCQUNoQyx3QkFBQyxjQUFELEVBQWMsV0FBVSxvQkFBcUI7Ozs7dUJBQ3pDOzs7OztzQkFDTDs7Ozs7O1lBQ0E7Ozs7O1dBQ0Y7Ozs7OztTQUNTOzs7OztRQUNYOzs7Ozs7TUFDRjs7Ozs7O0lBQ0U7Ozs7OztHQUdULHdCQUFDLFdBQUQ7SUFBUyxJQUFHO0lBQVEsV0FBVTtjQUE5QjtLQUVFLHdCQUFDLE9BQUQ7TUFDRSxXQUFVO01BQ1YsT0FBTyxFQUFFLFdBQVcsZUFBZSxhQUFhLFFBQVEsSUFBSyxLQUFLO01BQ2xFLGVBQVk7Z0JBQ2I7S0FFSTs7Ozs7S0FDTCx3QkFBQyxPQUFEO01BQ0UsV0FBVTtNQUNWLE9BQU8sRUFBRSxXQUFXLGVBQWUsYUFBYSxPQUFRLENBQUMsR0FBSSxLQUFLO01BQ2xFLGVBQVk7Z0JBQ2I7S0FFSTs7Ozs7S0FHTCx3QkFBQyxPQUFEO01BQ0UsV0FBVTtNQUNWLE9BQU8sRUFBRSxXQUFXLGVBQWUsYUFBYSxRQUFRLENBQUMsR0FBSSxLQUFLO01BQ2xFLGVBQVk7Z0JBRVosd0JBQUMsYUFBRCxFQUFhLE1BQU0sR0FBSzs7Ozs7S0FDckI7Ozs7O0tBRUwsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUEyQjtTQUFROzs7OztTQUNuRCx3QkFBQyxRQUFELFlBQU0sSUFBTzs7Ozs7U0FDYix3QkFBQyxRQUFELFlBQU0sWUFBZTs7Ozs7UUFDbEI7Ozs7OztPQUVMLHdCQUFDLGdCQUFEO1FBQWdCLElBQUc7UUFBSyxXQUFVO2tCQUFrRTtPQUVwRjs7Ozs7T0FHaEIsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ1o7U0FDQztVQUFFLElBQUk7VUFBTyxPQUFPO1NBQWE7U0FDakM7VUFBRSxJQUFJO1VBQWMsT0FBTztTQUFZO1NBQ3ZDO1VBQUUsSUFBSTtVQUFXLE9BQU87U0FBUztTQUNqQztVQUFFLElBQUk7VUFBVSxPQUFPO1NBQVM7UUFDbEMsQ0FBQyxDQUFDLEtBQUssU0FDTCx3QkFBQyxVQUFEO1NBRUUsZUFBZSxlQUFlLEtBQUssRUFBUztTQUM1QyxXQUFXLHFNQUNULGdCQUFnQixLQUFLLEtBQ2pCLGtDQUNBO21CQUdMLEtBQUs7UUFDQSxHQVRELEtBQUs7Ozs7ZUFTSixDQUNUO09BQ0U7Ozs7O09BR0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ1osY0FBYyxLQUFLLE1BQU0sUUFBUTtTQUNoQyxNQUFNLFlBQVksY0FBYyxTQUFTLE1BQU0sS0FBSyxRQUFRLGNBQWMsU0FBUztTQUNuRixPQUNFLHdCQUFDLE9BQUQ7VUFFRSxlQUFlLGNBQWMsSUFBSTtVQUNqQyxXQUFXLDRNQUNULFlBQVksNkJBQTZCO1VBRTNDLE1BQUs7VUFDTCxVQUFVO1VBQ1YsY0FBWSxtQkFBbUIsS0FBSztVQUNwQyxZQUFZLE1BQU07V0FDaEIsSUFBSSxFQUFFLFFBQVEsV0FBVyxFQUFFLFFBQVEsS0FBSyxjQUFjLElBQUk7VUFDNUQ7b0JBWEYsQ0FhRSx3QkFBQyxhQUFEO1dBQ0UsS0FBSyxLQUFLO1dBQ1YsS0FBSyxLQUFLO1dBQ1Ysb0JBQW1CO1dBQ25CLFdBQVU7V0FDVixPQUFPLEVBQUUsZ0JBQWdCLEtBQUssZ0JBQWdCLFNBQVM7VUFDeEQ7Ozs7b0JBQ0Qsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBbUMsS0FBSztXQUFZOzs7O3FCQUNwRSx3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFDYixLQUFLO1dBQ0Y7Ozs7bUJBQ0g7Ozs7O2tCQUNGO1lBekJFLEtBQUs7Ozs7Z0JBeUJQO1FBRVQsQ0FBQztPQUNFOzs7OztPQUdMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUNiLHdCQUFDLEtBQUQ7U0FDRSxNQUFNO1NBQ04sUUFBTztTQUNQLEtBQUk7U0FDSixXQUFVO1NBQ1YsY0FBVzttQkFMYixDQU9FLHdCQUFDLFFBQUQsRUFBTSxXQUFVLFdBQVk7Ozs7bUJBQzVCLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFoQixDQUNFLHdCQUFDLFFBQUQsWUFBTSxvQkFBdUI7Ozs7b0JBQzdCLHdCQUFDLGNBQUQsRUFBYyxXQUFVLG9CQUFxQjs7OztrQkFDekM7Ozs7O2lCQUNMOzs7Ozs7T0FDQTs7Ozs7TUFDRjs7Ozs7O0lBQ0U7Ozs7OztHQUdULHdCQUFDLFdBQUQ7SUFDRSxJQUFHO0lBQ0gsV0FBVTtjQUZaLENBS0Usd0JBQUMsT0FBRDtLQUNFLFdBQVU7S0FDVixPQUFPLEVBQUUsV0FBVyxvQkFBb0IsYUFBYSxRQUFRLElBQUssS0FBSztLQUN2RSxlQUFZO2VBQ2I7SUFFSTs7OztjQUVMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNFLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUEyQjtRQUFROzs7OztRQUNuRCx3QkFBQyxRQUFELFlBQU0sSUFBTzs7Ozs7UUFDYix3QkFBQyxRQUFELFlBQU0sUUFBVzs7Ozs7T0FDZDs7Ozs7O01BRUwsd0JBQUMsZ0JBQUQ7T0FBZ0IsSUFBRztPQUFLLFdBQVU7aUJBQWtFO01BRXBGOzs7OztNQUVoQix3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDYix3QkFBQyxLQUFEO1FBQ0UsTUFBSztRQUNMLFdBQVU7a0JBRVYsd0JBQUMsUUFBRCxZQUFNLCtEQUFrRTs7Ozs7T0FDdkU7Ozs7O01BQ0E7Ozs7O01BR0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxVQUFEO1NBQ0UsZUFBZSxvQkFBb0IsT0FBTztTQUMxQyxXQUFXLCtIQUNULHFCQUFxQixVQUNqQixzQ0FDQTttQkFFUDtRQUVPOzs7OztRQUNSLHdCQUFDLFVBQUQ7U0FDRSxlQUFlLG9CQUFvQixRQUFRO1NBQzNDLFdBQVcsK0hBQ1QscUJBQXFCLFdBQ2pCLHNDQUNBO21CQUVQO1FBRU87Ozs7O1FBQ1Isd0JBQUMsVUFBRDtTQUNFLGVBQWUsb0JBQW9CLFFBQVE7U0FDM0MsV0FBVywrSEFDVCxxQkFBcUIsV0FDakIsc0NBQ0E7bUJBRVA7UUFFTzs7Ozs7T0FDTDs7Ozs7O01BR0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxPQUFELFlBQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQ2IscUJBQXFCLFVBQ2xCLG9EQUNBLHFCQUFxQixXQUNyQiwrQ0FDQTtPQUNBOzs7O2dCQUNIOzs7O2lCQUNMLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUE2QztPQUFnQjs7OztlQUMxRTs7Ozs7O01BR0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQ1osY0FBYyxLQUFLLEtBQUssUUFBUTtRQUMvQixNQUFNLGVBQ0oscUJBQXFCLFVBQ2pCLElBQUksYUFDSixxQkFBcUIsV0FDckIsSUFBSSxjQUNKLElBQUk7UUFFVixPQUNFLHdCQUFDLE9BQUQ7U0FFRSxXQUFVO21CQUZaLENBSUUsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxNQUFEO1dBQUksV0FBVTtxQkFDWCxJQUFJO1VBQ0g7Ozs7b0JBQ0osd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDRSx3QkFBQyxPQUFELEVBQU8sV0FBVSw2QkFBOEI7Ozs7cUJBQy9DLHdCQUFDLFFBQUQsWUFBTyxJQUFJLFNBQWU7Ozs7bUJBQ3ZCOzs7OztrQkFDRjs7Ozs7bUJBRUwsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQ2Isd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQ2I7VUFDRzs7Ozs7U0FDSDs7OztpQkFDRjtXQWxCRTs7OztlQWtCRjtPQUVULENBQUM7TUFDRTs7Ozs7TUFHTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDYix3QkFBQyxLQUFEO1FBQ0UsTUFBTSxrQkFBa0I7UUFDeEIsUUFBTztRQUNQLEtBQUk7UUFDSixXQUFVO1FBQ1YsY0FBWSxrQkFBa0I7a0JBTGhDLENBT0Usd0JBQUMsUUFBRCxZQUFPLGtCQUFrQixLQUFXOzs7O2tCQUNwQyx3QkFBQyxjQUFELEVBQWMsV0FBVSx3R0FBeUc7Ozs7Z0JBQ2hJOzs7Ozs7TUFDQTs7Ozs7S0FDRjs7Ozs7WUFDRTs7Ozs7O0dBR1Qsd0JBQUMsV0FBRDtJQUFTLElBQUc7SUFBVSxXQUFVO2NBQWhDO0tBRUUsd0JBQUMsT0FBRDtNQUNFLFdBQVU7TUFDVixPQUFPLEVBQUUsV0FBVyxlQUFlLGFBQWEsUUFBUSxJQUFLLEtBQUs7TUFDbEUsZUFBWTtnQkFDYjtLQUVJOzs7OztLQUdMLHdCQUFDLE9BQUQ7TUFDRSxXQUFVO01BQ1YsZUFBWTtnQkFDYjtLQUVJOzs7OztLQUVMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQTJCO09BQVE7Ozs7O09BQ25ELHdCQUFDLFFBQUQsWUFBTSxJQUFPOzs7OztPQUNiLHdCQUFDLFFBQUQsWUFBTSxTQUFZOzs7OztNQUNmOzs7Ozs7S0FFTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxnQkFBRDtPQUFnQixJQUFHO09BQUssV0FBVTtpQkFBNkQ7TUFFL0U7Ozs7Z0JBQ2hCLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQW9EO1FBRTlEOzs7OztRQUNOLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUNaLENBQUMsR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLE1BQ3JCLHdCQUFDLE1BQUQsRUFBYyxXQUFVLHVCQUF3QixHQUFyQzs7OztnQkFBcUMsQ0FDakQ7UUFDRTs7Ozs7UUFDTCx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBNEM7UUFFdEQ7Ozs7O09BQ0g7Ozs7O2NBQ0Y7Ozs7Z0JBRUwsd0JBQUMsS0FBRDtPQUNFLE1BQU07T0FDTixRQUFPO09BQ1AsS0FBSTtPQUNKLFdBQVU7aUJBSlosQ0FNRSx3QkFBQyxRQUFELFlBQU0sb0JBQXVCOzs7O2lCQUM3Qix3QkFBQyxjQUFELEVBQWMsV0FBVSxVQUFXOzs7O2VBQ2xDOzs7OztjQUNBOzs7Ozs7S0FHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDWixhQUFhLEtBQUssS0FBSyxRQUFRO09BQzlCLE1BQU0sT0FBTyxNQUFNLE1BQU0sSUFBSSxxQkFBcUI7T0FDbEQsT0FDRSx3QkFBQyxPQUFEO1FBRUUsV0FBVyxnT0FBZ087a0JBRjdPO1NBSUUsd0JBQUMsT0FBRCxFQUFLLFdBQVUsa0RBQW1EOzs7OztTQUVsRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQ1osQ0FBQyxHQUFHLE1BQU0sSUFBSSxNQUFNLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxNQUM5Qix3QkFBQyxNQUFELEVBQWMsV0FBVSx1QkFBd0IsR0FBckM7Ozs7aUJBQXFDLENBQ2pEO1NBQ0U7Ozs7bUJBQ0wsd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQWI7V0FBNEQ7V0FDeEQsSUFBSTtXQUFLO1VBQ1Y7Ozs7O2lCQUNBOzs7OztTQUVMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQTRCLElBQUk7VUFBVzs7OztvQkFDM0Qsd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQWEsSUFBSTtVQUFXOzs7O2tCQUN6Qzs7Ozs7O1FBQ0Y7VUFwQkU7Ozs7Y0FvQkY7TUFFVCxDQUFDO0tBQ0U7Ozs7O0tBR0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ1osYUFBYSxLQUFLLEdBQUcsTUFDcEIsd0JBQUMsT0FBRCxFQUFhLFdBQVUsbUNBQW9DLEdBQWpEOzs7O2FBQWlELENBQzVEO0tBQ0U7Ozs7O0lBQ0U7Ozs7OztHQUdULHdCQUFDLFdBQUQ7SUFBUyxJQUFHO0lBQVUsV0FBVTtjQUFoQyxDQUVFLHdCQUFDLE9BQUQ7S0FDRSxXQUFVO0tBQ1YsT0FBTyxFQUFFLFdBQVcsZUFBZSxhQUFhLE9BQVEsSUFBSyxLQUFLO0tBQ2xFLGVBQVk7ZUFDYjtJQUVJOzs7O2NBRUwsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQTJCO1FBQVE7Ozs7O1FBQ25ELHdCQUFDLFFBQUQsWUFBTSxJQUFPOzs7OztRQUNiLHdCQUFDLFFBQUQsWUFBTSxTQUFZOzs7OztPQUNmOzs7Ozs7TUFFTCx3QkFBQyxnQkFBRDtPQUFnQixJQUFHO09BQUssV0FBVTtpQkFBa0U7TUFFcEY7Ozs7O01BQ2hCLHdCQUFDLGdCQUFEO09BQWdCLElBQUc7T0FBSSxPQUFPO09BQUssV0FBVTtpQkFBMEM7TUFFdkU7Ozs7O01BR2hCLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBRUUsd0JBQUMsS0FBRDtTQUNFLE1BQU07U0FDTixRQUFPO1NBQ1AsS0FBSTtTQUNKLFdBQVU7U0FDVixjQUFXO21CQUxiO1VBUUUsd0JBQUMsUUFBRCxFQUFNLFdBQVUseUhBQTBIOzs7OztVQUUxSSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUNiLHdCQUFDLE9BQUQ7YUFDRSxLQUFJO2FBQ0osS0FBSTthQUNKLFdBQVU7WUFDWDs7Ozs7V0FDRTs7OztxQkFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQXNGO1dBRWhHOzs7O3FCQUNKLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFmLENBQ0Usd0JBQUMsUUFBRDthQUFNLFdBQVU7dUJBQXdHO1lBRWxIOzs7O3NCQUNOLHdCQUFDLFFBQUQ7YUFBTSxXQUFVO3VCQUFvRTtZQUU5RTs7OztvQkFDSDs7Ozs7bUJBQ0Y7Ozs7bUJBQ0Y7Ozs7OztVQUVMLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0Usd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQXlIO1dBRW5JOzs7O3FCQUNOLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUNiLHdCQUFDLGNBQUQsRUFBYyxXQUFVLHdGQUF5Rjs7Ozs7V0FDOUc7Ozs7bUJBQ0Y7Ozs7OztTQUNKOzs7Ozs7UUFHSCx3QkFBQyxLQUFEO1NBQ0UsTUFBTTtTQUNOLFFBQU87U0FDUCxLQUFJO1NBQ0osV0FBVTtTQUNWLGNBQVc7bUJBTGI7VUFPRSx3QkFBQyxRQUFELEVBQU0sV0FBVSx5SEFBMEg7Ozs7O1VBRTFJLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0Usd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQ2Isd0JBQUMsT0FBRDthQUNFLEtBQUk7YUFDSixLQUFJO2FBQ0osV0FBVTtZQUNYOzs7OztXQUNFOzs7O3FCQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFBc0Y7V0FFaEc7Ozs7cUJBQ0osd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWYsQ0FDRSx3QkFBQyxRQUFEO2FBQU0sV0FBVTt1QkFBd0c7WUFFbEg7Ozs7c0JBQ04sd0JBQUMsUUFBRDthQUFNLFdBQVU7dUJBQW9FO1lBRTlFOzs7O29CQUNIOzs7OzttQkFDRjs7OzttQkFDRjs7Ozs7O1VBRUwsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBeUg7V0FFbkk7Ozs7cUJBQ04sd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQ2Isd0JBQUMsY0FBRCxFQUFjLFdBQVUsd0ZBQXlGOzs7OztXQUM5Rzs7OzttQkFDRjs7Ozs7O1NBQ0o7Ozs7OztRQUdILHdCQUFDLEtBQUQ7U0FDRSxNQUFNO1NBQ04sUUFBTztTQUNQLEtBQUk7U0FDSixXQUFVO1NBQ1YsY0FBVzttQkFMYjtVQU9FLHdCQUFDLFFBQUQsRUFBTSxXQUFVLHlIQUEwSDs7Ozs7VUFFMUksd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFDYix3QkFBQyxPQUFEO2FBQ0UsS0FBSTthQUNKLEtBQUk7YUFDSixXQUFVO1lBQ1g7Ozs7O1dBQ0U7Ozs7cUJBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUFzRjtXQUVoRzs7OztxQkFDSix3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZixDQUNFLHdCQUFDLFFBQUQ7YUFBTSxXQUFVO3VCQUF1RztZQUVqSDs7OztzQkFDTix3QkFBQyxRQUFEO2FBQU0sV0FBVTt1QkFBb0U7WUFFOUU7Ozs7b0JBQ0g7Ozs7O21CQUNGOzs7O21CQUNGOzs7Ozs7VUFFTCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUF5SDtXQUVuSTs7OztxQkFDTix3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFDYix3QkFBQyxjQUFELEVBQWMsV0FBVSx3RkFBeUY7Ozs7O1dBQzlHOzs7O21CQUNGOzs7Ozs7U0FDSjs7Ozs7O09BQ0E7Ozs7OztNQUdMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNiLHdCQUFDLEtBQUQ7UUFDRSxNQUFNO1FBQ04sUUFBTztRQUNQLEtBQUk7UUFDSixXQUFVO2tCQUpaLENBTUUsd0JBQUMsUUFBRCxZQUFNLHdDQUEyQzs7OztrQkFDakQsd0JBQUMsY0FBRCxFQUFjLFdBQVUsVUFBVzs7OztnQkFDbEM7Ozs7OztNQUNBOzs7OztLQUNGOzs7OztZQUNFOzs7Ozs7R0FHVCx3QkFBQyxXQUFEO0lBQVMsSUFBRztJQUFNLFdBQVU7Y0FBNUIsQ0FFRSx3QkFBQyxPQUFEO0tBQ0UsV0FBVTtLQUNWLE9BQU8sRUFBRSxXQUFXLG9CQUFvQixhQUFhLFFBQVEsSUFBSyxLQUFLO0tBQ3ZFLGVBQVk7ZUFDYjtJQUVJOzs7O2NBRUwsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQTJCO1FBQVE7Ozs7O1FBQ25ELHdCQUFDLFFBQUQsWUFBTSxJQUFPOzs7OztRQUNiLHdCQUFDLFFBQUQsWUFBTSxtQkFBc0I7Ozs7O09BQ3pCOzs7Ozs7TUFFTCx3QkFBQyxnQkFBRDtPQUFnQixJQUFHO09BQUssV0FBVTtpQkFBa0U7TUFFcEY7Ozs7O01BQ2hCLHdCQUFDLGdCQUFEO09BQWdCLElBQUc7T0FBSSxPQUFPO09BQUssV0FBVTtpQkFBMEM7TUFFdkU7Ozs7O01BRWhCLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNaLFNBQVMsS0FBSyxNQUFNLFFBQVE7UUFDM0IsTUFBTSxTQUFTLFlBQVk7UUFDM0IsT0FDRSx3QkFBQyxnQkFBRDtTQUEwQixPQUFPLE1BQU07bUJBQ3JDLHdCQUFDLE9BQUQ7VUFDRSxXQUFXLDBFQUNULFNBQVMsa0RBQWtEO29CQUYvRCxDQUtFLHdCQUFDLFVBQUQ7V0FDRSxlQUFlLFdBQVcsU0FBUyxPQUFPLEdBQUc7V0FDN0MsV0FBVTtXQUNWLGlCQUFlO1dBQ2YsaUJBQWUsY0FBYztxQkFKL0IsQ0FNRSx3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFDYixLQUFLO1dBQ0Y7Ozs7cUJBQ04sd0JBQUMsT0FBRDtZQUNFLFdBQVcsaUdBQ1QsU0FBUyw0QkFBNEI7c0JBR3RDLFNBQVMsd0JBQUMsT0FBRCxFQUFPLFdBQVUsVUFBVzs7Ozt1QkFBSSx3QkFBQyxNQUFELEVBQU0sV0FBVSxVQUFXOzs7OztXQUNsRTs7OzttQkFDQzs7Ozs7b0JBRVIsd0JBQUMsT0FBRDtXQUNFLElBQUksY0FBYztXQUNsQixXQUFXLDZDQUNULFNBQVMsMERBQTBEO3FCQUdyRSx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFDYix3QkFBQyxPQUFEO2FBQUssV0FBVTt1QkFDWixLQUFLO1lBQ0g7Ozs7O1dBQ0Y7Ozs7O1VBQ0Y7Ozs7a0JBQ0Y7Ozs7OztRQUNTLEdBckNLOzs7O2VBcUNMO09BRXBCLENBQUM7TUFDRTs7Ozs7TUFHTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBK0Q7T0FFekU7Ozs7aUJBQ04sd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQW1DO09BRTdDOzs7O2VBQ0g7Ozs7aUJBQ0wsd0JBQUMsS0FBRDtRQUNFLE1BQU07UUFDTixXQUFVO2tCQUZaLENBSUUsd0JBQUMsUUFBRCxFQUFNLFdBQVUsV0FBWTs7OztrQkFDNUIsd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQ2Qsd0JBQUMsUUFBRCxZQUFPLGFBQW1COzs7OztRQUN0Qjs7OztnQkFDTDs7Ozs7ZUFDQTs7Ozs7O0tBQ0Y7Ozs7O1lBQ0U7Ozs7OztHQUdULHdCQUFDLFdBQUQ7SUFDRSxLQUFLO0lBQ0wsSUFBRztJQUNILFdBQVU7Y0FFVix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBMkI7UUFBUTs7Ozs7UUFDbkQsd0JBQUMsUUFBRCxZQUFNLElBQU87Ozs7O1FBQ2Isd0JBQUMsUUFBRCxZQUFNLFdBQWM7Ozs7O09BQ2pCOzs7Ozs7TUFFTCx3QkFBQyxnQkFBRDtPQUFnQixJQUFHO09BQUssV0FBVTtpQkFBa0U7TUFFcEY7Ozs7O01BRWhCLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLFFBQUQsRUFBUSxXQUFVLHVDQUF3Qzs7OztvQkFDMUQsd0JBQUMsT0FBRDtXQUNFLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUFrRDtXQUFXOzs7OztXQUM3RSx3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBbUM7V0FFN0M7Ozs7O1dBQ04sd0JBQUMsS0FBRDtZQUFHLFdBQVU7c0JBQTZCO1dBRXZDOzs7OztVQUNBOzs7O2tCQUNGOzs7Ozs7U0FFTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLE9BQUQsRUFBTyxXQUFVLHVDQUF3Qzs7OztvQkFDekQsd0JBQUMsT0FBRDtXQUNFLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUFrRDtXQUU1RDs7Ozs7V0FDTix3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZjthQUNFLHdCQUFDLE9BQUQsWUFBSyx1QkFBeUI7Ozs7O2FBQzlCLHdCQUFDLE9BQUQsWUFBSyxvQ0FBc0M7Ozs7O2FBQzNDLHdCQUFDLE9BQUQsWUFBSyx1QkFBeUI7Ozs7O1lBQzNCOzs7Ozs7V0FDTCx3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBMEM7V0FFcEQ7Ozs7O1VBQ0g7Ozs7a0JBQ0Y7Ozs7OztTQUVMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsT0FBRCxFQUFPLFdBQVUsdUNBQXdDOzs7O29CQUN6RCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQWtEO1VBQWE7Ozs7b0JBQy9FLHdCQUFDLEtBQUQ7V0FDRSxNQUFNO1dBQ04sV0FBVTtxQkFFVDtVQUNBOzs7O2tCQUNBOzs7O2tCQUNGOzs7Ozs7UUFDRjs7Ozs7aUJBR0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxLQUFEO1VBQ0UsTUFBTTtVQUNOLFFBQU87VUFDUCxLQUFJO1VBQ0osV0FBVTtVQUNWLGNBQVc7b0JBTGIsQ0FPRSx3QkFBQyxZQUFELEVBQVksV0FBVSw2RkFBOEY7Ozs7b0JBQ3BILHdCQUFDLFFBQUQsWUFBTSxpQkFBb0I7Ozs7a0JBQ3pCOzs7Ozs7U0FFSCx3QkFBQyxLQUFEO1VBQ0UsTUFBTTtVQUNOLFFBQU87VUFDUCxLQUFJO1VBQ0osV0FBVTtVQUNWLGNBQVc7b0JBTGIsQ0FPRSx3QkFBQyxRQUFELFlBQU0sb0JBQXVCOzs7O29CQUM3Qix3QkFBQyxjQUFELEVBQWMsV0FBVSw2RkFBOEY7Ozs7a0JBQ3JIOzs7Ozs7U0FFSCx3QkFBQyxLQUFEO1VBQ0UsTUFBTTtVQUNOLFFBQU87VUFDUCxLQUFJO1VBQ0osV0FBVTtVQUNWLGNBQVc7b0JBTGIsQ0FPRSx3QkFBQyxNQUFELEVBQU0sV0FBVSw2RkFBOEY7Ozs7b0JBQzlHLHdCQUFDLFFBQUQsWUFBTSxlQUFrQjs7OztrQkFDdkI7Ozs7OztRQUNBOzs7OztlQUNGOzs7Ozs7S0FDRjs7Ozs7O0dBQ0U7Ozs7O0dBR1Qsd0JBQUMsT0FBRDtJQUFLLFdBQVU7SUFBZ0MsZUFBWTtHQUFROzs7OztHQUduRSx3QkFBQyxVQUFEO0lBQVEsV0FBVTtjQUFsQixDQUVFLHdCQUFDLE9BQUQ7S0FDRSxXQUFVO0tBQ1YsZUFBWTtlQUNiO0lBRUk7Ozs7Y0FFTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BRUUsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1FBQVEsTUFBTTtRQUFJLFdBQVU7T0FBbUI7Ozs7aUJBQy9DLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBd0M7T0FBaUI7Ozs7aUJBQ3pFLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUF3QjtPQUVsQzs7OztlQUNBOzs7O2VBQ0Y7Ozs7OztNQUdMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsS0FBRDtTQUNFLE1BQU07U0FDTixRQUFPO1NBQ1AsS0FBSTtTQUNKLFdBQVU7bUJBQ1g7UUFFRTs7Ozs7UUFDSCx3QkFBQyxLQUFEO1NBQ0UsTUFBTTtTQUNOLFFBQU87U0FDUCxLQUFJO1NBQ0osV0FBVTttQkFDWDtRQUVFOzs7OztRQUNILHdCQUFDLEtBQUQ7U0FBRyxNQUFNO1NBQVksV0FBVTttQkFDNUI7UUFDQTs7Ozs7UUFDSCx3QkFBQyxLQUFEO1NBQ0UsTUFBTTtTQUNOLFFBQU87U0FDUCxLQUFJO1NBQ0osV0FBVTttQkFDWDtRQUVFOzs7OztRQUNILHdCQUFDLFVBQUQ7U0FDRSxlQUFlLG1CQUFtQixJQUFJO1NBQ3RDLFdBQVU7U0FDVixjQUFXO21CQUhiLENBS0Usd0JBQUMsVUFBRCxFQUFVLFdBQVUsY0FBZTs7OzttQkFDbkMsd0JBQUMsUUFBRCxZQUFNLHdCQUEyQjs7OztpQkFDM0I7Ozs7OztPQUNMOzs7Ozs7TUFHTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFoQjtTQUFzRDtTQUNqRCxJQUFJLEtBQUssQ0FBQyxDQUFDLFlBQVk7U0FBRTtRQUN4Qjs7Ozs7aUJBQ04sd0JBQUMsVUFBRDtRQUNFLFNBQVM7UUFDVCxXQUFVO1FBQ1YsY0FBVztrQkFFWCx3QkFBQyxTQUFELEVBQVMsV0FBVSxVQUFXOzs7OztPQUN4Qjs7OztlQUNMOzs7Ozs7S0FDRjs7Ozs7WUFDQzs7Ozs7O0dBR1AscUJBQ0Msd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FDYix3QkFBQyxLQUFEO0tBQ0UsTUFBTTtLQUNOLFFBQU87S0FDUCxLQUFJO0tBQ0osV0FBVTtLQUNWLGNBQVc7ZUFMYixDQU9FLHdCQUFDLFFBQUQsRUFBTSxXQUFVLFdBQVk7Ozs7ZUFDNUIsd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQWhCLENBQ0Usd0JBQUMsUUFBRCxZQUFNLG9CQUF1Qjs7OztnQkFDN0Isd0JBQUMsY0FBRCxFQUFjLFdBQVUsb0JBQXFCOzs7O2NBQ3pDOzs7OzthQUNMOzs7Ozs7R0FDQTs7Ozs7R0FJUCx3QkFBQyxhQUFELENBQWM7Ozs7O0dBR2Qsd0JBQUMsY0FBRDtJQUNFLFFBQVE7SUFDUixjQUFjO0lBQ2QsUUFBUTtJQUNSLGVBQWUsZUFBZSxLQUFLO0dBQ3BDOzs7OztHQUdELHdCQUFDLGFBQUQ7SUFDRSxRQUFRO0lBQ1IsZUFBZSxtQkFBbUIsS0FBSztHQUN4Qzs7Ozs7RUFDRTs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQXBwLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIHVzZUVmZmVjdCwgdXNlUmVmIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHtcbiAgU3RhcixcbiAgTWFwUGluLFxuICBDbG9jayxcbiAgUGhvbmUsXG4gIFNlbmQsXG4gIE5hdmlnYXRpb24sXG4gIENoZXZyb25SaWdodCxcbiAgRXh0ZXJuYWxMaW5rLFxuICBTY2lzc29ycyxcbiAgV2lmaSxcbiAgQ29mZmVlLFxuICBEcm9wbGV0cyxcbiAgQ29va2llLFxuICBHYW1lcGFkMixcbiAgQXJyb3dVcFJpZ2h0LFxuICBBcnJvd1VwLFxuICBQbHVzLFxuICBNaW51cyxcbiAgSGVscENpcmNsZSxcbiAgRG93bmxvYWQsXG4gIEZvbGRlckFyY2hpdmUsXG59IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5pbXBvcnQgeyBCYXJiZXJQb2xlM0QgfSBmcm9tICcuL2NvbXBvbmVudHMvQmFyYmVyUG9sZTNEJztcbmltcG9ydCB7IExvZ29WQiB9IGZyb20gJy4vY29tcG9uZW50cy9Mb2dvVkInO1xuaW1wb3J0IHsgR2FsbGVyeU1vZGFsIH0gZnJvbSAnLi9jb21wb25lbnRzL0dhbGxlcnlNb2RhbCc7XG5pbXBvcnQgeyBBdWRpb1BsYXllciB9IGZyb20gJy4vY29tcG9uZW50cy9BdWRpb1BsYXllcic7XG5pbXBvcnQgeyBSZXZlYWxPblNjcm9sbCB9IGZyb20gJy4vY29tcG9uZW50cy9SZXZlYWxPblNjcm9sbCc7XG5pbXBvcnQgeyBCYXJiZXJJbWFnZSB9IGZyb20gJy4vY29tcG9uZW50cy9CYXJiZXJJbWFnZSc7XG5pbXBvcnQgeyBFeHBvcnRNb2RhbCB9IGZyb20gJy4vY29tcG9uZW50cy9FeHBvcnRNb2RhbCc7XG5pbXBvcnQge1xuICBTY2lzc29yc0ljb24sXG4gIENvbWJJY29uLFxuICBTdHJhaWdodFJhem9ySWNvbixcbiAgQ2xpcHBlckljb24sXG59IGZyb20gJy4vY29tcG9uZW50cy9CYXJiZXJUb29sc1NWRyc7XG5cbi8vIFJlYWwgRGlraWRpIEJvb2tpbmcgVVJMcyBzdHJpY3RseSBwZXIgaW5zdHJ1Y3Rpb25zXG5jb25zdCBESUtJRElfR0VORVJBTCA9XG4gICdodHRwczovL2Rpa2lkaS5uZXQvcnUvcmVjb3JkLzIwODkwNDU/cD0wLnBpLXBvLXNtLXNzbSZvPTEmbT00NDc1MjU4JnNvdXJjZT13ZWJzaXRlJmJhY2t1cmw9aHR0cHMlM0ElMkYlMkZkaWtpZGkubmV0JTJGcnUlMkZwcm9maWxlJTJGdm5lX3ZyZW1lbmlfYmFyYmVyc2hvcF8yMDg5MDQ1JztcblxuY29uc3QgRElLSURJX01BS1NVRCA9XG4gICdodHRwczovL2Rpa2lkaS5uZXQvcnUvcmVjb3JkLzIwODkwNDU/cD0zLnBpLXBvLXNtLXNzbSZvPTEmbT00NDc1MjU4JnNvdXJjZT13ZWJzaXRlJmJhY2t1cmw9aHR0cHMlM0ElMkYlMkZkaWtpZGkubmV0JTJGcnUlMkZwcm9maWxlJTJGdm5lX3ZyZW1lbmlfYmFyYmVyc2hvcF8yMDg5MDQ1JztcblxuY29uc3QgRElLSURJX1NJUk9aSElESU4gPVxuICAnaHR0cHM6Ly9kaWtpZGkubmV0L3J1L3JlY29yZC8yMDg5MDQ1P3A9My5waS1wby1zbS1zc20mbz0xJm09NDQ5MjA4OSZzb3VyY2U9d2Vic2l0ZSZiYWNrdXJsPWh0dHBzJTNBJTJGJTJGZGlraWRpLm5ldCUyRnJ1JTJGcHJvZmlsZSUyRnZuZV92cmVtZW5pX2JhcmJlcnNob3BfMjA4OTA0NSc7XG5cbmNvbnN0IERJS0lESV9aSEFNU0hJRCA9XG4gICdodHRwczovL2Rpa2lkaS5uZXQvMjA4OTA0NT9wPTMucGktcG8tc20tc3NtJm89MSZtPTQ2NjYxMjcnO1xuXG4vLyAyR0lTICYgQ29udGFjdHNcbmNvbnN0IERHSVNfVVJMID0gJ2h0dHBzOi8vMmdpcy5ydS9wZXJtL2Zpcm0vNzAwMDAwMDExMTU2NDM4NjAvdGFiL3Jldmlld3MnO1xuY29uc3QgVEVMRUdSQU1fVVJMID0gJ2h0dHBzOi8vdC5tZSc7XG5jb25zdCBQSE9ORV9OVU1CRVIgPSAnKzcgKDk5NikgNTc1LTUzLTA2JztcbmNvbnN0IFBIT05FX0xJTksgPSAndGVsOis3OTk2NTc1NTMwNic7XG5cbi8vIFJlYWwgbWFzdGVyIHdvcmtzXG5pbnRlcmZhY2UgV29ya0l0ZW0ge1xuICBpZDogc3RyaW5nO1xuICBzcmM6IHN0cmluZztcbiAgdGl0bGU6IHN0cmluZztcbiAgbWFzdGVySWQ6ICdzaXJvemhpZGluJyB8ICdqYW1zaGlkJyB8ICdtYWtzdWQnO1xuICBtYXN0ZXJOYW1lOiBzdHJpbmc7XG4gIGNyb3BQb3NpdGlvbj86IHN0cmluZztcbn1cblxuY29uc3QgQUxMX1dPUktTOiBXb3JrSXRlbVtdID0gW1xuICAvLyBTaXJvemhpZGluIHdvcmtzXG4gIHtcbiAgICBpZDogJ3ctcy0xJyxcbiAgICBzcmM6ICcvYXNzZXRzL2Fpc3R1ZGlvL0lNR183NzM1X2NlNmQ5NDNmLmpwZWcnLFxuICAgIHRpdGxlOiAn0KTQuNC70LjQs9GA0LDQvdC90YvQuSDRgdC60LjQvS3RhNC10LnQtCcsXG4gICAgbWFzdGVySWQ6ICdzaXJvemhpZGluJyxcbiAgICBtYXN0ZXJOYW1lOiAn0J/QsNGC0LjQtNC40L3QvtCyINCh0LjRgNC+0LbQuNC00LjQvScsXG4gICAgY3JvcFBvc2l0aW9uOiAnY2VudGVyJyxcbiAgfSxcbiAge1xuICAgIGlkOiAndy1zLTInLFxuICAgIHNyYzogJy9hc3NldHMvYWlzdHVkaW8vSU1HXzc2MTJfNTUyZDlhZTAuanBlZycsXG4gICAgdGl0bGU6ICfQnNC+0LTQtdC70LjRgNC+0LLQsNC90LjQtSDQsdC+0YDQvtC00Ysg0Lgg0LrQvtC90YLRg9GAJyxcbiAgICBtYXN0ZXJJZDogJ3Npcm96aGlkaW4nLFxuICAgIG1hc3Rlck5hbWU6ICfQn9Cw0YLQuNC00LjQvdC+0LIg0KHQuNGA0L7QttC40LTQuNC9JyxcbiAgICBjcm9wUG9zaXRpb246ICdjZW50ZXInLFxuICB9LFxuICB7XG4gICAgaWQ6ICd3LXMtMycsXG4gICAgc3JjOiAnL2Fzc2V0cy9haXN0dWRpby9JTUdfNzYxMF8xMWM5OTAwNC5qcGVnJyxcbiAgICB0aXRsZTogJ9CU0LXRgtGB0LrQsNGPINC80L7QtNC10LvRjNC90LDRjyDRgdGC0YDQuNC20LrQsCDQvdC+0LbQvdC40YbQsNC80LgnLFxuICAgIG1hc3RlcklkOiAnc2lyb3poaWRpbicsXG4gICAgbWFzdGVyTmFtZTogJ9Cf0LDRgtC40LTQuNC90L7QsiDQodC40YDQvtC20LjQtNC40L0nLFxuICAgIGNyb3BQb3NpdGlvbjogJ2NlbnRlcicsXG4gIH0sXG4gIC8vIEphbXNoaWQgd29ya3NcbiAge1xuICAgIGlkOiAndy1qLTEnLFxuICAgIHNyYzogJy9hc3NldHMvYWlzdHVkaW8vSU1HXzc2MDhfY2MzMWYyZGUuanBlZycsXG4gICAgdGl0bGU6ICfQmtC70LDRgdGB0LjRh9C10YHQutCw0Y8g0LzRg9C20YHQutCw0Y8g0YHRgtGA0LjQttC60LAg0Lgg0YPQutC70LDQtNC60LAnLFxuICAgIG1hc3RlcklkOiAnamFtc2hpZCcsXG4gICAgbWFzdGVyTmFtZTogJ9CR0LDRhdGA0LjQtNC40L3QvtCyINCW0LDQvNGI0LjQtCcsXG4gICAgY3JvcFBvc2l0aW9uOiAnY2VudGVyJyxcbiAgfSxcbiAge1xuICAgIGlkOiAndy1qLTInLFxuICAgIHNyYzogJy9hc3NldHMvYWlzdHVkaW8vSU1HXzc2MDdfNzc0ZTcxYWUuanBlZycsXG4gICAgdGl0bGU6ICfQotC10LrRgdGC0YPRgNC90YvQuSDQutGA0L7QvycsXG4gICAgbWFzdGVySWQ6ICdqYW1zaGlkJyxcbiAgICBtYXN0ZXJOYW1lOiAn0JHQsNGF0YDQuNC00LjQvdC+0LIg0JbQsNC80YjQuNC0JyxcbiAgICBjcm9wUG9zaXRpb246ICdjZW50ZXIgMzUlJyxcbiAgfSxcbiAgLy8gTWFrc3VkIHdvcmtzXG4gIHtcbiAgICBpZDogJ3ctbS0xJyxcbiAgICBzcmM6ICcvYXNzZXRzL2Fpc3R1ZGlvL0lNR18yMDAzXzZhOWJlNWEzLmpwZWcnLFxuICAgIHRpdGxlOiAn0KTQtdC50LQg0Lgg0L7RhNC+0YDQvNC70LXQvdC40LUg0LHQvtGA0L7QtNGLJyxcbiAgICBtYXN0ZXJJZDogJ21ha3N1ZCcsXG4gICAgbWFzdGVyTmFtZTogJ9CR0LDRhdGA0LjQtNC40L3QvtCyINCc0LDQutGB0YPQtCcsXG4gICAgY3JvcFBvc2l0aW9uOiAnY2VudGVyJyxcbiAgfSxcbiAge1xuICAgIGlkOiAndy1tLTInLFxuICAgIHNyYzogJy9hc3NldHMvYWlzdHVkaW8vSU1HXzIwMDJfOWM4MTcyMDAuanBlZycsXG4gICAgdGl0bGU6ICfQmtC+0L3RgtGD0YDQuNC90LMg0LHQvtGA0L7QtNGLINC+0L/QsNGB0L3QvtC5INCx0YDQuNGC0LLQvtC5JyxcbiAgICBtYXN0ZXJJZDogJ21ha3N1ZCcsXG4gICAgbWFzdGVyTmFtZTogJ9CR0LDRhdGA0LjQtNC40L3QvtCyINCc0LDQutGB0YPQtCcsXG4gICAgY3JvcFBvc2l0aW9uOiAnY2VudGVyJyxcbiAgfSxcbiAge1xuICAgIGlkOiAndy1tLTMnLFxuICAgIHNyYzogJy9hc3NldHMvYWlzdHVkaW8vSU1HXzE5OTdfMzIxMDIyOTYuanBlZycsXG4gICAgdGl0bGU6ICfQnNGD0LbRgdC60L7QuSDRhNC10LnQtCDQuCDRgNCw0YHQv9Cw0YDQuNCy0LDQvdC40LUnLFxuICAgIG1hc3RlcklkOiAnbWFrc3VkJyxcbiAgICBtYXN0ZXJOYW1lOiAn0JHQsNGF0YDQuNC00LjQvdC+0LIg0JzQsNC60YHRg9C0JyxcbiAgICBjcm9wUG9zaXRpb246ICdjZW50ZXInLFxuICB9LFxuXTtcblxuLy8gUHJpY2UgbGlzdCB3aXRoIHRpZXJzIGFjY29yZGluZyB0byAyR0lTXG50eXBlIE1hc3RlckNhdGVnb3J5ID0gJ2JyYW5kJyB8ICdiYXJiZXInIHwgJ2p1bmlvcic7XG5cbmludGVyZmFjZSBTZXJ2aWNlSXRlbSB7XG4gIG5hbWU6IHN0cmluZztcbiAgZHVyYXRpb246IHN0cmluZztcbiAgcHJpY2VKdW5pb3I6IHN0cmluZztcbiAgcHJpY2VCYXJiZXI6IHN0cmluZztcbiAgcHJpY2VCcmFuZDogc3RyaW5nO1xufVxuXG5jb25zdCBTRVJWSUNFU19EQVRBOiBTZXJ2aWNlSXRlbVtdID0gW1xuICB7XG4gICAgbmFtZTogJ9Cc0YPQttGB0LrQsNGPINGB0YLRgNC40LbQutCwICsg0LzQvtC00LXQu9C40YDQvtCy0LDQvdC40LUg0LHQvtGA0L7QtNGLIC8g0LHRgNC40YLRjNC1JyxcbiAgICBkdXJhdGlvbjogJzEg0YcgMjAg0LzQuNC9JyxcbiAgICBwcmljZUp1bmlvcjogJ9C+0YIgNzkwIOKCvScsXG4gICAgcHJpY2VCYXJiZXI6ICfQvtGCIDEgMTAwIOKCvScsXG4gICAgcHJpY2VCcmFuZDogJ9C+0YIgMSA0MDAg4oK9JyxcbiAgfSxcbiAge1xuICAgIG5hbWU6ICfQntGC0LXRhiArINGB0YvQvSAo0YDQtdCx0LXQvdC+0Log0LTQviAxMCDQu9C10YIpJyxcbiAgICBkdXJhdGlvbjogJzEg0YcgNDAg0LzQuNC9JyxcbiAgICBwcmljZUp1bmlvcjogJ9C+0YIgNzkwIOKCvScsXG4gICAgcHJpY2VCYXJiZXI6ICfQvtGCIDEgMTAwIOKCvScsXG4gICAgcHJpY2VCcmFuZDogJ9C+0YIgMSA0MDAg4oK9JyxcbiAgfSxcbiAge1xuICAgIG5hbWU6ICfQodGC0YDQuNC20LrQsCDQvdC+0LbQvdC40YbQsNC80LgnLFxuICAgIGR1cmF0aW9uOiAnMSDRhyAyMCDQvNC40L0nLFxuICAgIHByaWNlSnVuaW9yOiAn0L7RgiA1OTAg4oK9JyxcbiAgICBwcmljZUJhcmJlcjogJ9C+0YIgODAwIOKCvScsXG4gICAgcHJpY2VCcmFuZDogJ9C+0YIgMSAwMDAg4oK9JyxcbiAgfSxcbiAge1xuICAgIG5hbWU6ICfQlNC10YLRgdC60LDRjyDRgdGC0YDQuNC20LrQsCDQtNC+IDEwINC70LXRgicsXG4gICAgZHVyYXRpb246ICc0MCDQvNC40L0nLFxuICAgIHByaWNlSnVuaW9yOiAn0L7RgiAzOTAg4oK9JyxcbiAgICBwcmljZUJhcmJlcjogJ9C+0YIgNjAwIOKCvScsXG4gICAgcHJpY2VCcmFuZDogJ9C+0YIgODAwIOKCvScsXG4gIH0sXG4gIHtcbiAgICBuYW1lOiAn0JzQvtC00LXQu9C40YDQvtCy0LDQvdC40LUg0LHQvtGA0L7QtNGLIC8g0LHRgNC40YLRjNC1JyxcbiAgICBkdXJhdGlvbjogJzMwINC80LjQvScsXG4gICAgcHJpY2VKdW5pb3I6ICfQvtGCIDI5MCDigr0nLFxuICAgIHByaWNlQmFyYmVyOiAn0L7RgiA0NTAg4oK9JyxcbiAgICBwcmljZUJyYW5kOiAn0L7RgiA2MDAg4oK9JyxcbiAgfSxcbiAge1xuICAgIG5hbWU6ICfQodGC0YDQuNC20LrQsCDQvNCw0YjQuNC90LrQvtC5ICgxINC90LDRgdCw0LTQutCwKScsXG4gICAgZHVyYXRpb246ICczMCDQvNC40L0nLFxuICAgIHByaWNlSnVuaW9yOiAn0L7RgiAyOTAg4oK9JyxcbiAgICBwcmljZUJhcmJlcjogJ9C+0YIgNDAwIOKCvScsXG4gICAgcHJpY2VCcmFuZDogJ9C+0YIgNTAwIOKCvScsXG4gIH0sXG5dO1xuXG4vLyBSZWFsIHJldmlld3MgZnJvbSAyR0lTXG5jb25zdCBSRVZJRVdTX0RBVEEgPSBbXG4gIHtcbiAgICBuYW1lOiAn0JTQvNC40YLRgNC40Lkg0KHQvNC40YDQvdC+0LInLFxuICAgIGRhdGU6ICcxNCDQvtC60YLRj9Cx0YDRjyAyMDI0JyxcbiAgICByYXRpbmc6IDUsXG4gICAgdGV4dDogJ9Ce0YLQu9C40YfQvdGL0Lkg0LHQsNGA0LHQtdGA0YjQvtC/ISDQkdGL0Lsg0YMg0LzQsNGB0YLQtdGA0LAg0KHQuNGA0L7QttC40LTQuNC90LAuINCh0LTQtdC70LDQuyDQstGB0LUg0LHRi9GB0YLRgNC+LCDQsNC60LrRg9GA0LDRgtC90L4g0Lgg0LjQvNC10L3QvdC+INGC0LDQuiwg0LrQsNC6INGPINC/0YDQvtGB0LjQuy4g0JDRgtC80L7RgdGE0LXRgNCwINC60LvQsNGB0YHQvdCw0Y8sINGH0LDQuS/QutC+0YTQtSDQv9GA0LXQtNC70L7QttC40LvQuC4g0J7QtNC90L7Qt9C90LDRh9C90L4g0YDQtdC60L7QvNC10L3QtNGD0Y4hJyxcbiAgfSxcbiAge1xuICAgIG5hbWU6ICfQkNGA0YLQtdC8INCf0L7Qv9C+0LInLFxuICAgIGRhdGU6ICcyOCDRgdC10L3RgtGP0LHRgNGPIDIwMjQnLFxuICAgIHJhdGluZzogNSxcbiAgICB0ZXh0OiAn0JzQsNC60YHRg9C0IOKAlCDQvdCw0YHRgtC+0Y/RidC40Lkg0L/RgNC+0YTQuCEgMTAg0LvQtdGCINC+0L/Ri9GC0LAg0YHRgNCw0LfRgyDQstC40LTQvdC+LCDRhNC10LnQtCDRgdC00LXQu9Cw0Lsg0YTQuNC70LjQs9GA0LDQvdC90L4uINCf0YDQuNGP0YLQvdC+0LUg0LzQtdGB0YLQviwg0YPQtNC+0LHQvdC+0LUg0YDQsNGB0L/QvtC70L7QttC10L3QuNC1INC90LAg0JrQvtC80L/RgNC+0YHQtS4g0KLQtdC/0LXRgNGMINGB0YLRgNC40LPRg9GB0Ywg0YLQvtC70YzQutC+INC30LTQtdGB0YwuJyxcbiAgfSxcbiAge1xuICAgIG5hbWU6ICfQmNC70YzRjyDQki4nLFxuICAgIGRhdGU6ICczINGB0LXQvdGC0Y/QsdGA0Y8gMjAyNCcsXG4gICAgcmF0aW5nOiA1LFxuICAgIHRleHQ6ICfQn9GA0LjRhdC+0LTQuNC7INGBINGB0YvQvdC+0LwuINCW0LDQvNGI0LjQtCDQvdCw0YjQtdC7INC/0L7QtNGF0L7QtCDQuiDRgNC10LHQtdC90LrRgyDRgSDQv9C10YDQstGL0YUg0LzQuNC90YPRgiwg0L/QvtC00YHRgtGA0LjQsyDRgdC/0L7QutC+0LnQvdC+INC4INC60LDRh9C10YHRgtCy0LXQvdC90L4uINCm0LXQvdGLINCw0LHRgdC+0LvRjtGC0L3QviDQsNC00LXQutCy0LDRgtC90YvQtSDQt9CwINGC0LDQutC+0Lkg0YPRgNC+0LLQtdC90Ywg0YHQtdGA0LLQuNGB0LAuJyxcbiAgfSxcbiAge1xuICAgIG5hbWU6ICfQodC10YDQs9C10Lkg0JouJyxcbiAgICBkYXRlOiAnMTkg0LDQstCz0YPRgdGC0LAgMjAyNCcsXG4gICAgcmF0aW5nOiA1LFxuICAgIHRleHQ6ICfQntGH0LXQvdGMINGH0LjRgdGC0YvQuSDQuCDRgdGC0LjQu9GM0L3Ri9C5INCx0LDRgNCx0LXRgNGI0L7Qvy4g0JzQsNGB0YLQtdGA0LAg0LLQvdC40LzQsNGC0LXQu9GM0L3Ri9C1LCDQvdC40LrQsNC60L7Qs9C+INC/0LDRhNC+0YHQsCwg0YLQvtC70YzQutC+INGH0LXRgdGC0L3QsNGPINC60LDRh9C10YHRgtCy0LXQvdC90LDRjyDRgNCw0LHQvtGC0LAuIDUg0LjQtyA1INCx0LXQtyDRgdC+0LzQvdC10L3QuNC5LicsXG4gIH0sXG5dO1xuXG4vLyA2IEZyZWUgQW1lbml0aWVzIChGbGF0IDFweCBib3JkZXIsIDEyMHB4IGhlaWdodClcbmNvbnN0IEFNRU5JVElFU19MSVNUID0gW1xuICB7IHRpdGxlOiAn0JTQstGD0LrRgNCw0YLQvdC+0LUg0LzRi9GC0YzRkSDQs9C+0LvQvtCy0YsnLCBpY29uOiBEcm9wbGV0cyB9LFxuICB7IHRpdGxlOiAn0JrQvtGE0LUnLCBpY29uOiBDb2ZmZWUgfSxcbiAgeyB0aXRsZTogJ9Ch0L3QtdC60LgnLCBpY29uOiBDb29raWUgfSxcbiAgeyB0aXRsZTogJ9Cf0LDRgNC60L7QstC60LAnLCBjdXN0b21QOiB0cnVlIH0sXG4gIHsgdGl0bGU6ICdXaS1GaScsIGljb246IFdpZmkgfSxcbiAgeyB0aXRsZTogJ1BsYXlTdGF0aW9uIDUnLCBpY29uOiBHYW1lcGFkMiB9LFxuXTtcblxuLy8gRkFRIGl0ZW1zIGJhc2VkIHN0cmljdGx5IG9uIDJHSVMgY2FyZCBhbmQgc2Fsb24gc3BlY2lmaWNhdGlvbnNcbmNvbnN0IEZBUV9EQVRBID0gW1xuICB7XG4gICAgcTogJ9CX0LAg0YHQutC+0LvRjNC60L4g0LLRgNC10LzQtdC90Lgg0L3Rg9C20L3QviDQt9Cw0L/QuNGB0YvQstCw0YLRjNGB0Y8g0L3QsCDRgdGC0YDQuNC20LrRgz8nLFxuICAgIGE6ICfQl9Cw0L/QuNGB0Ywg0L7RgdGD0YnQtdGB0YLQstC70Y/QtdGC0YHRjyDQv9C+INC/0YDQtdC00LLQsNGA0LjRgtC10LvRjNC90L7QuSDQtNC+0LPQvtCy0L7RgNGR0L3QvdC+0YHRgtC4LiDQoNC10LrQvtC80LXQvdC00YPQtdC8INC30LDQv9C40YHRi9Cy0LDRgtGM0YHRjyDQt9Cw0YDQsNC90LXQtSDRh9C10YDQtdC3INC+0L3Qu9Cw0LnQvS3Qt9Cw0L/QuNGB0Ywg0LIgRGlraWRpINC40LvQuCDQv9C+INGC0LXQu9C10YTQvtC90YMgKzcgKDk5NikgNTc1LTUzLTA2LCDRh9GC0L7QsdGLINCy0YvQsdGA0LDRgtGMINC90LDQuNCx0L7Qu9C10LUg0YPQtNC+0LHQvdGL0Lkg0LLRgNC10LzQtdC90L3QvtC5INGB0LvQvtGCINC4INC90YPQttC90L7Qs9C+INC80LDRgdGC0LXRgNCwLicsXG4gIH0sXG4gIHtcbiAgICBxOiAn0KfRgtC+INCy0YXQvtC00LjRgiDQsiDRgdGC0L7QuNC80L7RgdGC0Ywg0YHRgtGA0LjQttC60Lg/JyxcbiAgICBhOiAn0JIg0LvRjtCx0YPRjiDRgdGC0YDQuNC20LrRgyDRg9C20LUg0LLQutC70Y7Rh9C10L3QviDQtNCy0YPQutGA0LDRgtC90L7QtSDQvNGL0YLRjNGRINCz0L7Qu9C+0LLRiyDQv9GA0L7RhNC10YHRgdC40L7QvdCw0LvRjNC90YvQvCDRiNCw0LzQv9GD0L3QtdC8LCDQvtGH0LjRidC10L3QuNC1INC60L7QttC4INC4INGE0LjQvdCw0LvRjNC90LDRjyDRg9C60LvQsNC00LrQsCDQv9GA0L7RhNC10YHRgdC40L7QvdCw0LvRjNC90YvQvCDRgdGC0LDQudC70LjQvdCz0L7QvC4g0J3QuNC60LDQutC40YUg0YHQutGA0YvRgtGL0YUg0LTQvtC/0LvQsNGCINC30LAg0LzRi9GC0YzRkSwg0YHRg9GI0LrRgyDQuNC70Lgg0YPQutC70LDQtNC+0YfQvdGL0LUg0YHRgNC10LTRgdGC0LLQsCDQvdC10YIuJyxcbiAgfSxcbiAge1xuICAgIHE6ICfQp9C10Lwg0L7RgtC70LjRh9Cw0Y7RgtGB0Y8g0LrQsNGC0LXQs9C+0YDQuNC4INC80LDRgdGC0LXRgNC+0LIgKEJSQU5ELCDQkdCw0YDQsdC10YAsINCd0LDRh9C40L3QsNGO0YnQuNC5KT8nLFxuICAgIGE6ICdCUkFORC3QsdCw0YDQsdC10YAg0JzQsNC60YHRg9C0INC40LzQtdC10YIgMTAg0LvQtdGCINC/0YDQvtGE0LXRgdGB0LjQvtC90LDQu9GM0L3QvtCz0L4g0YHRgtCw0LbQsCDQuCDQstGL0L/QvtC70L3Rj9C10YIg0YHRgtGA0LjQttC60Lgg0Lgg0LHQvtGA0L7QtNGLINC70Y7QsdC+0Lkg0YHQu9C+0LbQvdC+0YHRgtC4LiDQkdCw0YDQsdC10YAg0KHQuNGA0L7QttC40LTQuNC9IOKAlCDQvNCw0YHRgtC10YAg0L3QvtCy0L7QuSDRiNC60L7Qu9GLINGBINC/0L7QtNGC0LLQtdGA0LbQtNGR0L3QvdGL0Lwg0YDQtdC50YLQuNC90LPQvtC8IDUuMCDQsiAy0JPQmNChLiDQndCw0YfQuNC90LDRjtGJ0LjQuSDQsdCw0YDQsdC10YAg0JbQsNC80YjQuNC0INGB0YLRgNC40LbRkdGCINC/0L4g0YHRgtGA0L7Qs9C40Lwg0YTQuNGA0LzQtdC90L3Ri9C8INGB0YLQsNC90LTQsNGA0YLQsNC8INC/0L7QtCDQutC+0L3RgtGA0L7Qu9C10Lwg0LHRgNC10L3QtNCwINC/0L4g0LTQvtGB0YLRg9C/0L3QvtC5INGB0YLQvtC40LzQvtGB0YLQuC4nLFxuICB9LFxuICB7XG4gICAgcTogJ9Ca0LDQutC40LUg0YPQtNC+0LHRgdGC0LLQsCDQv9GA0LXQtNC+0YHRgtCw0LLQu9GP0Y7RgtGB0Y8g0LHQtdGB0L/Qu9Cw0YLQvdC+INCyINC60LDQttC00YvQuSDQstC40LfQuNGCPycsXG4gICAgYTogJ9CU0LvRjyDQstGB0LXRhSDQs9C+0YHRgtC10Lkg0LHQtdGB0L/Qu9Cw0YLQvdC+OiDRh9Cw0YjQutCwINC60L7RhNC1INC40LvQuCDRh9Cw0Y8sINGB0L3QtdC60LgsINCy0YvRgdC+0LrQvtGB0LrQvtGA0L7RgdGC0L3QvtC5IFdpLUZpLCDQt9C+0L3QsCDQvtGC0LTRi9GF0LAg0YEg0LrQvtC90YHQvtC70YzRjiBQbGF5U3RhdGlvbiA1LCDQv9Cw0YDQutC+0LLQutCwINGDINCy0YXQvtC00LAg0Lgg0LTQstGD0LrRgNCw0YLQvdC+0LUg0LzRi9GC0YzRkSDQs9C+0LvQvtCy0YsuJyxcbiAgfSxcbiAge1xuICAgIHE6ICfQoSDQutCw0LrQvtCz0L4g0LLQvtC30YDQsNGB0YLQsCDQstGLINGB0YLRgNC40LbRkdGC0LUg0LTQtdGC0LXQuT8nLFxuICAgIGE6ICfQnNGLINCy0YvQv9C+0LvQvdGP0LXQvCDQtNC10YLRgdC60LjQtSDRgdGC0YDQuNC20LrQuCDQtNC+IDEwINC70LXRgiwg0LAg0YLQsNC60LbQtSDQv9GA0LXQtNC70LDQs9Cw0LXQvCDQutC+0LzQv9C70LXQutGBIMKr0J7RgtC10YYgKyDRgdGL0L3Cuy4g0JzQsNGB0YLQtdGA0LAg0L3QsNGF0L7QtNGP0YIg0L/QvtC00YXQvtC0INC6INC60LDQttC00L7QvNGDINGA0LXQsdGR0L3QutGDINC4INGA0LDQsdC+0YLQsNGO0YIg0LHQtdGA0LXQttC90L4sINCw0LrQutGD0YDQsNGC0L3QviDQuCDRgdC/0L7QutC+0LnQvdC+LicsXG4gIH0sXG4gIHtcbiAgICBxOiAn0JrQsNC60L7QuSDRgyDQstCw0YEg0LPRgNCw0YTQuNC6INGA0LDQsdC+0YLRiyDQuCDQs9C00LUg0L3QsNGF0L7QtNC40YLRgdGPINCx0LDRgNCx0LXRgNGI0L7Qvz8nLFxuICAgIGE6ICfQnNGLINC90LDRhdC+0LTQuNC80YHRjyDQsiDQn9C10YDQvNC4INC/0L4g0LDQtNGA0LXRgdGDINCa0L7QvNGB0L7QvNC+0LvRjNGB0LrQuNC5INC/0YDQvtGB0L/QtdC60YIsIDg3ICjQodCy0LXRgNC00LvQvtCy0YHQutC40Lkg0YDQsNC50L7QvSwg0L/QtdGA0LXQutGA0ZHRgdGC0L7QuiDRgSDRg9C7LiDQmtC+0LzQuNC90YLQtdGA0L3QsCkuINCT0YDQsNGE0LjQuiDRgNCw0LHQvtGC0Ys6INCf0L3igJPQp9GCIDEwOjAw4oCTMjI6MDAsINCf0YIgMTA6MDDigJMxMzowMCDQuCAxNTowMOKAkzIyOjAwLCDQodCx4oCT0JLRgSAxMDowMOKAkzIyOjAwLicsXG4gIH0sXG4gIHtcbiAgICBxOiAn0JzQvtC20L3QviDQu9C4INC30LDQv9C40YHQsNGC0YzRgdGPINC6INC60L7QvdC60YDQtdGC0L3QvtC80YMg0LzQsNGB0YLQtdGA0YM/JyxcbiAgICBhOiAn0JTQsC4g0JIg0LHQu9C+0LrQtSDCq9CX0LDQv9C40YHQsNGC0YzRgdGPINC6INGB0L/QtdGG0LjQsNC70LjRgdGC0YPCuyDQuNC70Lgg0L/RgNGP0LzQviDQsiBEaWtpZGkg0LLRiyDQvNC+0LbQtdGC0LUg0LLRi9Cx0YDQsNGC0Ywg0L/QtdGA0YHQvtC90LDQu9GM0L3Rg9GOINC30LDQv9C40YHRjCDQuiDQnNCw0LrRgdGD0LTRgywg0KHQuNGA0L7QttC40LTQuNC90YMg0LjQu9C4INCW0LDQvNGI0LjQtNGDLCDQu9C40LHQviDQstGL0LHRgNCw0YLRjCDQvtCx0YnRg9GOINC30LDQv9C40YHRjCDQuiDQu9GO0LHQvtC80YMg0YHQstC+0LHQvtC00L3QvtC80YMg0LzQsNGB0YLQtdGA0YMuJyxcbiAgfSxcbl07XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEFwcCgpIHtcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUodHJ1ZSk7XG4gIGNvbnN0IFtzY3JvbGxQcm9ncmVzcywgc2V0U2Nyb2xsUHJvZ3Jlc3NdID0gdXNlU3RhdGUoMCk7XG4gIGNvbnN0IFtzY3JvbGxZUG9zLCBzZXRTY3JvbGxZUG9zXSA9IHVzZVN0YXRlKDApO1xuXG4gIC8vIEhlYWRlciBhdXRvLWhpZGUgc3RhdGVcbiAgY29uc3QgW2hlYWRlclZpc2libGUsIHNldEhlYWRlclZpc2libGVdID0gdXNlU3RhdGUodHJ1ZSk7XG4gIGNvbnN0IGxhc3RTY3JvbGxZID0gdXNlUmVmKDApO1xuXG4gIC8vIE1vZGFscyAmIGZpbHRlcnNcbiAgY29uc3QgW3NlbGVjdGVkQ2F0ZWdvcnksIHNldFNlbGVjdGVkQ2F0ZWdvcnldID0gdXNlU3RhdGU8TWFzdGVyQ2F0ZWdvcnk+KCdqdW5pb3InKTtcbiAgY29uc3QgW3dvcmtzRmlsdGVyLCBzZXRXb3Jrc0ZpbHRlcl0gPSB1c2VTdGF0ZTwnYWxsJyB8ICdzaXJvemhpZGluJyB8ICdqYW1zaGlkJyB8ICdtYWtzdWQnPignYWxsJyk7XG4gIGNvbnN0IFtnYWxsZXJ5T3Blbiwgc2V0R2FsbGVyeU9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbZ2FsbGVyeUltYWdlcywgc2V0R2FsbGVyeUltYWdlc10gPSB1c2VTdGF0ZTx7IHNyYzogc3RyaW5nOyB0aXRsZTogc3RyaW5nOyBtYXN0ZXI/OiBzdHJpbmcgfVtdPihbXSk7XG4gIGNvbnN0IFtnYWxsZXJ5SW5kZXgsIHNldEdhbGxlcnlJbmRleF0gPSB1c2VTdGF0ZSgwKTtcbiAgY29uc3QgW3Nob3dTdGlja3lCb29raW5nLCBzZXRTaG93U3RpY2t5Qm9va2luZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtvcGVuRmFxLCBzZXRPcGVuRmFxXSA9IHVzZVN0YXRlPG51bWJlciB8IG51bGw+KDApO1xuICBjb25zdCBbZXhwb3J0TW9kYWxPcGVuLCBzZXRFeHBvcnRNb2RhbE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gIC8vIEFuaW1hdGVkIGNvdW50ZXJzXG4gIGNvbnN0IFtyYXRpbmdDb3VudCwgc2V0UmF0aW5nQ291bnRdID0gdXNlU3RhdGUoMCk7XG4gIGNvbnN0IFtsaXRTdGFycywgc2V0TGl0U3RhcnNdID0gdXNlU3RhdGUoMCk7XG5cbiAgY29uc3QgaGVyb1JlZiA9IHVzZVJlZjxIVE1MRWxlbWVudD4obnVsbCk7XG4gIGNvbnN0IGNvbnRhY3RzUmVmID0gdXNlUmVmPEhUTUxFbGVtZW50PihudWxsKTtcbiAgY29uc3QgYWJvdXRSZWYgPSB1c2VSZWY8SFRNTEVsZW1lbnQ+KG51bGwpO1xuXG4gIC8vIExlbmlzIGluaXRpYWxpemF0aW9uICYgc21vb3RoIHNjcm9sbFxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IHdpbiA9IHdpbmRvdyBhcyBhbnk7XG4gICAgbGV0IGxlbmlzSW5zdGFuY2U6IGFueSA9IG51bGw7XG4gICAgaWYgKHdpbi5MZW5pcykge1xuICAgICAgbGVuaXNJbnN0YW5jZSA9IG5ldyB3aW4uTGVuaXMoe1xuICAgICAgICBkdXJhdGlvbjogMS4xLFxuICAgICAgICBlYXNpbmc6ICh0OiBudW1iZXIpID0+IE1hdGgubWluKDEsIDEuMDAxIC0gTWF0aC5wb3coMiwgLTEwICogdCkpLFxuICAgICAgICBvcmllbnRhdGlvbjogJ3ZlcnRpY2FsJyxcbiAgICAgICAgc21vb3RoV2hlZWw6IHRydWUsXG4gICAgICB9KTtcblxuICAgICAgZnVuY3Rpb24gcmFmKHRpbWU6IG51bWJlcikge1xuICAgICAgICBsZW5pc0luc3RhbmNlLnJhZih0aW1lKTtcbiAgICAgICAgcmVxdWVzdEFuaW1hdGlvbkZyYW1lKHJhZik7XG4gICAgICB9XG4gICAgICByZXF1ZXN0QW5pbWF0aW9uRnJhbWUocmFmKTtcbiAgICB9XG5cbiAgICBjb25zdCB0aW1lciA9IHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XG4gICAgfSwgOTAwKTtcblxuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBjbGVhclRpbWVvdXQodGltZXIpO1xuICAgICAgaWYgKGxlbmlzSW5zdGFuY2UpIGxlbmlzSW5zdGFuY2UuZGVzdHJveSgpO1xuICAgIH07XG4gIH0sIFtdKTtcblxuICAvLyBTY3JvbGwgbGlzdGVuZXJcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBsZXQgdGlja2luZyA9IGZhbHNlO1xuXG4gICAgY29uc3Qgb25TY3JvbGwgPSAoKSA9PiB7XG4gICAgICBpZiAoIXRpY2tpbmcpIHtcbiAgICAgICAgd2luZG93LnJlcXVlc3RBbmltYXRpb25GcmFtZSgoKSA9PiB7XG4gICAgICAgICAgY29uc3QgdG90YWxIZWlnaHQgPSBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuc2Nyb2xsSGVpZ2h0IC0gd2luZG93LmlubmVySGVpZ2h0O1xuICAgICAgICAgIGNvbnN0IGN1cnJlbnRTY3JvbGwgPSB3aW5kb3cuc2Nyb2xsWTtcbiAgICAgICAgICBjb25zdCBwcm9ncmVzcyA9IHRvdGFsSGVpZ2h0ID4gMCA/IChjdXJyZW50U2Nyb2xsIC8gdG90YWxIZWlnaHQpICogMTAwIDogMDtcbiAgICAgICAgICBzZXRTY3JvbGxQcm9ncmVzcyhwcm9ncmVzcyk7XG4gICAgICAgICAgc2V0U2Nyb2xsWVBvcyhjdXJyZW50U2Nyb2xsKTtcblxuICAgICAgICAgIC8vIEhlYWRlciBoaWRlIG9uIHNjcm9sbCBkb3duLCBzaG93IG9uIHNjcm9sbCB1cFxuICAgICAgICAgIGlmIChjdXJyZW50U2Nyb2xsID4gMTIwKSB7XG4gICAgICAgICAgICBpZiAoY3VycmVudFNjcm9sbCA+IGxhc3RTY3JvbGxZLmN1cnJlbnQgKyA2KSB7XG4gICAgICAgICAgICAgIHNldEhlYWRlclZpc2libGUoZmFsc2UpO1xuICAgICAgICAgICAgfSBlbHNlIGlmIChjdXJyZW50U2Nyb2xsIDwgbGFzdFNjcm9sbFkuY3VycmVudCAtIDYpIHtcbiAgICAgICAgICAgICAgc2V0SGVhZGVyVmlzaWJsZSh0cnVlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgc2V0SGVhZGVyVmlzaWJsZSh0cnVlKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgbGFzdFNjcm9sbFkuY3VycmVudCA9IGN1cnJlbnRTY3JvbGw7XG5cbiAgICAgICAgICAvLyBTdGlja3kgYm9va2luZyBidXR0b24gdmlzaWJpbGl0eVxuICAgICAgICAgIGNvbnN0IGhlcm8gPSBoZXJvUmVmLmN1cnJlbnQ7XG4gICAgICAgICAgY29uc3QgY29udGFjdHMgPSBjb250YWN0c1JlZi5jdXJyZW50O1xuICAgICAgICAgIGlmIChoZXJvICYmIGNvbnRhY3RzKSB7XG4gICAgICAgICAgICBjb25zdCBoZXJvQm90dG9tID0gaGVyby5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS5ib3R0b207XG4gICAgICAgICAgICBjb25zdCBjb250YWN0c1RvcCA9IGNvbnRhY3RzLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLnRvcDtcbiAgICAgICAgICAgIGNvbnN0IHdpbmRvd0hlaWdodCA9IHdpbmRvdy5pbm5lckhlaWdodDtcbiAgICAgICAgICAgIGNvbnN0IGFmdGVySGVybyA9IGhlcm9Cb3R0b20gPCAwO1xuICAgICAgICAgICAgY29uc3QgYmVmb3JlQ29udGFjdHMgPSBjb250YWN0c1RvcCA+IHdpbmRvd0hlaWdodCAtIDkwO1xuICAgICAgICAgICAgc2V0U2hvd1N0aWNreUJvb2tpbmcoYWZ0ZXJIZXJvICYmIGJlZm9yZUNvbnRhY3RzKTtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICB0aWNraW5nID0gZmFsc2U7XG4gICAgICAgIH0pO1xuICAgICAgICB0aWNraW5nID0gdHJ1ZTtcbiAgICAgIH1cbiAgICB9O1xuXG4gICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ3Njcm9sbCcsIG9uU2Nyb2xsLCB7IHBhc3NpdmU6IHRydWUgfSk7XG4gICAgcmV0dXJuICgpID0+IHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKCdzY3JvbGwnLCBvblNjcm9sbCk7XG4gIH0sIFtdKTtcblxuICAvLyBDb3VudGluZyByYXRpbmcgJiBsaWdodGluZyBzdGFycyBpbiBBYm91dCAmIFJldmlld3NcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCBvYnNlcnZlciA9IG5ldyBJbnRlcnNlY3Rpb25PYnNlcnZlcihcbiAgICAgIChbZW50cnldKSA9PiB7XG4gICAgICAgIGlmIChlbnRyeS5pc0ludGVyc2VjdGluZykge1xuICAgICAgICAgIGxldCBjdXJyZW50ID0gMDtcbiAgICAgICAgICBjb25zdCBpbnRlcnZhbCA9IHNldEludGVydmFsKCgpID0+IHtcbiAgICAgICAgICAgIGN1cnJlbnQgKz0gMC41O1xuICAgICAgICAgICAgaWYgKGN1cnJlbnQgPj0gNS4wKSB7XG4gICAgICAgICAgICAgIHNldFJhdGluZ0NvdW50KDUuMCk7XG4gICAgICAgICAgICAgIGNsZWFySW50ZXJ2YWwoaW50ZXJ2YWwpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgc2V0UmF0aW5nQ291bnQoTnVtYmVyKGN1cnJlbnQudG9GaXhlZCgxKSkpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH0sIDYwKTtcblxuICAgICAgICAgIGZvciAobGV0IGkgPSAxOyBpIDw9IDU7IGkrKykge1xuICAgICAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgICAgIHNldExpdFN0YXJzKGkpO1xuICAgICAgICAgICAgfSwgaSAqIDE1MCk7XG4gICAgICAgICAgfVxuICAgICAgICAgIG9ic2VydmVyLmRpc2Nvbm5lY3QoKTtcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIHsgdGhyZXNob2xkOiAwLjMgfVxuICAgICk7XG5cbiAgICBpZiAoYWJvdXRSZWYuY3VycmVudCkge1xuICAgICAgb2JzZXJ2ZXIub2JzZXJ2ZShhYm91dFJlZi5jdXJyZW50KTtcbiAgICB9XG4gICAgcmV0dXJuICgpID0+IG9ic2VydmVyLmRpc2Nvbm5lY3QoKTtcbiAgfSwgW10pO1xuXG4gIC8vIEZpbHRlcmVkIHdvcmtzXG4gIGNvbnN0IGZpbHRlcmVkV29ya3MgPVxuICAgIHdvcmtzRmlsdGVyID09PSAnYWxsJyA/IEFMTF9XT1JLUyA6IEFMTF9XT1JLUy5maWx0ZXIoKHcpID0+IHcubWFzdGVySWQgPT09IHdvcmtzRmlsdGVyKTtcblxuICBjb25zdCBvcGVuV29ya01vZGFsID0gKGl0ZW06IFdvcmtJdGVtKSA9PiB7XG4gICAgY29uc3QgaW1hZ2VzID0gZmlsdGVyZWRXb3Jrcy5tYXAoKHcpID0+ICh7XG4gICAgICBzcmM6IHcuc3JjLFxuICAgICAgdGl0bGU6IHcudGl0bGUsXG4gICAgICBtYXN0ZXI6IHcubWFzdGVyTmFtZSxcbiAgICB9KSk7XG4gICAgY29uc3QgaW5kZXggPSBmaWx0ZXJlZFdvcmtzLmZpbmRJbmRleCgodykgPT4gdy5pZCA9PT0gaXRlbS5pZCk7XG4gICAgc2V0R2FsbGVyeUltYWdlcyhpbWFnZXMpO1xuICAgIHNldEdhbGxlcnlJbmRleChpbmRleCA+PSAwID8gaW5kZXggOiAwKTtcbiAgICBzZXRHYWxsZXJ5T3Blbih0cnVlKTtcbiAgfTtcblxuICBjb25zdCBvcGVuTWFzdGVyV29ya01vZGFsID0gKG1hc3RlcldvcmtzOiBXb3JrSXRlbVtdLCBpZHg6IG51bWJlcikgPT4ge1xuICAgIGNvbnN0IGltYWdlcyA9IG1hc3RlcldvcmtzLm1hcCgodykgPT4gKHtcbiAgICAgIHNyYzogdy5zcmMsXG4gICAgICB0aXRsZTogdy50aXRsZSxcbiAgICAgIG1hc3Rlcjogdy5tYXN0ZXJOYW1lLFxuICAgIH0pKTtcbiAgICBzZXRHYWxsZXJ5SW1hZ2VzKGltYWdlcyk7XG4gICAgc2V0R2FsbGVyeUluZGV4KGlkeCk7XG4gICAgc2V0R2FsbGVyeU9wZW4odHJ1ZSk7XG4gIH07XG5cbiAgY29uc3Qgc2Nyb2xsVG9Ub3AgPSAoKSA9PiB7XG4gICAgd2luZG93LnNjcm9sbFRvKHsgdG9wOiAwLCBiZWhhdmlvcjogJ3Ntb290aCcgfSk7XG4gIH07XG5cbiAgLy8gUHJpY2UgQ1RBIGJ1dHRvbiBsaW5rICYgdGl0bGUgbWFwcGVkIHRvIGFjdGl2ZSB0YWJcbiAgY29uc3QgcHJpY2VCdXR0b25Db25maWcgPSB7XG4gICAgYnJhbmQ6IHtcbiAgICAgIHRleHQ6ICfQl9Cw0L/QuNGB0LDRgtGM0YHRjyDQuiDQnNCw0LrRgdGD0LTRgycsXG4gICAgICB1cmw6IERJS0lESV9NQUtTVUQsXG4gICAgfSxcbiAgICBiYXJiZXI6IHtcbiAgICAgIHRleHQ6ICfQl9Cw0L/QuNGB0LDRgtGM0YHRjyDQuiDQodC40YDQvtC20LjQtNC40L3RgycsXG4gICAgICB1cmw6IERJS0lESV9TSVJPWkhJRElOLFxuICAgIH0sXG4gICAganVuaW9yOiB7XG4gICAgICB0ZXh0OiAn0JfQsNC/0LjRgdCw0YLRjNGB0Y8g0Log0JbQsNC80YjQuNC00YMnLFxuICAgICAgdXJsOiBESUtJRElfWkhBTVNISUQsXG4gICAgfSxcbiAgfVtzZWxlY3RlZENhdGVnb3J5XTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgbWluLWgtc2NyZWVuIGJnLVsjRkJGOEY0XSB0ZXh0LVsjMTExMTExXSBvdmVyZmxvdy14LWhpZGRlblwiPlxuICAgICAgey8qIDAuIElOVFJPIFNQTEFTSCBDVVJUQUlOICovfVxuICAgICAgPGRpdlxuICAgICAgICBjbGFzc05hbWU9e2BmaXhlZCBpbnNldC0wIHotNTAgYmctWyMxMTExMTFdIGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRyYW5zaXRpb24tdHJhbnNmb3JtIGR1cmF0aW9uLTgwMCBlYXNlLVtjdWJpYy1iZXppZXIoMC4yMiwxLDAuMzYsMSldICR7XG4gICAgICAgICAgbG9hZGluZyA/ICd0cmFuc2xhdGUteS0wJyA6ICctdHJhbnNsYXRlLXktZnVsbCBwb2ludGVyLWV2ZW50cy1ub25lJ1xuICAgICAgICB9YH1cbiAgICAgICAgYXJpYS1oaWRkZW49eyFsb2FkaW5nfVxuICAgICAgPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyXCI+XG4gICAgICAgICAgPExvZ29WQiBzaXplPXs4OH0gY2xhc3NOYW1lPVwidy0yMiBoLTIyIHNoYWRvdy0yeGwgYm9yZGVyLTIgYm9yZGVyLXdoaXRlLzIwXCIgLz5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWRpc3BsYXkgdGV4dC13aGl0ZSB0ZXh0LTJ4bCBzbTp0ZXh0LTN4bCB0cmFja2luZy13aWRlc3QgbXQtNSB1cHBlcmNhc2VcIj5cbiAgICAgICAgICAgINCS0J3QlSDQktCg0JXQnNCV0J3QmFxuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXdoaXRlLzYwIHRleHQteHMgZm9udC1tb25vIHRyYWNraW5nLXdpZGVzdCBtdC0xLjUgdXBwZXJjYXNlXCI+XG4gICAgICAgICAgICDQkdCw0YDQsdC10YDRiNC+0L8gwrcg0J/QtdGA0LzRjFxuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIFRPUCBQUk9HUkVTUyBCQVIgKEJhcmJlciBwb2xlIHN0cmlwZSBzY3JvbGwgaW5kaWNhdG9yKSAqL31cbiAgICAgIDxkaXZcbiAgICAgICAgY2xhc3NOYW1lPVwiZml4ZWQgdG9wLTAgbGVmdC0wIHotNTAgaC0xIGJhcmJlci1wb2xlLXN0cmlwZSB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0xNTAgZWFzZS1vdXQgcG9pbnRlci1ldmVudHMtbm9uZVwiXG4gICAgICAgIHN0eWxlPXt7IHdpZHRoOiBgJHtzY3JvbGxQcm9ncmVzc30lYCB9fVxuICAgICAgICBhcmlhLWhpZGRlbj1cInRydWVcIlxuICAgICAgLz5cblxuICAgICAgey8qIEhFQURFUiAqL31cbiAgICAgIDxoZWFkZXJcbiAgICAgICAgY2xhc3NOYW1lPXtgc3RpY2t5IHRvcC0wIHotNDAgYmctWyNGQkY4RjRdLzk1IGJhY2tkcm9wLWJsdXItbWQgYm9yZGVyLWIgYm9yZGVyLWJsYWNrLzggcHgtNCBzbTpweC04IHB5LTMuNSB0cmFuc2l0aW9uLXRyYW5zZm9ybSBkdXJhdGlvbi0zMDAgZWFzZS1pbi1vdXQgJHtcbiAgICAgICAgICBoZWFkZXJWaXNpYmxlID8gJ3RyYW5zbGF0ZS15LTAnIDogJy10cmFuc2xhdGUteS1mdWxsJ1xuICAgICAgICB9YH1cbiAgICAgID5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXgtdy03eGwgbXgtYXV0byBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTRcIj5cbiAgICAgICAgICB7LyogTG9nbyBTaWduICg0NHB4KSBhbmQgQnJhbmQgVGl0bGUgKi99XG4gICAgICAgICAgPGFcbiAgICAgICAgICAgIGhyZWY9XCIjXCJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHNocmluay0wIGdyb3VwIGZvY3VzLXZpc2libGU6b3V0bGluZS0yIGZvY3VzLXZpc2libGU6b3V0bGluZS1bI0M4MTAyRV1cIlxuICAgICAgICAgICAgYXJpYS1sYWJlbD1cItCR0LDRgNCx0LXRgNGI0L7QvyDQktC90LUg0JLRgNC10LzQtdC90Lgg0JPQu9Cw0LLQvdCw0Y9cIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxMb2dvVkIgc2l6ZT17NDR9IGNsYXNzTmFtZT1cImdyb3VwLWhvdmVyOnNjYWxlLTEwNSB0cmFuc2l0aW9uLXRyYW5zZm9ybSBkdXJhdGlvbi0zMDBcIiAvPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1kaXNwbGF5IHRleHQtbGcgc206dGV4dC14bCB0cmFja2luZy10aWdodCB0ZXh0LVsjMTExMTExXSB3aGl0ZXNwYWNlLW5vd3JhcFwiPlxuICAgICAgICAgICAgICDQktCd0JUg0JLQoNCV0JzQldCd0JhcbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICA8L2E+XG5cbiAgICAgICAgICB7LyogTmF2aWdhdGlvbiAqL31cbiAgICAgICAgICA8bmF2IGNsYXNzTmFtZT1cImhpZGRlbiBsZzpmbGV4IGl0ZW1zLWNlbnRlciBnYXAtOCB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtYmxhY2svNzVcIj5cbiAgICAgICAgICAgIDxhIGhyZWY9XCIjYWJvdXRcIiBjbGFzc05hbWU9XCJob3Zlcjp0ZXh0LVsjQzgxMDJFXSB0cmFuc2l0aW9uLWNvbG9ycyB3aGl0ZXNwYWNlLW5vd3JhcFwiPlxuICAgICAgICAgICAgICDQniDQvdCw0YFcbiAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICAgIDxhIGhyZWY9XCIjZnJlZVwiIGNsYXNzTmFtZT1cImhvdmVyOnRleHQtWyNDODEwMkVdIHRyYW5zaXRpb24tY29sb3JzIHdoaXRlc3BhY2Utbm93cmFwXCI+XG4gICAgICAgICAgICAgINCR0LXRgdC/0LvQsNGC0L3QvlxuICAgICAgICAgICAgPC9hPlxuICAgICAgICAgICAgPGEgaHJlZj1cIiNtYXN0ZXJzXCIgY2xhc3NOYW1lPVwiaG92ZXI6dGV4dC1bI0M4MTAyRV0gdHJhbnNpdGlvbi1jb2xvcnMgd2hpdGVzcGFjZS1ub3dyYXBcIj5cbiAgICAgICAgICAgICAg0JzQsNGB0YLQtdGA0LBcbiAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICAgIDxhIGhyZWY9XCIjd29ya3NcIiBjbGFzc05hbWU9XCJob3Zlcjp0ZXh0LVsjQzgxMDJFXSB0cmFuc2l0aW9uLWNvbG9ycyB3aGl0ZXNwYWNlLW5vd3JhcFwiPlxuICAgICAgICAgICAgICDQoNCw0LHQvtGC0YtcbiAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICAgIDxhIGhyZWY9XCIjcHJpY2luZ1wiIGNsYXNzTmFtZT1cImhvdmVyOnRleHQtWyNDODEwMkVdIHRyYW5zaXRpb24tY29sb3JzIHdoaXRlc3BhY2Utbm93cmFwXCI+XG4gICAgICAgICAgICAgINCf0YDQsNC50YFcbiAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICAgIDxhIGhyZWY9XCIjcmV2aWV3c1wiIGNsYXNzTmFtZT1cImhvdmVyOnRleHQtWyNDODEwMkVdIHRyYW5zaXRpb24tY29sb3JzIHdoaXRlc3BhY2Utbm93cmFwXCI+XG4gICAgICAgICAgICAgINCe0YLQt9GL0LLRi1xuICAgICAgICAgICAgPC9hPlxuICAgICAgICAgICAgPGEgaHJlZj1cIiNib29raW5nXCIgY2xhc3NOYW1lPVwiaG92ZXI6dGV4dC1bI0M4MTAyRV0gdHJhbnNpdGlvbi1jb2xvcnMgd2hpdGVzcGFjZS1ub3dyYXBcIj5cbiAgICAgICAgICAgICAg0JfQsNC/0LjRgdGMXG4gICAgICAgICAgICA8L2E+XG4gICAgICAgICAgICA8YSBocmVmPVwiI2ZhcVwiIGNsYXNzTmFtZT1cImhvdmVyOnRleHQtWyNDODEwMkVdIHRyYW5zaXRpb24tY29sb3JzIHdoaXRlc3BhY2Utbm93cmFwXCI+XG4gICAgICAgICAgICAgIEZBUVxuICAgICAgICAgICAgPC9hPlxuICAgICAgICAgICAgPGEgaHJlZj1cIiNjb250YWN0c1wiIGNsYXNzTmFtZT1cImhvdmVyOnRleHQtWyNDODEwMkVdIHRyYW5zaXRpb24tY29sb3JzIHdoaXRlc3BhY2Utbm93cmFwXCI+XG4gICAgICAgICAgICAgINCa0L7QvdGC0LDQutGC0YtcbiAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICA8L25hdj5cblxuICAgICAgICAgIHsvKiBIZWFkZXIgQWN0aW9uIEJ1dHRvbiAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHNocmluay0wXCI+XG4gICAgICAgICAgICA8YVxuICAgICAgICAgICAgICBocmVmPXtESUtJRElfR0VORVJBTH1cbiAgICAgICAgICAgICAgdGFyZ2V0PVwiX2JsYW5rXCJcbiAgICAgICAgICAgICAgcmVsPVwibm9vcGVuZXIgbm9yZWZlcnJlclwiXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJ0bi1iYXJiZXIgcHgtNSBweS0yLjUgYmctYmxhY2sgdGV4dC13aGl0ZSB0ZXh0LXhzIHNtOnRleHQtc20gZm9udC1zZW1pYm9sZCB0cmFja2luZy13aWRlciB1cHBlcmNhc2Ugd2hpdGVzcGFjZS1ub3dyYXAgc2hhZG93LXNtIGZvY3VzLXZpc2libGU6b3V0bGluZS0yIGZvY3VzLXZpc2libGU6b3V0bGluZS1bI0M4MTAyRV1cIlxuICAgICAgICAgICAgICBhcmlhLWxhYmVsPVwi0JfQsNC/0LjRgdCw0YLRjNGB0Y8g0L7QvdC70LDQudC9INCyINCx0LDRgNCx0LXRgNGI0L7QvyDQktC90LUg0LLRgNC10LzQtdC90Lgg0YfQtdGA0LXQtyBEaWtpZGlcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJidG4tZmlsbFwiIC8+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInJlbGF0aXZlIHotMTAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgIDxzcGFuPtCX0LDQv9C40YHQsNGC0YzRgdGPPC9zcGFuPlxuICAgICAgICAgICAgICAgIDxBcnJvd1VwUmlnaHQgY2xhc3NOYW1lPVwidy00IGgtNCBidG4tYXJyb3dcIiAvPlxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8L2E+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9oZWFkZXI+XG5cbiAgICAgIHsvKiAwMS4gSEVSTyAo0J/QldCg0JLQq9CZINCt0JrQoNCQ0J0pICovfVxuICAgICAgPHNlY3Rpb25cbiAgICAgICAgcmVmPXtoZXJvUmVmfVxuICAgICAgICBpZD1cImhlcm9cIlxuICAgICAgICBjbGFzc05hbWU9XCJyZWxhdGl2ZSBwdC0yIHBiLTEyIHNtOnBiLTIwIHB4LTQgc206cHgtOCBtYXgtdy03eGwgbXgtYXV0byBvdmVyZmxvdy1oaWRkZW5cIlxuICAgICAgPlxuICAgICAgICB7LyogUGFyYWxsYXggb3V0bGluZSB3YXRlcm1hcmsgJ9CS0J3QlSDQktCg0JXQnNCV0J3QmCcgKi99XG4gICAgICAgIDxkaXZcbiAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSAtdG9wLTYgbGVmdC0xLzIgLXRyYW5zbGF0ZS14LTEvMiBzZWxlY3Qtbm9uZSBwb2ludGVyLWV2ZW50cy1ub25lIGZvbnQtZGlzcGxheSB0ZXh0LVsxNXZ3XSBsZWFkaW5nLW5vbmUgd2hpdGVzcGFjZS1ub3dyYXAgdHJhY2tpbmctdGlnaHRlciB0ZXh0LXN0cm9rZS1zdWJ0bGUgei0wXCJcbiAgICAgICAgICBzdHlsZT17eyB0cmFuc2Zvcm06IGB0cmFuc2xhdGUoLTUwJSwgJHtzY3JvbGxZUG9zICogMC4xOH1weClgIH19XG4gICAgICAgICAgYXJpYS1oaWRkZW49XCJ0cnVlXCJcbiAgICAgICAgPlxuICAgICAgICAgINCS0J3QlSDQktCg0JXQnNCV0J3QmFxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogRmxvYXRpbmcgQmFyYmVyIFRvb2w6IENvbWIgJiBSYXpvciAqL31cbiAgICAgICAgPGRpdlxuICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIHJpZ2h0LTggdG9wLTE2IHNlbGVjdC1ub25lIHBvaW50ZXItZXZlbnRzLW5vbmUgb3BhY2l0eS0yMCBoaWRkZW4gbWQ6YmxvY2sgdGV4dC1ibGFja1wiXG4gICAgICAgICAgc3R5bGU9e3sgdHJhbnNmb3JtOiBgdHJhbnNsYXRlWSgke3Njcm9sbFlQb3MgKiAtMC4xMn1weCkgcm90YXRlKDE1ZGVnKWAgfX1cbiAgICAgICAgICBhcmlhLWhpZGRlbj1cInRydWVcIlxuICAgICAgICA+XG4gICAgICAgICAgPFN0cmFpZ2h0UmF6b3JJY29uIHNpemU9ezcyfSAvPlxuICAgICAgICA8L2Rpdj5cblxuXG4gICAgICAgIHsvKiBIRVJPIFBIT1RPOiA0LzMgYXNwZWN0LCB1bmNyb3BwZWQgbmVvbiBzaWduICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHctZnVsbCBhc3BlY3QtWzQvM10gcm91bmRlZC14bCBvdmVyZmxvdy12aXNpYmxlIHNoYWRvdy0yeGwgYm9yZGVyIGJvcmRlci1ibGFjay8xMCBiZy1ibGFjay81IHotMTAgbXktNCBzbTpteS02XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgaC1mdWxsIHJvdW5kZWQteGwgb3ZlcmZsb3ctaGlkZGVuXCI+XG4gICAgICAgICAgICA8aW1nXG4gICAgICAgICAgICAgIHNyYz1cIi9hc3NldHMvYWlzdHVkaW8vSU1HXzc3NDBfYWE0NGU3MTQuanBlZ1wiXG4gICAgICAgICAgICAgIGFsdD1cItCS0YXQvtC0INC4INGE0LDRgdCw0LQg0LHQsNGA0LHQtdGA0YjQvtC/0LAg0JLQvdC1INCy0YDQtdC80LXQvdC4INGBINCy0YvQstC10YHQutC+0Lkg0Lgg0LHQsNGA0LHQtdGALdC/0L7Qu9C+0Lwg0L3QsCDQmtC+0LzRgdC+0LzQvtC70YzRgdC60L7QvCDQv9GA0L7RgdC/0LXQutGC0LUsIDg3XCJcbiAgICAgICAgICAgICAgbG9hZGluZz1cImVhZ2VyXCJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtZnVsbCBvYmplY3QtY292ZXIgdHJhbnNpdGlvbi10cmFuc2Zvcm0gZHVyYXRpb24tMTAwMCBlYXNlLW91dCBob3ZlcjpzY2FsZS0xMDNcIlxuICAgICAgICAgICAgICBzdHlsZT17eyBvYmplY3RQb3NpdGlvbjogJ2NlbnRlciAzNSUnIH19XG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIFNvbGlkIEJsYWNrIEhlcm8gU2VhbCAoMTIwcHggZGlhbWV0ZXIgb24gZGVza3RvcCwgOTZweCBtb2JpbGUpICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgLWJvdHRvbS03IC1yaWdodC0zIHNtOi1ib3R0b20tMTAgc206LXJpZ2h0LTYgei0zMCB3LTI0IGgtMjQgc206dy0zMiBzbTpoLTMyIHNlbGVjdC1ub25lIG92ZXJmbG93LXZpc2libGVcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgdy1mdWxsIGgtZnVsbCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxuICAgICAgICAgICAgICB7LyogU29saWQgMTIwcHggYmxhY2sgY2lyY2xlIGJhY2tncm91bmQgKi99XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQtMCByb3VuZGVkLWZ1bGwgYmctYmxhY2sgc2hhZG93LTJ4bCBib3JkZXIgYm9yZGVyLXdoaXRlLzIwXCIgLz5cblxuICAgICAgICAgICAgICB7LyogV2hpdGUgY2lyY3VsYXIgdGV4dCByb3RhdGluZyAqL31cbiAgICAgICAgICAgICAgPHN2Z1xuICAgICAgICAgICAgICAgIHZpZXdCb3g9XCIwIDAgMTYwIDE2MFwiXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtZnVsbCBhbmltYXRlLXNwaW4tc2xvdyBvdmVyZmxvdy12aXNpYmxlIHJlbGF0aXZlIHotMTBcIlxuICAgICAgICAgICAgICAgIHN0eWxlPXt7IGFuaW1hdGlvbkR1cmF0aW9uOiBgJHtNYXRoLm1heCg2LCAyMCAtIHNjcm9sbFByb2dyZXNzICogMC4yKX1zYCB9fVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPHBhdGhcbiAgICAgICAgICAgICAgICAgIGlkPVwic2VhbENpcmNsZVBhdGhcIlxuICAgICAgICAgICAgICAgICAgZD1cIk0gODAsIDgwIG0gLTYyLCAwIGEgNjIsNjIgMCAxLDEgMTI0LDAgYSA2Miw2MiAwIDEsMSAtMTI0LDBcIlxuICAgICAgICAgICAgICAgICAgZmlsbD1cIm5vbmVcIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPHRleHQgY2xhc3NOYW1lPVwidGV4dC1bMTJweF0gZm9udC1kaXNwbGF5IGZvbnQtZXh0cmFib2xkIHRyYWNraW5nLVszLjhweF0gZmlsbC13aGl0ZSB1cHBlcmNhc2VcIj5cbiAgICAgICAgICAgICAgICAgIDx0ZXh0UGF0aCBocmVmPVwiI3NlYWxDaXJjbGVQYXRoXCIgc3RhcnRPZmZzZXQ9XCIwJVwiPlxuICAgICAgICAgICAgICAgICAgICDQktCd0JUg0JLQoNCV0JzQldCd0Jggwrcg0JHQkNCg0JHQldCg0KjQntCfIMK3INCf0JXQoNCc0KwgwrdcbiAgICAgICAgICAgICAgICAgIDwvdGV4dFBhdGg+XG4gICAgICAgICAgICAgICAgPC90ZXh0PlxuICAgICAgICAgICAgICA8L3N2Zz5cblxuICAgICAgICAgICAgICB7LyogT2ZmaWNpYWwgTG9nb1ZCIG1vbm9ncmFtIGluIGNlbnRlciAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC0wIG0tYXV0byB3LTEyIGgtMTIgc206dy0xNiBzbTpoLTE2IHJvdW5kZWQtZnVsbCBiZy1ibGFjayBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBvdmVyZmxvdy1oaWRkZW4gei0yMFwiPlxuICAgICAgICAgICAgICAgIDxMb2dvVkIgc2l6ZT17NjB9IGNsYXNzTmFtZT1cInctZnVsbCBoLWZ1bGwgYm9yZGVyIGJvcmRlci13aGl0ZS8zMCByb3VuZGVkLWZ1bGxcIiAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogQ29udGVudCBzZXF1ZW5jZSB1bmRlciBwaG90byAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC04IHNtOm10LTEyIG1heC13LTN4bCByZWxhdGl2ZSB6LTEwXCI+XG4gICAgICAgICAgey8qIEtpY2tlciAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQteHMgc206dGV4dC1zbSBmb250LXNlbWlib2xkIHRyYWNraW5nLXdpZGVyIHVwcGVyY2FzZSBtYi0zIHRleHQtYmxhY2svNzBcIj5cbiAgICAgICAgICAgIDxzcGFuPtCf0JXQoNCc0Kw8L3NwYW4+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsjQzgxMDJFXVwiPsK3PC9zcGFuPlxuICAgICAgICAgICAgPGFcbiAgICAgICAgICAgICAgaHJlZj17REdJU19VUkx9XG4gICAgICAgICAgICAgIHRhcmdldD1cIl9ibGFua1wiXG4gICAgICAgICAgICAgIHJlbD1cIm5vb3BlbmVyIG5vcmVmZXJyZXJcIlxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSB0ZXh0LVsjMTIzMDZCXSBmb250LWJvbGQgaG92ZXI6dW5kZXJsaW5lXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPFN0YXIgY2xhc3NOYW1lPVwidy00IGgtNCBmaWxsLVsjQzgxMDJFXSB0ZXh0LVsjQzgxMDJFXVwiIC8+XG4gICAgICAgICAgICAgIDxzcGFuPjUuMCDQkiAy0JPQmNChPC9zcGFuPlxuICAgICAgICAgICAgPC9hPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIEhlYWRsaW5lICovfVxuICAgICAgICAgIDxSZXZlYWxPblNjcm9sbCBhcz1cImgxXCIgZGVsYXk9ezEwMH0gY2xhc3NOYW1lPVwidGV4dC00eGwgc206dGV4dC02eGwgbGc6dGV4dC03eGwgZm9udC1kaXNwbGF5IGxlYWRpbmctWzAuOTVdIHRleHQtYmxhY2sgdHJhY2tpbmctdGlnaHRlciBtYi00XCI+XG4gICAgICAgICAgICDQktCd0JUg0JLQoNCV0JzQldCd0JhcbiAgICAgICAgICA8L1JldmVhbE9uU2Nyb2xsPlxuXG4gICAgICAgICAgey8qIFN1YnRpdGxlICovfVxuICAgICAgICAgIDxSZXZlYWxPblNjcm9sbCBhcz1cInBcIiBkZWxheT17MjAwfSBjbGFzc05hbWU9XCJ0ZXh0LWxnIHNtOnRleHQtMnhsIHRleHQtYmxhY2svODAgZm9udC1ub3JtYWwgbGVhZGluZy1yZWxheGVkIG1iLThcIj5cbiAgICAgICAgICAgINCc0YPQttGB0LrQuNC1INGB0YLRgNC40LbQutC4INC4INCx0YDQuNGC0YzRkSDQsiDQn9C10YDQvNC4INC90LAg0JrQvtC80YHQvtC80L7Qu9GM0YHQutC+0Lwg0L/RgNC+0YHQv9C10LrRgtC1LlxuICAgICAgICAgIDwvUmV2ZWFsT25TY3JvbGw+XG5cbiAgICAgICAgICB7LyogQWN0aW9uIEJ1dHRvbnMgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IGl0ZW1zLXN0cmV0Y2ggc206aXRlbXMtY2VudGVyIGdhcC00XCI+XG4gICAgICAgICAgICA8YVxuICAgICAgICAgICAgICBocmVmPXtESUtJRElfR0VORVJBTH1cbiAgICAgICAgICAgICAgdGFyZ2V0PVwiX2JsYW5rXCJcbiAgICAgICAgICAgICAgcmVsPVwibm9vcGVuZXIgbm9yZWZlcnJlclwiXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJ0bi1iYXJiZXIgcHgtOCBweS00IGJnLWJsYWNrIHRleHQtd2hpdGUgdGV4dC1jZW50ZXIgdGV4dC1zbSB0cmFja2luZy13aWRlc3Qgc2hhZG93LWxnIGZvY3VzLXZpc2libGU6b3V0bGluZS0yIGZvY3VzLXZpc2libGU6b3V0bGluZS1bI0M4MTAyRV1cIlxuICAgICAgICAgICAgICBhcmlhLWxhYmVsPVwi0JfQsNC/0LjRgdCw0YLRjNGB0Y8g0L7QvdC70LDQudC9INC90LAg0YHRgtGA0LjQttC60YNcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJidG4tZmlsbFwiIC8+XG4gICAgICAgICAgICAgIHsvKiAxOCUgR2xhcmUgc3dlZXAgYW5pbWF0aW9uICovfVxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC15LTAgdy0yMCBiZy1ncmFkaWVudC10by1yIGZyb20tdHJhbnNwYXJlbnQgdmlhLXdoaXRlLzE4IHRvLXRyYW5zcGFyZW50IHBvaW50ZXItZXZlbnRzLW5vbmUgYW5pbWF0ZS1nbGFyZVwiIC8+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInJlbGF0aXZlIHotMTAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8c3Bhbj7Ql9Cw0L/QuNGB0LDRgtGM0YHRjyDQvtC90LvQsNC50L08L3NwYW4+XG4gICAgICAgICAgICAgICAgPEFycm93VXBSaWdodCBjbGFzc05hbWU9XCJ3LTQgaC00IGJ0bi1hcnJvd1wiIC8+XG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDwvYT5cblxuICAgICAgICAgICAgPGFcbiAgICAgICAgICAgICAgaHJlZj1cIiNwcmljaW5nXCJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNiBweS00IGJvcmRlciBib3JkZXItYmxhY2svMjAgaG92ZXI6Ym9yZGVyLWJsYWNrIHRleHQtYmxhY2sgZm9udC1zZW1pYm9sZCB0ZXh0LXNtIHRyYWNraW5nLXdpZGUgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgaG92ZXI6YmctYmxhY2svNSB0cmFuc2l0aW9uLWNvbG9ycyBtaW4taC1bNDhweF0gZm9jdXMtdmlzaWJsZTpvdXRsaW5lLTIgZm9jdXMtdmlzaWJsZTpvdXRsaW5lLVsjQzgxMDJFXVwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxzcGFuPtCh0LzQvtGC0YDQtdGC0Ywg0YbQtdC90Ys8L3NwYW4+XG4gICAgICAgICAgICAgIDxDaGV2cm9uUmlnaHQgY2xhc3NOYW1lPVwidy00IGgtNCByb3RhdGUtOTBcIiAvPlxuICAgICAgICAgICAgPC9hPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogQW5pbWF0ZWQgY3V0dGluZyBzY2lzc29ycyBsaW5lIGRpdmlkZXIgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMTQgc206bXQtMTggcmVsYXRpdmUgdy1mdWxsIGgtOCBmbGV4IGl0ZW1zLWNlbnRlclwiPlxuICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIGxlZnQtMCB0b3AtMS8yIC10cmFuc2xhdGUteS0xLzIgaC0wLjUgYmctWyNDODEwMkVdIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTEwMCBlYXNlLW91dFwiXG4gICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogYCR7TWF0aC5taW4oMTAwLCBNYXRoLm1heCg2LCBzY3JvbGxQcm9ncmVzcyAqIDEuOCkpfSVgIH19XG4gICAgICAgICAgLz5cbiAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSByaWdodC0wIHRvcC0xLzIgLXRyYW5zbGF0ZS15LTEvMiBoLTAuNSBiZy1ibGFjay8xMFwiXG4gICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogYCR7TWF0aC5tYXgoMCwgMTAwIC0gTWF0aC5taW4oMTAwLCBNYXRoLm1heCg2LCBzY3JvbGxQcm9ncmVzcyAqIDEuOCkpKX0lYCB9fVxuICAgICAgICAgIC8+XG4gICAgICAgICAgPGRpdlxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTEvMiAtdHJhbnNsYXRlLXktMS8yIC10cmFuc2xhdGUteC0xLzIgdGV4dC1bI0M4MTAyRV0gdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMTAwIGVhc2Utb3V0XCJcbiAgICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICAgIGxlZnQ6IGAke01hdGgubWluKDk4LCBNYXRoLm1heCgyLCBzY3JvbGxQcm9ncmVzcyAqIDEuOCkpfSVgLFxuICAgICAgICAgICAgICB0cmFuc2Zvcm06IGB0cmFuc2xhdGUoLTUwJSwgLTUwJSkgcm90YXRlKCR7TWF0aC5zaW4oc2Nyb2xsWVBvcyAqIDAuMDUpICogMTUgLSA0NX1kZWcpYCxcbiAgICAgICAgICAgIH19XG4gICAgICAgICAgPlxuICAgICAgICAgICAgPFNjaXNzb3JzIGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvc2VjdGlvbj5cblxuICAgICAgey8qIFRXTyBUSUNLRVIgTUFSUVVFRSBMSU5FUyAoQmV0d2VlbiBIZXJvIGFuZCBGcmVlIEFtZW5pdGllcykgKi99XG4gICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJweS00IGJvcmRlci15IGJvcmRlci1ibGFjay8xMCBvdmVyZmxvdy1oaWRkZW4gYmctYmxhY2svMyBzZWxlY3Qtbm9uZVwiPlxuICAgICAgICB7LyogTGluZSAxOiBMZWZ0d2FyZCBtYXJxdWVlICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFuaW1hdGUtbWFycXVlZS1sZWZ0IGZsZXggaXRlbXMtY2VudGVyIGdhcC02IHdoaXRlc3BhY2Utbm93cmFwIHRleHQtc3Ryb2tlLWRhcmsgZm9udC1kaXNwbGF5IHRleHQtMnhsIHNtOnRleHQtM3hsIHRyYWNraW5nLXdpZGVyIHVwcGVyY2FzZVwiPlxuICAgICAgICAgIHtbLi4uQXJyYXkoNildLm1hcCgoXywgaSkgPT4gKFxuICAgICAgICAgICAgPHNwYW4ga2V5PXtpfSBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNlwiPlxuICAgICAgICAgICAgICA8c3Bhbj5CQVJCRVJTSE9QIMK3INCS0J3QlSDQktCg0JXQnNCV0J3QmCDCtyDQn9CV0KDQnNCsIMK3PC9zcGFuPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsjQzgxMDJFXSB0ZXh0LWxnIGZvbnQtc2Fuc1wiPuKcpjwvc3Bhbj5cbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICApKX1cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIExpbmUgMjogUmlnaHR3YXJkIG1hcnF1ZWUgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYW5pbWF0ZS1tYXJxdWVlLXJpZ2h0IGZsZXggaXRlbXMtY2VudGVyIGdhcC02IHdoaXRlc3BhY2Utbm93cmFwIHRleHQtc3Ryb2tlLWRhcmsgZm9udC1kaXNwbGF5IHRleHQtMnhsIHNtOnRleHQtM3hsIHRyYWNraW5nLXdpZGVyIHVwcGVyY2FzZSBtdC0yXCI+XG4gICAgICAgICAge1suLi5BcnJheSg2KV0ubWFwKChfLCBpKSA9PiAoXG4gICAgICAgICAgICA8c3BhbiBrZXk9e2l9IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC02XCI+XG4gICAgICAgICAgICAgIDxzcGFuPkZBREUgwrcgQkVBUkQgwrcgU1RZTEUgwrcgQ0xBU1NJQyDCtzwvc3Bhbj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bIzEyMzA2Ql0gdGV4dC1sZyBmb250LXNhbnNcIj7inKY8L3NwYW4+XG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgKSl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9zZWN0aW9uPlxuXG4gICAgICB7LyogMDIuINCR0JvQntCaIMKr0JIg0JrQkNCW0JTQq9CZINCS0JjQl9CY0KIg4oCUINCR0JXQodCf0JvQkNCi0J3QnsK7ICovfVxuICAgICAgPHNlY3Rpb24gaWQ9XCJmcmVlXCIgY2xhc3NOYW1lPVwicHktMTIgc206cHktMTYgcHgtNCBzbTpweC04IG1heC13LTd4bCBteC1hdXRvIHJlbGF0aXZlXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItOFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC14cyBzbTp0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ibGFjay82MCB0cmFja2luZy13aWRlciB1cHBlcmNhc2UgbWItMlwiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bI0M4MTAyRV0gZm9udC1ib2xkXCI+MDI8L3NwYW4+XG4gICAgICAgICAgICA8c3Bhbj4vPC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4+0KHQtdGA0LLQuNGBPC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxSZXZlYWxPblNjcm9sbCBhcz1cImgyXCIgY2xhc3NOYW1lPVwidGV4dC0zeGwgc206dGV4dC01eGwgZm9udC1kaXNwbGF5IHRleHQtYmxhY2sgbGVhZGluZy10aWdodFwiPlxuICAgICAgICAgICAg0JIg0JrQkNCW0JTQq9CZINCS0JjQl9CY0KIg4oCUINCR0JXQodCf0JvQkNCi0J3QnlxuICAgICAgICAgIDwvUmV2ZWFsT25TY3JvbGw+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiA2IEZsYXQgMXB4IFRpbGVzICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgbWQ6Z3JpZC1jb2xzLTMgZ2FwLTMgc206Z2FwLTRcIj5cbiAgICAgICAgICB7QU1FTklUSUVTX0xJU1QubWFwKChpdGVtLCBpZHgpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IEljb24gPSBpdGVtLmljb247XG4gICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAga2V5PXtpZHh9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZ3JvdXAgcmVsYXRpdmUgaC1bMTIwcHhdIHAtNCBiZy13aGl0ZSBib3JkZXIgYm9yZGVyLWJsYWNrLzE1IHJvdW5kZWQtbWQgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMjAwIGhvdmVyOmJnLVsjMTIzMDZCXSBhY3RpdmU6YmctWyMxMjMwNkJdIGZsZXggZmxleC1jb2wganVzdGlmeS1iZXR3ZWVuIGN1cnNvci1wb2ludGVyIHNlbGVjdC1ub25lXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydFwiPlxuICAgICAgICAgICAgICAgICAge2l0ZW0uY3VzdG9tUCA/IChcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1kaXNwbGF5IGZvbnQtYmxhY2sgdGV4dC14bCB0ZXh0LWJsYWNrLzc1IGdyb3VwLWhvdmVyOnRleHQtd2hpdGUgdHJhbnNpdGlvbi1jb2xvcnNcIj5cbiAgICAgICAgICAgICAgICAgICAgICBQXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICkgOiBJY29uID8gKFxuICAgICAgICAgICAgICAgICAgICA8SWNvbiBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtYmxhY2svNzUgZ3JvdXAtaG92ZXI6dGV4dC13aGl0ZSB0cmFuc2l0aW9uLWNvbG9yc1wiIC8+XG4gICAgICAgICAgICAgICAgICApIDogbnVsbH1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1zbSBzbTp0ZXh0LWJhc2UgdGV4dC1ibGFjayBncm91cC1ob3Zlcjp0ZXh0LXdoaXRlIHRyYW5zaXRpb24tY29sb3JzIGxlYWRpbmctc251Z1wiPlxuICAgICAgICAgICAgICAgICAge2l0ZW0udGl0bGV9XG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfSl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9zZWN0aW9uPlxuXG4gICAgICB7LyogMDMuIMKr0J4g0J3QkNChwrsgKNCk0JjQm9Ce0KHQntCk0JjQryDQmCDQotCe0KfQndCr0JUg0KTQkNCa0KLQqykgKi99XG4gICAgICA8c2VjdGlvblxuICAgICAgICByZWY9e2Fib3V0UmVmfVxuICAgICAgICBpZD1cImFib3V0XCJcbiAgICAgICAgY2xhc3NOYW1lPVwicHktMTIgc206cHktMTYgcHgtNCBzbTpweC04IG1heC13LTd4bCBteC1hdXRvIHJlbGF0aXZlIG92ZXJmbG93LWhpZGRlblwiXG4gICAgICA+XG4gICAgICAgIHsvKiBQYXJhbGxheCBvdXRsaW5lIHdhdGVybWFyayAnNS4wJyAqL31cbiAgICAgICAgPGRpdlxuICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIC10b3AtMTAgcmlnaHQtMTAgc2VsZWN0LW5vbmUgcG9pbnRlci1ldmVudHMtbm9uZSBmb250LWRpc3BsYXkgdGV4dC1bMTh2d10gbGVhZGluZy1ub25lIHRleHQtc3Ryb2tlLXN1YnRsZSB6LTBcIlxuICAgICAgICAgIHN0eWxlPXt7IHRyYW5zZm9ybTogYHRyYW5zbGF0ZVkoJHsoc2Nyb2xsWVBvcyAtIDEyMDApICogMC4xNX1weClgIH19XG4gICAgICAgICAgYXJpYS1oaWRkZW49XCJ0cnVlXCJcbiAgICAgICAgPlxuICAgICAgICAgIDUuMFxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogRmxvYXRpbmcgQmFyYmVyIFRvb2w6IENvbWIgKi99XG4gICAgICAgIDxkaXZcbiAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSBsZWZ0LTYgdG9wLTIwIHNlbGVjdC1ub25lIHBvaW50ZXItZXZlbnRzLW5vbmUgb3BhY2l0eS0xNSBoaWRkZW4gbWQ6YmxvY2sgdGV4dC1ibGFja1wiXG4gICAgICAgICAgc3R5bGU9e3sgdHJhbnNmb3JtOiBgdHJhbnNsYXRlWSgkeyhzY3JvbGxZUG9zIC0gMTIwMCkgKiAtMC4xfXB4KWAgfX1cbiAgICAgICAgICBhcmlhLWhpZGRlbj1cInRydWVcIlxuICAgICAgICA+XG4gICAgICAgICAgPENvbWJJY29uIHNpemU9ezY0fSAvPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogM0QgQmFyYmVyIFBvbGUgb24gcmlnaHQgZWRnZSAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSByaWdodC0xLjUgc206cmlnaHQtMyB0b3AtMTAgei0zMCB3LTE0IGgtNjQgc206aC04MCBoaWRkZW4gc206YmxvY2tcIj5cbiAgICAgICAgICA8QmFyYmVyUG9sZTNEIHNpZGU9XCJyaWdodFwiIGNsYXNzTmFtZT1cInctZnVsbCBoLWZ1bGxcIiAvPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtOnByLTE2IHJlbGF0aXZlIHotMTBcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQteHMgc206dGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtYmxhY2svNjAgdHJhY2tpbmctd2lkZXIgdXBwZXJjYXNlIG1iLTNcIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWyNDODEwMkVdIGZvbnQtYm9sZFwiPjAzPC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4+Lzwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuPtCeINC90LDRgTwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxSZXZlYWxPblNjcm9sbCBhcz1cImgyXCIgY2xhc3NOYW1lPVwidGV4dC0zeGwgc206dGV4dC01eGwgZm9udC1kaXNwbGF5IHRleHQtYmxhY2sgbWItNCBsZWFkaW5nLXRpZ2h0XCI+XG4gICAgICAgICAgICDQktCd0JUg0JLQoNCV0JzQldCd0JhcbiAgICAgICAgICA8L1JldmVhbE9uU2Nyb2xsPlxuXG4gICAgICAgICAgPFJldmVhbE9uU2Nyb2xsIGFzPVwicFwiIGRlbGF5PXsxMDB9IGNsYXNzTmFtZT1cInRleHQteGwgc206dGV4dC0yeGwgdGV4dC1ibGFjay84NSBtYXgtdy0zeGwgbGVhZGluZy1yZWxheGVkIG1iLTEwXCI+XG4gICAgICAgICAgICDQl9C00LXRgdGMINC90LUg0YHQv9C10YjQsNGCLiDQotC+0YfQvdC+0YHRgtGMINCyINC00LXRgtCw0LvRj9GFLCDRgdC/0L7QutC+0LnQvdGL0Lkg0YDQsNC30LPQvtCy0L7RgCDQuCDRgdGC0YDQuNC20LrQsCwg0YEg0LrQvtGC0L7RgNC+0Lkg0YXQvtGH0LXRgtGB0Y8g0LLRi9C50YLQuFxuICAgICAgICAgICAg0L3QsCDRg9C70LjRhtGDLlxuICAgICAgICAgIDwvUmV2ZWFsT25TY3JvbGw+XG5cbiAgICAgICAgICB7LyogVGhyZWUgY29yZSBwcmluY2lwbGVzICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMyBnYXAtNiBzbTpnYXAtOCBtYi0xMlwiPlxuICAgICAgICAgICAge1sn0KLQntCn0J3QntCh0KLQrCcsICfQodCf0J7QmtCe0JnQodCi0JLQmNCVJywgJ9CS0J3QmNCc0JDQndCY0JUnXS5tYXAoKHdvcmQsIGlkeCkgPT4gKFxuICAgICAgICAgICAgICA8ZGl2IGtleT17aWR4fSBjbGFzc05hbWU9XCJncm91cFwiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtMnhsIHNtOnRleHQtM3hsIGZvbnQtZGlzcGxheSB0cmFja2luZy10aWdodCB0ZXh0LWJsYWNrIGJsb2NrIG1iLTJcIj5cbiAgICAgICAgICAgICAgICAgIHt3b3JkfVxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtMC41IGJnLVsjQzgxMDJFXSB3LTE2IGdyb3VwLWhvdmVyOnctZnVsbCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi01MDAgZWFzZS1vdXRcIiAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICkpfVxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIFR3by1Db2x1bW4gRmFjdCBDYXJkcyAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgZ2FwLTQgbWF4LXctMnhsXCI+XG4gICAgICAgICAgICB7LyogQ2FyZCAxOiA1LjAgaW4gMkdJUyAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC02IGJnLXdoaXRlIGJvcmRlciBib3JkZXItYmxhY2svMTAgcm91bmRlZC1sZ1wiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtYmFzZWxpbmUgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LTR4bCBzbTp0ZXh0LTV4bCBmb250LWRpc3BsYXkgdGV4dC1bI0M4MTAyRV0gdGFidWxhci1udW1zXCI+XG4gICAgICAgICAgICAgICAgICB7cmF0aW5nQ291bnQudG9GaXhlZCgxKX1cbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC1ibGFjay82MCB1cHBlcmNhc2VcIj7QsiAy0JPQmNChPC9zcGFuPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSBteS0yXCI+XG4gICAgICAgICAgICAgICAge1sxLCAyLCAzLCA0LCA1XS5tYXAoKHN0YXJOdW0pID0+IChcbiAgICAgICAgICAgICAgICAgIDxTdGFyXG4gICAgICAgICAgICAgICAgICAgIGtleT17c3Rhck51bX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdy00IGgtNCB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0zMDAgJHtcbiAgICAgICAgICAgICAgICAgICAgICBzdGFyTnVtIDw9IGxpdFN0YXJzXG4gICAgICAgICAgICAgICAgICAgICAgICA/ICdmaWxsLVsjQzgxMDJFXSB0ZXh0LVsjQzgxMDJFXSdcbiAgICAgICAgICAgICAgICAgICAgICAgIDogJ3RleHQtYmxhY2svMTUnXG4gICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdXBwZXJjYXNlIGZvbnQtbWVkaXVtIHRleHQtYmxhY2svNjBcIj5cbiAgICAgICAgICAgICAgICDQoNC10LnRgtC40L3QsyDQsiAy0JPQmNChXG4gICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogQ2FyZCAyOiBTY2hlZHVsZSAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC02IGJnLXdoaXRlIGJvcmRlciBib3JkZXItYmxhY2svMTAgcm91bmRlZC1sZyBmbGV4IGZsZXgtY29sIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtM3hsIHNtOnRleHQtNHhsIGZvbnQtZGlzcGxheSB0ZXh0LVsjMTIzMDZCXSBibG9jayB0YWJ1bGFyLW51bXNcIj5cbiAgICAgICAgICAgICAgICAgIDEwOjAwIOKAkyAyMjowMFxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHVwcGVyY2FzZSBmb250LW1lZGl1bSB0ZXh0LWJsYWNrLzYwIGJsb2NrIG10LTJcIj5cbiAgICAgICAgICAgICAgICAgINCT0YDQsNGE0LjQulxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtYmxhY2svNTAgbXQtMyBpdGFsaWNcIj5cbiAgICAgICAgICAgICAgICDQn9GCOiAxMDowMC0xMzowMCDQuCAxNTowMC0yMjowMC4g0J/QviDQtNC+0LPQvtCy0L7RgNGR0L3QvdC+0YHRgtC4LlxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L3NlY3Rpb24+XG5cbiAgICAgIHsvKiAwNC4g0JzQkNCh0KLQldCg0JAgKi99XG4gICAgICA8c2VjdGlvbiBpZD1cIm1hc3RlcnNcIiBjbGFzc05hbWU9XCJweS0xMiBzbTpweS0xNiBweC00IHNtOnB4LTggbWF4LXctN3hsIG14LWF1dG8gcmVsYXRpdmUgb3ZlcmZsb3ctaGlkZGVuXCI+XG4gICAgICAgIHsvKiBQYXJhbGxheCBvdXRsaW5lIHdhdGVybWFya3MgKi99XG4gICAgICAgIDxkaXZcbiAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSAtdG9wLTEwIGxlZnQtMTAgc2VsZWN0LW5vbmUgcG9pbnRlci1ldmVudHMtbm9uZSBmb250LWRpc3BsYXkgdGV4dC1bMTV2d10gbGVhZGluZy1ub25lIHRleHQtc3Ryb2tlLXN1YnRsZSB6LTBcIlxuICAgICAgICAgIHN0eWxlPXt7IHRyYW5zZm9ybTogYHRyYW5zbGF0ZVkoJHsoc2Nyb2xsWVBvcyAtIDE5MDApICogMC4xMn1weClgIH19XG4gICAgICAgICAgYXJpYS1oaWRkZW49XCJ0cnVlXCJcbiAgICAgICAgPlxuICAgICAgICAgIEJSQU5EXG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2XG4gICAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgYm90dG9tLTEwIHJpZ2h0LTQgc2VsZWN0LW5vbmUgcG9pbnRlci1ldmVudHMtbm9uZSBmb250LWRpc3BsYXkgdGV4dC1bMTJ2d10gbGVhZGluZy1ub25lIHRleHQtc3Ryb2tlLXN1YnRsZSB6LTBcIlxuICAgICAgICAgIHN0eWxlPXt7IHRyYW5zZm9ybTogYHRyYW5zbGF0ZVkoJHsoc2Nyb2xsWVBvcyAtIDIyMDApICogLTAuMX1weClgIH19XG4gICAgICAgICAgYXJpYS1oaWRkZW49XCJ0cnVlXCJcbiAgICAgICAgPlxuICAgICAgICAgIE5FVyBTQ0hPT0xcbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIDNEIEJhcmJlciBQb2xlIG9uIGxlZnQgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgbGVmdC0xLjUgc206bGVmdC0zIHRvcC0xMCB6LTMwIHctMTQgaC02NCBzbTpoLTgwIGhpZGRlbiBzbTpibG9ja1wiPlxuICAgICAgICAgIDxCYXJiZXJQb2xlM0Qgc2lkZT1cImxlZnRcIiBjbGFzc05hbWU9XCJ3LWZ1bGwgaC1mdWxsXCIgLz5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB6LTEwXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXhzIHNtOnRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWJsYWNrLzYwIHRyYWNraW5nLXdpZGVyIHVwcGVyY2FzZSBtYi0zXCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsjQzgxMDJFXSBmb250LWJvbGRcIj4wNDwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuPi88L3NwYW4+XG4gICAgICAgICAgICA8c3Bhbj7QnNCw0YHRgtC10YDQsDwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxSZXZlYWxPblNjcm9sbCBhcz1cImgyXCIgY2xhc3NOYW1lPVwidGV4dC0zeGwgc206dGV4dC01eGwgZm9udC1kaXNwbGF5IHRleHQtYmxhY2sgbWItOCBsZWFkaW5nLXRpZ2h0XCI+XG4gICAgICAgICAgICDQnNCQ0KHQotCV0KDQkCDQodCQ0JvQntCd0JBcbiAgICAgICAgICA8L1JldmVhbE9uU2Nyb2xsPlxuXG4gICAgICAgICAgey8qIDMgTWFzdGVyIENhcmRzICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBsZzpncmlkLWNvbHMtMyBnYXAtOFwiPlxuICAgICAgICAgICAgey8qIE1BU1RFUiAxOiDQn9Cw0YLQuNC00LjQvdC+0LIg0KHQuNGA0L7QttC40LTQuNC9ICovfVxuICAgICAgICAgICAgPFJldmVhbE9uU2Nyb2xsIGRlbGF5PXswfSBjbGFzc05hbWU9XCJoLWZ1bGxcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBiZy13aGl0ZSBib3JkZXIgYm9yZGVyLWJsYWNrLzEwIHJvdW5kZWQtbGcgb3ZlcmZsb3ctaGlkZGVuIHNoYWRvdy1zbSBob3ZlcjpzaGFkb3cteGwgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIGZsZXggZmxleC1jb2wganVzdGlmeS1iZXR3ZWVuIGdyb3VwIGgtZnVsbFwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGxlZnQtMCB0b3AtMCBib3R0b20tMCB3LTEgYmFyYmVyLXBvbGUtc3RyaXBlXCIgLz5cblxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgYXNwZWN0LVszLzRdIG92ZXJmbG93LWhpZGRlbiBiZy1ibGFjay81XCI+XG4gICAgICAgICAgICAgICAgICA8aW1nXG4gICAgICAgICAgICAgICAgICAgIHNyYz1cIi9hc3NldHMvYWlzdHVkaW8vSU1HXzc2MDVfMmRjMTU2MTUuanBlZ1wiXG4gICAgICAgICAgICAgICAgICAgIGFsdD1cItCf0LDRgtC40LTQuNC90L7QsiDQodC40YDQvtC20LjQtNC40L0sINCR0LDRgNCx0LXRgCDRgdCw0LvQvtC90LAg0JLQvdC1INCy0YDQtdC80LXQvdC4XCJcbiAgICAgICAgICAgICAgICAgICAgbG9hZGluZz1cImxhenlcIlxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC1mdWxsIG9iamVjdC1jb3ZlciBvYmplY3QtdG9wIHRyYW5zaXRpb24tdHJhbnNmb3JtIGR1cmF0aW9uLTUwMCBncm91cC1ob3ZlcjpzY2FsZS0xMDRcIlxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTMgbGVmdC00IGJnLWJsYWNrIHRleHQtd2hpdGUgcHgtMyBweS0xIHRleHQteHMgZm9udC1tb25vIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxuICAgICAgICAgICAgICAgICAgICDQkdCw0YDQsdC10YBcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtMyByaWdodC0zIGJnLXdoaXRlLzk1IHRleHQtYmxhY2sgcHgtMi41IHB5LTEgdGV4dC14cyBmb250LXNlbWlib2xkIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHNoYWRvdy1zbVwiPlxuICAgICAgICAgICAgICAgICAgICA8U3RhciBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSBmaWxsLVsjQzgxMDJFXSB0ZXh0LVsjQzgxMDJFXVwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPjUuMDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ibGFjay81MCB0ZXh0LVsxMHB4XVwiPig4INC+0YbQtdC90L7Quik8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC02XCI+XG4gICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1kaXNwbGF5IHRleHQteGwgdGV4dC1ibGFja1wiPtCf0LDRgtC40LTQuNC90L7QsiDQodC40YDQvtC20LjQtNC40L08L2gzPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LVsjQzgxMDJFXSBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIGJsb2NrIG10LTFcIj5cbiAgICAgICAgICAgICAgICAgICAg0JHQsNGA0LHQtdGAXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtYmxhY2svNzUgbXQtMyBsZWFkaW5nLXJlbGF4ZWRcIj5cbiAgICAgICAgICAgICAgICAgICAgwqvQnNC+0LvQvtC00L7QuSDQvNCw0YHRgtC10YAg0L3QvtCy0L7QuSDRiNC60L7Qu9GLLCDQutC+0YLQvtGA0YvQuSDQv9C+0YHRgtC+0Y/QvdC90L4g0YHQvtCy0LXRgNGI0LXQvdGB0YLQstGD0LXRgiDRgdCy0L7QuCDQvdCw0LLRi9C60Lgg0Lgg0YHQu9C10LTQuNGCXG4gICAgICAgICAgICAgICAgICAgINC30LAg0YHQvtCy0YDQtdC80LXQvdC90YvQvNC4INGC0LXQvdC00LXQvdGG0LjRj9C80LguINCQ0LrQutGD0YDQsNGC0L3QvtGB0YLRjCwg0LLQvdC40LzQsNC90LjQtSDQuiDQtNC10YLQsNC70Y/QvCDQuCDQuNGB0LrRgNC10L3QvdC40Lkg0L/QvtC00YXQvtC0INC6XG4gICAgICAgICAgICAgICAgICAgINC60LDQttC00L7QvNGDINCz0L7RgdGC0Y4g4oCUINGC0L4sINGH0YLQviDQvtGC0LvQuNGH0LDQtdGCINC10LPQviDRgNCw0LHQvtGC0YMuINCd0LDRh9Cw0LvQviDQsdC+0LvRjNGI0L7Qs9C+INC/0YPRgtC4INC90LDRh9C40L3QsNC10YLRgdGPINC30LTQtdGB0YwuwrtcbiAgICAgICAgICAgICAgICAgIDwvcD5cblxuICAgICAgICAgICAgICAgICAgey8qIFdvcmtzIHN0cmlwICovfVxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC01IHB0LTQgYm9yZGVyLXQgYm9yZGVyLWJsYWNrLzEwXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtbW9ubyB1cHBlcmNhc2UgdGV4dC1ibGFjay81MCBibG9jayBtYi0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAg0KDQsNCx0L7RgtGLXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0zIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAge0FMTF9XT1JLUy5maWx0ZXIoKHcpID0+IHcubWFzdGVySWQgPT09ICdzaXJvemhpZGluJykubWFwKCh3b3JrLCBpZHgpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtpZHh9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb3Blbk1hc3RlcldvcmtNb2RhbChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEFMTF9XT1JLUy5maWx0ZXIoKHcpID0+IHcubWFzdGVySWQgPT09ICdzaXJvemhpZGluJyksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZHhcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYXNwZWN0LVs0LzVdIG92ZXJmbG93LWhpZGRlbiByb3VuZGVkIGJnLWJsYWNrLzUgYm9yZGVyIGJvcmRlci1ibGFjay8xMCBob3ZlcjpvcGFjaXR5LTg1IHRyYW5zaXRpb24tb3BhY2l0eSBjdXJzb3ItcG9pbnRlciBmb2N1cy12aXNpYmxlOm91dGxpbmUtMiBmb2N1cy12aXNpYmxlOm91dGxpbmUtWyNDODEwMkVdXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD17YNCe0YLQutGA0YvRgtGMINGA0LDQsdC+0YLRgzogJHt3b3JrLnRpdGxlfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxCYXJiZXJJbWFnZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNyYz17d29yay5zcmN9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYWx0PXt3b3JrLnRpdGxlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRhaW5lckNsYXNzTmFtZT1cInctZnVsbCBoLWZ1bGxcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNob3dTcGlubmVyPXtmYWxzZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNiBwdC0wXCI+XG4gICAgICAgICAgICAgICAgPGFcbiAgICAgICAgICAgICAgICAgIGhyZWY9e0RJS0lESV9TSVJPWkhJRElOfVxuICAgICAgICAgICAgICAgICAgdGFyZ2V0PVwiX2JsYW5rXCJcbiAgICAgICAgICAgICAgICAgIHJlbD1cIm5vb3BlbmVyIG5vcmVmZXJyZXJcIlxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYnRuLWJhcmJlciB3LWZ1bGwgcHktMyBiZy1ibGFjayB0ZXh0LXdoaXRlIHRleHQteHMgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBmb2N1cy12aXNpYmxlOm91dGxpbmUtMiBmb2N1cy12aXNpYmxlOm91dGxpbmUtWyNDODEwMkVdXCJcbiAgICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCLQl9Cw0L/QuNGB0LDRgtGM0YHRjyDQuiDQodC40YDQvtC20LjQtNC40L3Rg1wiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYnRuLWZpbGxcIiAvPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicmVsYXRpdmUgei0xMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj7Ql9Cw0L/QuNGB0LDRgtGM0YHRjyDQuiDQodC40YDQvtC20LjQtNC40L3Rgzwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPEFycm93VXBSaWdodCBjbGFzc05hbWU9XCJ3LTQgaC00IGJ0bi1hcnJvd1wiIC8+XG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9hPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvUmV2ZWFsT25TY3JvbGw+XG5cbiAgICAgICAgICB7LyogTUFTVEVSIDI6INCR0LDRhdGA0LjQtNC40L3QvtCyINCW0LDQvNGI0LjQtCAqL31cbiAgICAgICAgICA8UmV2ZWFsT25TY3JvbGwgZGVsYXk9ezE1MH0gY2xhc3NOYW1lPVwiaC1mdWxsXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGJnLXdoaXRlIGJvcmRlciBib3JkZXItYmxhY2svMTAgcm91bmRlZC1sZyBvdmVyZmxvdy1oaWRkZW4gc2hhZG93LXNtIGhvdmVyOnNoYWRvdy14bCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgZmxleCBmbGV4LWNvbCBqdXN0aWZ5LWJldHdlZW4gZ3JvdXAgaC1mdWxsXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgbGVmdC0wIHRvcC0wIGJvdHRvbS0wIHctMSBiYXJiZXItcG9sZS1zdHJpcGVcIiAvPlxuXG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBhc3BlY3QtWzMvNF0gb3ZlcmZsb3ctaGlkZGVuIGJnLWJsYWNrLzVcIj5cbiAgICAgICAgICAgICAgICAgIDxpbWdcbiAgICAgICAgICAgICAgICAgICAgc3JjPVwiL2Fzc2V0cy9haXN0dWRpby9JTUdfNzYwNF82M2UyNjRjOC5qcGVnXCJcbiAgICAgICAgICAgICAgICAgICAgYWx0PVwi0JHQsNGF0YDQuNC00LjQvdC+0LIg0JbQsNC80YjQuNC0LCDQndCw0YfQuNC90LDRjtGJ0LjQuSDQsdCw0YDQsdC10YAg0YHQsNC70L7QvdCwINCS0L3QtSDQstGA0LXQvNC10L3QuFwiXG4gICAgICAgICAgICAgICAgICAgIGxvYWRpbmc9XCJsYXp5XCJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtZnVsbCBvYmplY3QtY292ZXIgb2JqZWN0LXRvcCB0cmFuc2l0aW9uLXRyYW5zZm9ybSBkdXJhdGlvbi01MDAgZ3JvdXAtaG92ZXI6c2NhbGUtMTA0XCJcbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIHRvcC0zIGxlZnQtNCBiZy1ibGFjayB0ZXh0LXdoaXRlIHB4LTMgcHktMSB0ZXh0LXhzIGZvbnQtbW9ubyB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cbiAgICAgICAgICAgICAgICAgICAg0J3QsNGH0LjQvdCw0Y7RidC40Lkg0LHQsNGA0LHQtdGAXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC02XCI+XG4gICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1kaXNwbGF5IHRleHQteGwgdGV4dC1ibGFja1wiPtCR0LDRhdGA0LjQtNC40L3QvtCyINCW0LDQvNGI0LjQtDwvaDM+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtWyMxMjMwNkJdIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgYmxvY2sgbXQtMVwiPlxuICAgICAgICAgICAgICAgICAgICDQndCw0YfQuNC90LDRjtGJ0LjQuSDQsdCw0YDQsdC10YBcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ibGFjay83NSBtdC0zIGxlYWRpbmctcmVsYXhlZFwiPlxuICAgICAgICAgICAgICAgICAgICDCq9Ch0L7Qt9C00LDRjiDRgdGC0LjQu9GMLCDQv9C+0LTRh9GR0YDQutC40LLQsNGOINC40L3QtNC40LLQuNC00YPQsNC70YzQvdC+0YHRgtGMLiDQmtCw0LbQtNGL0Lkg0LTQtdC90Ywg0YHRgtCw0L3QvtCy0LvRjtGB0Ywg0LvRg9GH0YjQtSDRgNCw0LTQuFxuICAgICAgICAgICAgICAgICAgICDQstCw0YjQtdCz0L4g0LjQtNC10LDQu9GM0L3QvtCz0L4g0L7QsdGA0LDQt9CwLiDQmtCw0YfQtdGB0YLQstC+LCDQsNC60LrRg9GA0LDRgtC90L7RgdGC0Ywg0Lgg0LvRjtCx0L7QstGMINC6INGB0LLQvtC10LzRgyDQtNC10LvRgy7Cu1xuICAgICAgICAgICAgICAgICAgPC9wPlxuXG4gICAgICAgICAgICAgICAgICB7LyogV29ya3Mgc3RyaXAgZm9yIEphbXNoaWQgKi99XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTUgcHQtNCBib3JkZXItdCBib3JkZXItYmxhY2svMTBcIj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1tb25vIHVwcGVyY2FzZSB0ZXh0LWJsYWNrLzUwIGJsb2NrIG1iLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICDQoNCw0LHQvtGC0YtcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7QUxMX1dPUktTLmZpbHRlcigodykgPT4gdy5tYXN0ZXJJZCA9PT0gJ2phbXNoaWQnKS5tYXAoKHdvcmssIGlkeCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2lkeH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcGVuTWFzdGVyV29ya01vZGFsKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQUxMX1dPUktTLmZpbHRlcigodykgPT4gdy5tYXN0ZXJJZCA9PT0gJ2phbXNoaWQnKSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkeFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhc3BlY3QtWzQvNV0gb3ZlcmZsb3ctaGlkZGVuIHJvdW5kZWQgYmctYmxhY2svNSBib3JkZXIgYm9yZGVyLWJsYWNrLzEwIGhvdmVyOm9wYWNpdHktODUgdHJhbnNpdGlvbi1vcGFjaXR5IGN1cnNvci1wb2ludGVyIGZvY3VzLXZpc2libGU6b3V0bGluZS0yIGZvY3VzLXZpc2libGU6b3V0bGluZS1bI0M4MTAyRV1cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPXtg0J7RgtC60YDRi9GC0Ywg0YDQsNCx0L7RgtGDOiAke3dvcmsudGl0bGV9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPEJhcmJlckltYWdlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc3JjPXt3b3JrLnNyY31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbHQ9e3dvcmsudGl0bGV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udGFpbmVyQ2xhc3NOYW1lPVwidy1mdWxsIGgtZnVsbFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2hvd1NwaW5uZXI9e2ZhbHNlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IG9iamVjdFBvc2l0aW9uOiB3b3JrLmNyb3BQb3NpdGlvbiB8fCAnY2VudGVyJyB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC02IHB0LTBcIj5cbiAgICAgICAgICAgICAgICA8YVxuICAgICAgICAgICAgICAgICAgaHJlZj17RElLSURJX1pIQU1TSElEfVxuICAgICAgICAgICAgICAgICAgdGFyZ2V0PVwiX2JsYW5rXCJcbiAgICAgICAgICAgICAgICAgIHJlbD1cIm5vb3BlbmVyIG5vcmVmZXJyZXJcIlxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYnRuLWJhcmJlciB3LWZ1bGwgcHktMyBiZy1ibGFjayB0ZXh0LXdoaXRlIHRleHQteHMgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBmb2N1cy12aXNpYmxlOm91dGxpbmUtMiBmb2N1cy12aXNpYmxlOm91dGxpbmUtWyNDODEwMkVdXCJcbiAgICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCLQl9Cw0L/QuNGB0LDRgtGM0YHRjyDQuiDQltCw0LzRiNC40LTRg1wiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYnRuLWZpbGxcIiAvPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicmVsYXRpdmUgei0xMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj7Ql9Cw0L/QuNGB0LDRgtGM0YHRjyDQuiDQltCw0LzRiNC40LTRgzwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPEFycm93VXBSaWdodCBjbGFzc05hbWU9XCJ3LTQgaC00IGJ0bi1hcnJvd1wiIC8+XG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9hPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvUmV2ZWFsT25TY3JvbGw+XG5cbiAgICAgICAgICB7LyogTUFTVEVSIDM6INCR0LDRhdGA0LjQtNC40L3QvtCyINCc0LDQutGB0YPQtCAqL31cbiAgICAgICAgICA8UmV2ZWFsT25TY3JvbGwgZGVsYXk9ezMwMH0gY2xhc3NOYW1lPVwiaC1mdWxsXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGJnLXdoaXRlIGJvcmRlciBib3JkZXItYmxhY2svMTAgcm91bmRlZC1sZyBvdmVyZmxvdy1oaWRkZW4gc2hhZG93LXNtIGhvdmVyOnNoYWRvdy14bCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgZmxleCBmbGV4LWNvbCBqdXN0aWZ5LWJldHdlZW4gZ3JvdXAgaC1mdWxsXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgbGVmdC0wIHRvcC0wIGJvdHRvbS0wIHctMSBiYXJiZXItcG9sZS1zdHJpcGVcIiAvPlxuXG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBhc3BlY3QtWzMvNF0gb3ZlcmZsb3ctaGlkZGVuIGJnLWJsYWNrLzVcIj5cbiAgICAgICAgICAgICAgICAgIDxpbWdcbiAgICAgICAgICAgICAgICAgICAgc3JjPVwiL2Fzc2V0cy9haXN0dWRpby9JTUdfMTk3N19jZTZiMDQ4NC5qcGVnXCJcbiAgICAgICAgICAgICAgICAgICAgYWx0PVwi0JHQsNGF0YDQuNC00LjQvdC+0LIg0JzQsNC60YHRg9C0LCBCUkFORC3QsdCw0YDQsdC10YAg0YHQsNC70L7QvdCwINCS0L3QtSDQstGA0LXQvNC10L3QuFwiXG4gICAgICAgICAgICAgICAgICAgIGxvYWRpbmc9XCJsYXp5XCJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtZnVsbCBvYmplY3QtY292ZXIgb2JqZWN0LXRvcCB0cmFuc2l0aW9uLXRyYW5zZm9ybSBkdXJhdGlvbi01MDAgZ3JvdXAtaG92ZXI6c2NhbGUtMTA0XCJcbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIHRvcC0zIGxlZnQtNCBiZy1bIzEyMzA2Ql0gdGV4dC13aGl0ZSBweC0zIHB5LTEgdGV4dC14cyBmb250LW1vbm8gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XG4gICAgICAgICAgICAgICAgICAgIEJSQU5ELdCx0LDRgNCx0LXRgFxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIHRvcC0zIHJpZ2h0LTMgYmctd2hpdGUvOTUgdGV4dC1ibGFjayBweC0yLjUgcHktMSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgc2hhZG93LXNtXCI+XG4gICAgICAgICAgICAgICAgICAgIDEwINC70LXRgiDQvtC/0YvRgtCwXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC02XCI+XG4gICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1kaXNwbGF5IHRleHQteGwgdGV4dC1ibGFja1wiPtCR0LDRhdGA0LjQtNC40L3QvtCyINCc0LDQutGB0YPQtDwvaDM+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtWyNDODEwMkVdIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgYmxvY2sgbXQtMVwiPlxuICAgICAgICAgICAgICAgICAgICBCUkFORC3QsdCw0YDQsdC10YBcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ibGFjay83NSBtdC0zIGxlYWRpbmctcmVsYXhlZFwiPlxuICAgICAgICAgICAgICAgICAgICDCqzEwINC70LXRgiDQvtC/0YvRgtCwLCDRgdC+0YLQvdC4INC00L7QstC+0LvRjNC90YvRhSDQutC70LjQtdC90YLQvtCyINC4INC70Y7QsdC+0LLRjCDQuiDRgdCy0L7QtdC80YMg0LTQtdC70YMuINCc0LDRgdGC0LXRgCwg0LrQvtGC0L7RgNGL0LlcbiAgICAgICAgICAgICAgICAgICAg0LfQvdCw0LXRgiDQstGB0ZEg0L4g0YfQuNGB0YLRi9GFINGE0LXQudC00LDRhSwg0LDQutC60YPRgNCw0YLQvdGL0YUg0LHQvtGA0L7QtNCw0YUg0Lgg0YHRgtC40LvRjNC90YvRhSDRg9C00LvQuNC90ZHQvdC90YvRhSDRgdGC0YDQuNC20LrQsNGFLlxuICAgICAgICAgICAgICAgICAgICDQodC/0L7QutC+0LnQvdGL0Lkg0LIg0YDQsNCx0L7RgtC1LCDRg9Cy0LXRgNC10L3QvdGL0Lkg0LIg0YDQtdC30YPQu9GM0YLQsNGC0LUg0Lgg0LLRgdC10LPQtNCwINCy0L3QuNC80LDRgtC10LvRjNC90YvQuSDQuiDQv9C+0LbQtdC70LDQvdC40Y/QvCDQs9C+0YHRgtGPLlxuICAgICAgICAgICAgICAgICAgICDQldGB0LvQuCDQvdGD0LbQtdC9INC+0LHRgNCw0LcsINC60L7RgtC+0YDRi9C5INCx0YPQtNC10YIg0LLRi9Cz0LvRj9C00LXRgtGMINC00L7RgdGC0L7QudC90L4g0LrQsNC20LTRi9C5INC00LXQvdGMLCDQstGLINC/0L4g0LDQtNGA0LXRgdGDLsK7XG4gICAgICAgICAgICAgICAgICA8L3A+XG5cbiAgICAgICAgICAgICAgICAgIHsvKiBXb3JrcyBzdHJpcCBmb3IgTWFrc3VkICovfVxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC01IHB0LTQgYm9yZGVyLXQgYm9yZGVyLWJsYWNrLzEwXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtbW9ubyB1cHBlcmNhc2UgdGV4dC1ibGFjay81MCBibG9jayBtYi0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAg0KDQsNCx0L7RgtGLXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0zIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAge0FMTF9XT1JLUy5maWx0ZXIoKHcpID0+IHcubWFzdGVySWQgPT09ICdtYWtzdWQnKS5tYXAoKHdvcmssIGlkeCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2lkeH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcGVuTWFzdGVyV29ya01vZGFsKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQUxMX1dPUktTLmZpbHRlcigodykgPT4gdy5tYXN0ZXJJZCA9PT0gJ21ha3N1ZCcpLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWR4XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImFzcGVjdC1bNC81XSBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZCBiZy1ibGFjay81IGJvcmRlciBib3JkZXItYmxhY2svMTAgaG92ZXI6b3BhY2l0eS04NSB0cmFuc2l0aW9uLW9wYWNpdHkgY3Vyc29yLXBvaW50ZXIgZm9jdXMtdmlzaWJsZTpvdXRsaW5lLTIgZm9jdXMtdmlzaWJsZTpvdXRsaW5lLVsjQzgxMDJFXVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9e2DQntGC0LrRgNGL0YLRjCDRgNCw0LHQvtGC0YM6ICR7d29yay50aXRsZX1gfVxuICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8QmFyYmVySW1hZ2VcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzcmM9e3dvcmsuc3JjfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFsdD17d29yay50aXRsZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250YWluZXJDbGFzc05hbWU9XCJ3LWZ1bGwgaC1mdWxsXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaG93U3Bpbm5lcj17ZmFsc2V9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTYgcHQtMFwiPlxuICAgICAgICAgICAgICAgIDxhXG4gICAgICAgICAgICAgICAgICBocmVmPXtESUtJRElfTUFLU1VEfVxuICAgICAgICAgICAgICAgICAgdGFyZ2V0PVwiX2JsYW5rXCJcbiAgICAgICAgICAgICAgICAgIHJlbD1cIm5vb3BlbmVyIG5vcmVmZXJyZXJcIlxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYnRuLWJhcmJlciB3LWZ1bGwgcHktMyBiZy1ibGFjayB0ZXh0LXdoaXRlIHRleHQteHMgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBmb2N1cy12aXNpYmxlOm91dGxpbmUtMiBmb2N1cy12aXNpYmxlOm91dGxpbmUtWyNDODEwMkVdXCJcbiAgICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCLQl9Cw0L/QuNGB0LDRgtGM0YHRjyDQuiDQnNCw0LrRgdGD0LTRg1wiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYnRuLWZpbGxcIiAvPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicmVsYXRpdmUgei0xMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj7Ql9Cw0L/QuNGB0LDRgtGM0YHRjyDQuiDQnNCw0LrRgdGD0LTRgzwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPEFycm93VXBSaWdodCBjbGFzc05hbWU9XCJ3LTQgaC00IGJ0bi1hcnJvd1wiIC8+XG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9hPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvUmV2ZWFsT25TY3JvbGw+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9zZWN0aW9uPlxuXG4gICAgICB7LyogMDUuINCg0JDQkdCe0KLQqyAo0J/QntCg0KLQpNCe0JvQmNCeKSAqL31cbiAgICAgIDxzZWN0aW9uIGlkPVwid29ya3NcIiBjbGFzc05hbWU9XCJweS0xMiBzbTpweS0xNiBweC00IHNtOnB4LTggbWF4LXctN3hsIG14LWF1dG8gcmVsYXRpdmUgb3ZlcmZsb3ctaGlkZGVuXCI+XG4gICAgICAgIHsvKiBQYXJhbGxheCBvdXRsaW5lIHdhdGVybWFya3MgKi99XG4gICAgICAgIDxkaXZcbiAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSAtdG9wLTEwIHJpZ2h0LTQgc2VsZWN0LW5vbmUgcG9pbnRlci1ldmVudHMtbm9uZSBmb250LWRpc3BsYXkgdGV4dC1bMTZ2d10gbGVhZGluZy1ub25lIHRleHQtc3Ryb2tlLXN1YnRsZSB6LTBcIlxuICAgICAgICAgIHN0eWxlPXt7IHRyYW5zZm9ybTogYHRyYW5zbGF0ZVkoJHsoc2Nyb2xsWVBvcyAtIDI3MDApICogMC4xNH1weClgIH19XG4gICAgICAgICAgYXJpYS1oaWRkZW49XCJ0cnVlXCJcbiAgICAgICAgPlxuICAgICAgICAgIFdPUktTXG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2XG4gICAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgYm90dG9tLTYgbGVmdC0xMCBzZWxlY3Qtbm9uZSBwb2ludGVyLWV2ZW50cy1ub25lIGZvbnQtZGlzcGxheSB0ZXh0LVsxMnZ3XSBsZWFkaW5nLW5vbmUgdGV4dC1zdHJva2Utc3VidGxlIHotMFwiXG4gICAgICAgICAgc3R5bGU9e3sgdHJhbnNmb3JtOiBgdHJhbnNsYXRlWSgkeyhzY3JvbGxZUG9zIC0gMzAwMCkgKiAtMC4xfXB4KWAgfX1cbiAgICAgICAgICBhcmlhLWhpZGRlbj1cInRydWVcIlxuICAgICAgICA+XG4gICAgICAgICAgU1RZTEVcbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIEZsb2F0aW5nIENsaXBwZXIgSWxsdXN0cmF0aW9uICovfVxuICAgICAgICA8ZGl2XG4gICAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgcmlnaHQtMTIgdG9wLTI0IHNlbGVjdC1ub25lIHBvaW50ZXItZXZlbnRzLW5vbmUgb3BhY2l0eS0yMCBoaWRkZW4gbWQ6YmxvY2sgdGV4dC1ibGFja1wiXG4gICAgICAgICAgc3R5bGU9e3sgdHJhbnNmb3JtOiBgdHJhbnNsYXRlWSgkeyhzY3JvbGxZUG9zIC0gMjcwMCkgKiAtMC4xfXB4KWAgfX1cbiAgICAgICAgICBhcmlhLWhpZGRlbj1cInRydWVcIlxuICAgICAgICA+XG4gICAgICAgICAgPENsaXBwZXJJY29uIHNpemU9ezY0fSAvPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHotMTBcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQteHMgc206dGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtYmxhY2svNjAgdHJhY2tpbmctd2lkZXIgdXBwZXJjYXNlIG1iLTNcIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWyNDODEwMkVdIGZvbnQtYm9sZFwiPjA1PC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4+Lzwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuPtCf0L7RgNGC0YTQvtC70LjQvjwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxSZXZlYWxPblNjcm9sbCBhcz1cImgyXCIgY2xhc3NOYW1lPVwidGV4dC0zeGwgc206dGV4dC01eGwgZm9udC1kaXNwbGF5IHRleHQtYmxhY2sgbWItNiBsZWFkaW5nLXRpZ2h0XCI+XG4gICAgICAgICAgICDQoNCQ0JHQntCi0KtcbiAgICAgICAgICA8L1JldmVhbE9uU2Nyb2xsPlxuXG4gICAgICAgICAgey8qIEZpbHRlciBDaGlwcyAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIG92ZXJmbG93LXgtYXV0byBwYi0zIG1iLTggbm8tc2Nyb2xsYmFyXCI+XG4gICAgICAgICAgICB7W1xuICAgICAgICAgICAgICB7IGlkOiAnYWxsJywgbGFiZWw6ICfQktGB0LUg0YDQsNCx0L7RgtGLJyB9LFxuICAgICAgICAgICAgICB7IGlkOiAnc2lyb3poaWRpbicsIGxhYmVsOiAn0KHQuNGA0L7QttC40LTQuNC9JyB9LFxuICAgICAgICAgICAgICB7IGlkOiAnamFtc2hpZCcsIGxhYmVsOiAn0JbQsNC80YjQuNC0JyB9LFxuICAgICAgICAgICAgICB7IGlkOiAnbWFrc3VkJywgbGFiZWw6ICfQnNCw0LrRgdGD0LQnIH0sXG4gICAgICAgICAgICBdLm1hcCgoY2hpcCkgPT4gKFxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAga2V5PXtjaGlwLmlkfVxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFdvcmtzRmlsdGVyKGNoaXAuaWQgYXMgYW55KX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweC01IHB5LTIuNSB0ZXh0LXhzIHNtOnRleHQtc20gZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdHJhbnNpdGlvbi1jb2xvcnMgcm91bmRlZC1mdWxsIHNocmluay0wIG1pbi1oLVs0MnB4XSBjdXJzb3ItcG9pbnRlciBmb2N1cy12aXNpYmxlOm91dGxpbmUtMiBmb2N1cy12aXNpYmxlOm91dGxpbmUtWyNDODEwMkVdICR7XG4gICAgICAgICAgICAgICAgICB3b3Jrc0ZpbHRlciA9PT0gY2hpcC5pZFxuICAgICAgICAgICAgICAgICAgICA/ICdiZy1ibGFjayB0ZXh0LXdoaXRlIHNoYWRvdy1zbSdcbiAgICAgICAgICAgICAgICAgICAgOiAnYmctYmxhY2svNSBob3ZlcjpiZy1ibGFjay8xMCB0ZXh0LWJsYWNrLzc1J1xuICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAge2NoaXAubGFiZWx9XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogV29ya3MgR3JpZCAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgbWQ6Z3JpZC1jb2xzLTMgbGc6Z3JpZC1jb2xzLTQgZ2FwLTMgc206Z2FwLTVcIj5cbiAgICAgICAgICAgIHtmaWx0ZXJlZFdvcmtzLm1hcCgod29yaywgaWR4KSA9PiB7XG4gICAgICAgICAgICAgIGNvbnN0IGlzTGFzdE9kZCA9IGZpbHRlcmVkV29ya3MubGVuZ3RoICUgMiAhPT0gMCAmJiBpZHggPT09IGZpbHRlcmVkV29ya3MubGVuZ3RoIC0gMTtcbiAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICBrZXk9e3dvcmsuaWR9XG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvcGVuV29ya01vZGFsKHdvcmspfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZ3JvdXAgcmVsYXRpdmUgYXNwZWN0LVszLzRdIG92ZXJmbG93LWhpZGRlbiByb3VuZGVkLWxnIGJnLWJsYWNrLzUgYm9yZGVyIGJvcmRlci1ibGFjay8xMCBjdXJzb3ItcG9pbnRlciBzaGFkb3ctc20gaG92ZXI6c2hhZG93LWxnIHRyYW5zaXRpb24tYWxsIGZvY3VzLXZpc2libGU6b3V0bGluZS0yIGZvY3VzLXZpc2libGU6b3V0bGluZS1bI0M4MTAyRV0gJHtcbiAgICAgICAgICAgICAgICAgICAgaXNMYXN0T2RkID8gJ2NvbC1zcGFuLTIgbWQ6Y29sLXNwYW4tMScgOiAnJ1xuICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICByb2xlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgIHRhYkluZGV4PXswfVxuICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD17YNCe0YLQutGA0YvRgtGMINGA0LDQsdC+0YLRgzogJHt3b3JrLnRpdGxlfWB9XG4gICAgICAgICAgICAgICAgICBvbktleURvd249eyhlKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChlLmtleSA9PT0gJ0VudGVyJyB8fCBlLmtleSA9PT0gJyAnKSBvcGVuV29ya01vZGFsKHdvcmspO1xuICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8QmFyYmVySW1hZ2VcbiAgICAgICAgICAgICAgICAgICAgc3JjPXt3b3JrLnNyY31cbiAgICAgICAgICAgICAgICAgICAgYWx0PXt3b3JrLnRpdGxlfVxuICAgICAgICAgICAgICAgICAgICBjb250YWluZXJDbGFzc05hbWU9XCJ3LWZ1bGwgaC1mdWxsXCJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidHJhbnNpdGlvbi10cmFuc2Zvcm0gZHVyYXRpb24tNTAwIGdyb3VwLWhvdmVyOnNjYWxlLTEwNFwiXG4gICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IG9iamVjdFBvc2l0aW9uOiB3b3JrLmNyb3BQb3NpdGlvbiB8fCAnY2VudGVyJyB9fVxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQtMCBiZy1ncmFkaWVudC10by10IGZyb20tYmxhY2svODUgdmlhLWJsYWNrLzIwIHRvLXRyYW5zcGFyZW50IG9wYWNpdHktMCBncm91cC1ob3ZlcjpvcGFjaXR5LTEwMCB0cmFuc2l0aW9uLW9wYWNpdHkgcC0zIHNtOnAtNCBmbGV4IGZsZXgtY29sIGp1c3RpZnktZW5kIHRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgbGVhZGluZy10aWdodFwiPnt3b3JrLnRpdGxlfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gc206dGV4dC1bMTFweF0gdGV4dC1bI0M4MTAyRV0gZm9udC1tZWRpdW0gbXQtMSB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7d29yay5tYXN0ZXJOYW1lfVxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIH0pfVxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIEZ1bGwtd2lkdGggQm9va2luZyBDVEEgdW5kZXIgZ2FsbGVyeSAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTEwXCI+XG4gICAgICAgICAgICA8YVxuICAgICAgICAgICAgICBocmVmPXtESUtJRElfR0VORVJBTH1cbiAgICAgICAgICAgICAgdGFyZ2V0PVwiX2JsYW5rXCJcbiAgICAgICAgICAgICAgcmVsPVwibm9vcGVuZXIgbm9yZWZlcnJlclwiXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJ0bi1iYXJiZXIgdy1mdWxsIHB5LTQgYmctYmxhY2sgdGV4dC13aGl0ZSBmb250LWRpc3BsYXkgdGV4dC1zbSB0cmFja2luZy13aWRlc3QgdXBwZXJjYXNlIHNoYWRvdy1tZCBmb2N1cy12aXNpYmxlOm91dGxpbmUtMiBmb2N1cy12aXNpYmxlOm91dGxpbmUtWyNDODEwMkVdXCJcbiAgICAgICAgICAgICAgYXJpYS1sYWJlbD1cItCX0LDQv9C40YHQsNGC0YzRgdGPINC+0L3Qu9Cw0LnQvSDQvdCwINGB0YLRgNC40LbQutGDXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYnRuLWZpbGxcIiAvPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB6LTEwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4+0JfQsNC/0LjRgdCw0YLRjNGB0Y8g0L7QvdC70LDQudC9PC9zcGFuPlxuICAgICAgICAgICAgICAgIDxBcnJvd1VwUmlnaHQgY2xhc3NOYW1lPVwidy00IGgtNCBidG4tYXJyb3dcIiAvPlxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8L2E+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9zZWN0aW9uPlxuXG4gICAgICB7LyogMDYuINCf0KDQkNCZ0KEgKNCd0JAg0KHQmNCd0JXQnCDQpNCe0J3QlSAjMTIzMDZCLCDQotCV0JrQodCiINCR0JXQm9Cr0JksINCQ0JrQptCV0J3QoiAjRkY1QzZDKSAqL31cbiAgICAgIDxzZWN0aW9uXG4gICAgICAgIGlkPVwicHJpY2luZ1wiXG4gICAgICAgIGNsYXNzTmFtZT1cInB5LTEyIHNtOnB5LTE2IHB4LTQgc206cHgtOCBiZy1bIzEyMzA2Ql0gdGV4dC13aGl0ZSByZWxhdGl2ZSBvdmVyZmxvdy1oaWRkZW5cIlxuICAgICAgPlxuICAgICAgICB7LyogUGFyYWxsYXggb3V0bGluZSB3YXRlcm1hcmsgJ1BSSUNFJyAqL31cbiAgICAgICAgPGRpdlxuICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIC10b3AtMTAgbGVmdC0xLzIgLXRyYW5zbGF0ZS14LTEvMiBzZWxlY3Qtbm9uZSBwb2ludGVyLWV2ZW50cy1ub25lIGZvbnQtZGlzcGxheSB0ZXh0LVsxOHZ3XSBsZWFkaW5nLW5vbmUgdGV4dC1zdHJva2UtYmx1ZSB6LTBcIlxuICAgICAgICAgIHN0eWxlPXt7IHRyYW5zZm9ybTogYHRyYW5zbGF0ZSgtNTAlLCAkeyhzY3JvbGxZUG9zIC0gMzUwMCkgKiAwLjE1fXB4KWAgfX1cbiAgICAgICAgICBhcmlhLWhpZGRlbj1cInRydWVcIlxuICAgICAgICA+XG4gICAgICAgICAgUFJJQ0VcbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXgtdy00eGwgbXgtYXV0byByZWxhdGl2ZSB6LTEwXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXhzIHNtOnRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LXdoaXRlLzYwIHRyYWNraW5nLXdpZGVyIHVwcGVyY2FzZSBtYi0zXCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsjRkY1QzZDXSBmb250LWJvbGRcIj4wNjwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuPi88L3NwYW4+XG4gICAgICAgICAgICA8c3Bhbj7Qn9GA0LDQudGBPC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPFJldmVhbE9uU2Nyb2xsIGFzPVwiaDJcIiBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBzbTp0ZXh0LTV4bCBmb250LWRpc3BsYXkgdGV4dC13aGl0ZSBtYi0yIGxlYWRpbmctdGlnaHRcIj5cbiAgICAgICAgICAgINCj0KHQm9Cj0JPQmCDQmCDQptCV0J3Qq1xuICAgICAgICAgIDwvUmV2ZWFsT25TY3JvbGw+XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLThcIj5cbiAgICAgICAgICAgIDxhXG4gICAgICAgICAgICAgIGhyZWY9XCIjZnJlZVwiXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXNtIHNtOnRleHQtYmFzZSB0ZXh0LXdoaXRlLzkwIGhvdmVyOnRleHQtd2hpdGUgdW5kZXJsaW5lIGRlY29yYXRpb24tWyNGRjVDNkNdIGRlY29yYXRpb24tMiB1bmRlcmxpbmUtb2Zmc2V0LTQgZm9udC1tZWRpdW0gdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8c3Bhbj7QnNGL0YLRjNGRINCz0L7Qu9C+0LLRiywg0LrQvtGE0LUsINGB0L3QtdC60LgsINC/0LDRgNC60L7QstC60LAsIFdpLUZpINC4IFBTNSDQsdC10YHQv9C70LDRgtC90L4g4oaSPC9zcGFuPlxuICAgICAgICAgICAgPC9hPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIE1hc3RlciBDYXRlZ29yeSBUYWJzICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctYmxhY2svMjUgcC0xLjUgcm91bmRlZC1sZyBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTEgbWItOCBtYXgtdy1sZ1wiPlxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTZWxlY3RlZENhdGVnb3J5KCdicmFuZCcpfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2BmbGV4LTEgcHktMyB0ZXh0LXhzIHNtOnRleHQtc20gZm9udC1zZW1pYm9sZCByb3VuZGVkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0cmFuc2l0aW9uLWNvbG9ycyBtaW4taC1bNDhweF0gY3Vyc29yLXBvaW50ZXIgJHtcbiAgICAgICAgICAgICAgICBzZWxlY3RlZENhdGVnb3J5ID09PSAnYnJhbmQnXG4gICAgICAgICAgICAgICAgICA/ICdiZy13aGl0ZSB0ZXh0LVsjMTIzMDZCXSBzaGFkb3ctbWQnXG4gICAgICAgICAgICAgICAgICA6ICd0ZXh0LXdoaXRlLzgwIGhvdmVyOnRleHQtd2hpdGUnXG4gICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICBCUkFORC3QkdCw0YDQsdC10YBcbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTZWxlY3RlZENhdGVnb3J5KCdiYXJiZXInKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmxleC0xIHB5LTMgdGV4dC14cyBzbTp0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgcm91bmRlZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdHJhbnNpdGlvbi1jb2xvcnMgbWluLWgtWzQ4cHhdIGN1cnNvci1wb2ludGVyICR7XG4gICAgICAgICAgICAgICAgc2VsZWN0ZWRDYXRlZ29yeSA9PT0gJ2JhcmJlcidcbiAgICAgICAgICAgICAgICAgID8gJ2JnLXdoaXRlIHRleHQtWyMxMjMwNkJdIHNoYWRvdy1tZCdcbiAgICAgICAgICAgICAgICAgIDogJ3RleHQtd2hpdGUvODAgaG92ZXI6dGV4dC13aGl0ZSdcbiAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgINCR0LDRgNCx0LXRgFxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNlbGVjdGVkQ2F0ZWdvcnkoJ2p1bmlvcicpfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2BmbGV4LTEgcHktMyB0ZXh0LXhzIHNtOnRleHQtc20gZm9udC1zZW1pYm9sZCByb3VuZGVkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0cmFuc2l0aW9uLWNvbG9ycyBtaW4taC1bNDhweF0gY3Vyc29yLXBvaW50ZXIgJHtcbiAgICAgICAgICAgICAgICBzZWxlY3RlZENhdGVnb3J5ID09PSAnanVuaW9yJ1xuICAgICAgICAgICAgICAgICAgPyAnYmctd2hpdGUgdGV4dC1bIzEyMzA2Ql0gc2hhZG93LW1kJ1xuICAgICAgICAgICAgICAgICAgOiAndGV4dC13aGl0ZS84MCBob3Zlcjp0ZXh0LXdoaXRlJ1xuICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAg0J3QsNGH0LjQvdCw0Y7RidC40LlcbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIENhdGVnb3J5IHN1YnRpdGxlICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNiBwYi0zIGJvcmRlci1iIGJvcmRlci13aGl0ZS8xNSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gdGV4dC14cyBzbTp0ZXh0LXNtIHRleHQtd2hpdGUvODBcIj5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgICAgIHtzZWxlY3RlZENhdGVnb3J5ID09PSAnYnJhbmQnXG4gICAgICAgICAgICAgICAgICA/ICdCUkFORC3QkdCw0YDQsdC10YAg4oCUINCR0LDRhdGA0LjQtNC40L3QvtCyINCc0LDQutGB0YPQtCAoMTAg0LvQtdGCINC+0L/Ri9GC0LApJ1xuICAgICAgICAgICAgICAgICAgOiBzZWxlY3RlZENhdGVnb3J5ID09PSAnYmFyYmVyJ1xuICAgICAgICAgICAgICAgICAgPyAn0JHQsNGA0LHQtdGAIOKAlCDQn9Cw0YLQuNC00LjQvdC+0LIg0KHQuNGA0L7QttC40LTQuNC9ICjQoNC10LnRgtC40L3QsyA1LjApJ1xuICAgICAgICAgICAgICAgICAgOiAn0J3QsNGH0LjQvdCw0Y7RidC40Lkg0LHQsNGA0LHQtdGAIOKAlCDQkdCw0YXRgNC40LTQuNC90L7QsiDQltCw0LzRiNC40LQgKNCU0L7RgdGC0YPQv9C90LDRjyDRgdGC0L7QuNC80L7RgdGC0YwpJ31cbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsjRkY1QzZDXSBmb250LWJvbGQgdXBwZXJjYXNlIHRleHQteHNcIj7Qn9GA0LDQudGBIDLQk9CY0KE8L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogU2VydmljZSByb3dzICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zIHNtOnNwYWNlLXktNFwiPlxuICAgICAgICAgICAge1NFUlZJQ0VTX0RBVEEubWFwKChzcnYsIGlkeCkgPT4ge1xuICAgICAgICAgICAgICBjb25zdCBjdXJyZW50UHJpY2UgPVxuICAgICAgICAgICAgICAgIHNlbGVjdGVkQ2F0ZWdvcnkgPT09ICdicmFuZCdcbiAgICAgICAgICAgICAgICAgID8gc3J2LnByaWNlQnJhbmRcbiAgICAgICAgICAgICAgICAgIDogc2VsZWN0ZWRDYXRlZ29yeSA9PT0gJ2JhcmJlcidcbiAgICAgICAgICAgICAgICAgID8gc3J2LnByaWNlQmFyYmVyXG4gICAgICAgICAgICAgICAgICA6IHNydi5wcmljZUp1bmlvcjtcblxuICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICAgIGtleT17aWR4fVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZ3JvdXAgcmVsYXRpdmUgcC00IHNtOnAtNSBiZy13aGl0ZS81IGhvdmVyOmJnLXdoaXRlLzEwIGJvcmRlci1sLTIgYm9yZGVyLXRyYW5zcGFyZW50IGhvdmVyOmJvcmRlci1bI0ZGNUM2Q10gdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMjAwIHJvdW5kZWQtci1sZyBmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IHNtOml0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTJcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIHByLTRcIj5cbiAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1iYXNlIHNtOnRleHQtbGcgdGV4dC13aGl0ZSBncm91cC1ob3Zlcjp0ZXh0LXdoaXRlIHRyYW5zaXRpb24tY29sb3JzXCI+XG4gICAgICAgICAgICAgICAgICAgICAge3Nydi5uYW1lfVxuICAgICAgICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQteHMgdGV4dC13aGl0ZS82MCBmb250LW1vbm8gbXQtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxDbG9jayBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LVsjRkY1QzZDXVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3Nydi5kdXJhdGlvbn08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1yaWdodCBzbTpwbC00IGJvcmRlci10IHNtOmJvcmRlci10LTAgYm9yZGVyLXdoaXRlLzEwIHB0LTIgc206cHQtMFwiPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWRpc3BsYXkgdGV4dC14bCBzbTp0ZXh0LTJ4bCB0ZXh0LXdoaXRlIGJsb2NrIHRhYnVsYXItbnVtcyBncm91cC1ob3ZlcjotdHJhbnNsYXRlLXgtMS41IHRyYW5zaXRpb24tdHJhbnNmb3JtIGR1cmF0aW9uLTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgIHtjdXJyZW50UHJpY2V9XG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgfSl9XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogUmVkIGJ1dHRvbjogZHluYW1pYyBsaW5rICYgdGV4dCBtYXRjaGluZyBhY3RpdmUgdGFiICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtOCB0ZXh0LWNlbnRlciBzbTp0ZXh0LWxlZnRcIj5cbiAgICAgICAgICAgIDxhXG4gICAgICAgICAgICAgIGhyZWY9e3ByaWNlQnV0dG9uQ29uZmlnLnVybH1cbiAgICAgICAgICAgICAgdGFyZ2V0PVwiX2JsYW5rXCJcbiAgICAgICAgICAgICAgcmVsPVwibm9vcGVuZXIgbm9yZWZlcnJlclwiXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImdyb3VwIHB4LTggcHktNCBiZy1bI0M4MTAyRV0gaG92ZXI6YmctWyNhNjBiMjRdIGFjdGl2ZTpiZy1bIzBhMWU0YV0gdGV4dC13aGl0ZSBmb250LWRpc3BsYXkgdGV4dC1zbSB0cmFja2luZy13aWRlc3QgdXBwZXJjYXNlIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMCBpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgbWluLWgtWzQ4cHhdIHNoYWRvdy1sZyBmb2N1cy12aXNpYmxlOm91dGxpbmUtMiBmb2N1cy12aXNpYmxlOm91dGxpbmUtd2hpdGVcIlxuICAgICAgICAgICAgICBhcmlhLWxhYmVsPXtwcmljZUJ1dHRvbkNvbmZpZy50ZXh0fVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8c3Bhbj57cHJpY2VCdXR0b25Db25maWcudGV4dH08L3NwYW4+XG4gICAgICAgICAgICAgIDxBcnJvd1VwUmlnaHQgY2xhc3NOYW1lPVwidy00IGgtNCBncm91cC1ob3Zlcjpyb3RhdGUtNDUgdHJhbnNpdGlvbi10cmFuc2Zvcm0gZHVyYXRpb24tMjAwIHRleHQtWyNGRjVDNkNdIGdyb3VwLWhvdmVyOnRleHQtd2hpdGVcIiAvPlxuICAgICAgICAgICAgPC9hPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvc2VjdGlvbj5cblxuICAgICAgey8qIDA3LiDQntCi0JfQq9CS0KsgKi99XG4gICAgICA8c2VjdGlvbiBpZD1cInJldmlld3NcIiBjbGFzc05hbWU9XCJweS0xMiBzbTpweS0xNiBweC00IHNtOnB4LTggbWF4LXctN3hsIG14LWF1dG8gcmVsYXRpdmUgb3ZlcmZsb3ctaGlkZGVuXCI+XG4gICAgICAgIHsvKiBQYXJhbGxheCBvdXRsaW5lIHdhdGVybWFyayAnUkVWSUVXUycgKi99XG4gICAgICAgIDxkaXZcbiAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSAtdG9wLTEwIGxlZnQtMTAgc2VsZWN0LW5vbmUgcG9pbnRlci1ldmVudHMtbm9uZSBmb250LWRpc3BsYXkgdGV4dC1bMTZ2d10gbGVhZGluZy1ub25lIHRleHQtc3Ryb2tlLXN1YnRsZSB6LTBcIlxuICAgICAgICAgIHN0eWxlPXt7IHRyYW5zZm9ybTogYHRyYW5zbGF0ZVkoJHsoc2Nyb2xsWVBvcyAtIDQzMDApICogMC4xNH1weClgIH19XG4gICAgICAgICAgYXJpYS1oaWRkZW49XCJ0cnVlXCJcbiAgICAgICAgPlxuICAgICAgICAgIFJFVklFV1NcbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIEdpYW50IHF1b3RhdGlvbiBtYXJrcyBpbiBiYWNrZ3JvdW5kICovfVxuICAgICAgICA8ZGl2XG4gICAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgcmlnaHQtNCB0b3AtNiBzZWxlY3Qtbm9uZSBwb2ludGVyLWV2ZW50cy1ub25lIGZvbnQtc2VyaWYgdGV4dC1bMTh2d10gbGVhZGluZy1ub25lIHRleHQtWyNDODEwMkVdIG9wYWNpdHktMTAgZm9udC1ib2xkIHotMFwiXG4gICAgICAgICAgYXJpYS1oaWRkZW49XCJ0cnVlXCJcbiAgICAgICAgPlxuICAgICAgICAgIOKAnFxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQteHMgc206dGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtYmxhY2svNjAgdHJhY2tpbmctd2lkZXIgdXBwZXJjYXNlIG1iLTMgcmVsYXRpdmUgei0xMFwiPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWyNDODEwMkVdIGZvbnQtYm9sZFwiPjA3PC9zcGFuPlxuICAgICAgICAgIDxzcGFuPi88L3NwYW4+XG4gICAgICAgICAgPHNwYW4+0J7RgtC30YvQstGLPC9zcGFuPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgc206aXRlbXMtZW5kIGp1c3RpZnktYmV0d2VlbiBnYXAtNiBtYi04IHJlbGF0aXZlIHotMTBcIj5cbiAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgPFJldmVhbE9uU2Nyb2xsIGFzPVwiaDJcIiBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBzbTp0ZXh0LTV4bCBmb250LWRpc3BsYXkgdGV4dC1ibGFjayBsZWFkaW5nLXRpZ2h0XCI+XG4gICAgICAgICAgICAgINCe0KLQl9Cr0JLQqyDQmtCb0JjQldCd0KLQntCSXG4gICAgICAgICAgICA8L1JldmVhbE9uU2Nyb2xsPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBtdC0zXCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtNHhsIGZvbnQtZGlzcGxheSB0ZXh0LVsjQzgxMDJFXSB0YWJ1bGFyLW51bXNcIj5cbiAgICAgICAgICAgICAgICA1LjBcbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHRleHQtWyNDODEwMkVdXCI+XG4gICAgICAgICAgICAgICAge1suLi5BcnJheSg1KV0ubWFwKChfLCBpKSA9PiAoXG4gICAgICAgICAgICAgICAgICA8U3RhciBrZXk9e2l9IGNsYXNzTmFtZT1cInctNSBoLTUgZmlsbC1jdXJyZW50XCIgLz5cbiAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHVwcGVyY2FzZSB0ZXh0LWJsYWNrLzYwXCI+XG4gICAgICAgICAgICAgICAg0LIgMtCT0JjQoVxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxhXG4gICAgICAgICAgICBocmVmPXtER0lTX1VSTH1cbiAgICAgICAgICAgIHRhcmdldD1cIl9ibGFua1wiXG4gICAgICAgICAgICByZWw9XCJub29wZW5lciBub3JlZmVycmVyXCJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTUgcHktMyBib3JkZXIgYm9yZGVyLWJsYWNrLzMwIGhvdmVyOmJvcmRlci1ibGFjayB0ZXh0LWJsYWNrIGZvbnQtc2VtaWJvbGQgdGV4dC14cyB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdHJhbnNpdGlvbi1jb2xvcnMgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0yIG1pbi1oLVs0OHB4XSBzZWxmLXN0YXJ0IHNtOnNlbGYtYXV0byBmb2N1cy12aXNpYmxlOm91dGxpbmUtMiBmb2N1cy12aXNpYmxlOm91dGxpbmUtWyNDODEwMkVdXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8c3Bhbj7QktGB0LUg0L7RgtC30YvQstGLINCyIDLQk9CY0KE8L3NwYW4+XG4gICAgICAgICAgICA8RXh0ZXJuYWxMaW5rIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgIDwvYT5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIEhvcml6b250YWwgcmliYm9uICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTYgb3ZlcmZsb3cteC1hdXRvIHBiLTYgc25hcC14IHNuYXAtbWFuZGF0b3J5IHNjcm9sbC1zbW9vdGggbm8tc2Nyb2xsYmFyIHNlbGVjdC1ub25lIHJlbGF0aXZlIHotMTBcIj5cbiAgICAgICAgICB7UkVWSUVXU19EQVRBLm1hcCgocmV2LCBpZHgpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHRpbHQgPSBpZHggJSAyID09PSAwID8gJ3JvdGF0ZS1bLTAuNmRlZ10nIDogJ3JvdGF0ZS1bMC42ZGVnXSc7XG4gICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAga2V5PXtpZHh9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgc25hcC1jZW50ZXIgc2hyaW5rLTAgdy1bMjkwcHhdIHNtOnctWzM2MHB4XSBwLTYgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1ibGFjay8xMCByb3VuZGVkLWxnIHNoYWRvdy1zbSBmbGV4IGZsZXgtY29sIGp1c3RpZnktYmV0d2VlbiByZWxhdGl2ZSBvdmVyZmxvdy1oaWRkZW4gdHJhbnNpdGlvbi10cmFuc2Zvcm0gZHVyYXRpb24tMzAwIGhvdmVyOnJvdGF0ZS0wIGhvdmVyOnNoYWRvdy1tZCAke3RpbHR9YH1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTAgaW5zZXQteC0wIGgtMSBiYXJiZXItcG9sZS1zdHJpcGVcIiAvPlxuXG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgdGV4dC1bI0M4MTAyRV0gbWItM1wiPlxuICAgICAgICAgICAgICAgICAgICB7Wy4uLkFycmF5KHJldi5yYXRpbmcpXS5tYXAoKF8sIGkpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICA8U3RhciBrZXk9e2l9IGNsYXNzTmFtZT1cInctNCBoLTQgZmlsbC1jdXJyZW50XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ibGFjay84NSBpdGFsaWMgbGVhZGluZy1yZWxheGVkXCI+XG4gICAgICAgICAgICAgICAgICAgIMKre3Jldi50ZXh0fcK7XG4gICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgcHQtNCBib3JkZXItdCBib3JkZXItYmxhY2svNSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gdGV4dC14cyB0ZXh0LWJsYWNrLzUwXCI+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtYmxhY2tcIj57cmV2Lm5hbWV9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vXCI+e3Jldi5kYXRlfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApO1xuICAgICAgICAgIH0pfVxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogSW5kaWNhdG9ycyAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiBtdC0yIHJlbGF0aXZlIHotMTBcIj5cbiAgICAgICAgICB7UkVWSUVXU19EQVRBLm1hcCgoXywgaSkgPT4gKFxuICAgICAgICAgICAgPGRpdiBrZXk9e2l9IGNsYXNzTmFtZT1cInctMiBoLTIgcm91bmRlZC1mdWxsIGJnLWJsYWNrLzIwXCIgLz5cbiAgICAgICAgICApKX1cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L3NlY3Rpb24+XG5cbiAgICAgIHsvKiBORVcgU0VDVElPTjogwqvQl9CQ0J/QmNCh0JDQotCs0KHQryDQmiDQodCf0JXQptCY0JDQm9CY0KHQotCjwrsgKEJldHdlZW4gUmV2aWV3cyBhbmQgQ29udGFjdHMpICovfVxuICAgICAgPHNlY3Rpb24gaWQ9XCJib29raW5nXCIgY2xhc3NOYW1lPVwicHktMTIgc206cHktMTYgcHgtNCBzbTpweC04IG1heC13LTd4bCBteC1hdXRvIHJlbGF0aXZlIG92ZXJmbG93LWhpZGRlblwiPlxuICAgICAgICB7LyogUGFyYWxsYXggb3V0bGluZSB3YXRlcm1hcmsgJ0JPT0snICovfVxuICAgICAgICA8ZGl2XG4gICAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgLXRvcC0xMCByaWdodC0xMCBzZWxlY3Qtbm9uZSBwb2ludGVyLWV2ZW50cy1ub25lIGZvbnQtZGlzcGxheSB0ZXh0LVsxOHZ3XSBsZWFkaW5nLW5vbmUgdGV4dC1zdHJva2Utc3VidGxlIHotMFwiXG4gICAgICAgICAgc3R5bGU9e3sgdHJhbnNmb3JtOiBgdHJhbnNsYXRlWSgkeyhzY3JvbGxZUG9zIC0gNTAwMCkgKiAwLjE1fXB4KWAgfX1cbiAgICAgICAgICBhcmlhLWhpZGRlbj1cInRydWVcIlxuICAgICAgICA+XG4gICAgICAgICAgQk9PS1xuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHotMTAgbWF4LXctNHhsIG14LWF1dG9cIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQteHMgc206dGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtYmxhY2svNjAgdHJhY2tpbmctd2lkZXIgdXBwZXJjYXNlIG1iLTNcIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWyNDODEwMkVdIGZvbnQtYm9sZFwiPjA4PC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4+Lzwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuPtCX0LDQv9C40YHRjDwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxSZXZlYWxPblNjcm9sbCBhcz1cImgyXCIgY2xhc3NOYW1lPVwidGV4dC0zeGwgc206dGV4dC01eGwgZm9udC1kaXNwbGF5IHRleHQtYmxhY2sgbWItMiBsZWFkaW5nLXRpZ2h0XCI+XG4gICAgICAgICAgICDQl9CQ0J/QmNCh0JDQotCs0KHQryDQmiDQodCf0JXQptCY0JDQm9CY0KHQotCjXG4gICAgICAgICAgPC9SZXZlYWxPblNjcm9sbD5cbiAgICAgICAgICA8UmV2ZWFsT25TY3JvbGwgYXM9XCJwXCIgZGVsYXk9ezEwMH0gY2xhc3NOYW1lPVwidGV4dC1ibGFjay83MCB0ZXh0LWJhc2Ugc206dGV4dC1sZyBtYi04XCI+XG4gICAgICAgICAgICDQktGL0LHQtdGA0LjRgtC1INC80LDRgdGC0LXRgNCwLCDQt9Cw0L/QuNGB0Ywg0L7RgtC60YDQvtC10YLRgdGPINCyIERpa2lkaVxuICAgICAgICAgIDwvUmV2ZWFsT25TY3JvbGw+XG5cbiAgICAgICAgICB7LyogMyBNYXN0ZXIgQm9va2luZyBSb3dzIChIZWlnaHQgfjk2cHgsIDY0cHggcm91bmQgcG9ydHJhaXQsIGFycm93LCBob3ZlciByZWQgZmlsbCkgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTMgc206c3BhY2UteS00XCI+XG4gICAgICAgICAgICB7LyogUm93IDE6IE1ha3N1ZCAqL31cbiAgICAgICAgICAgIDxhXG4gICAgICAgICAgICAgIGhyZWY9e0RJS0lESV9NQUtTVUR9XG4gICAgICAgICAgICAgIHRhcmdldD1cIl9ibGFua1wiXG4gICAgICAgICAgICAgIHJlbD1cIm5vb3BlbmVyIG5vcmVmZXJyZXJcIlxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJncm91cCByZWxhdGl2ZSBtaW4taC1bOTZweF0gcC00IHNtOnAtNSBiZy13aGl0ZSBib3JkZXIgYm9yZGVyLWJsYWNrLzE1IHJvdW5kZWQteGwgc2hhZG93LXNtIGhvdmVyOmJvcmRlci1bI0M4MTAyRV0gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC00IG92ZXJmbG93LWhpZGRlbiB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgYWN0aXZlOnNjYWxlLVswLjk5XSBmb2N1cy12aXNpYmxlOm91dGxpbmUtMiBmb2N1cy12aXNpYmxlOm91dGxpbmUtWyNDODEwMkVdXCJcbiAgICAgICAgICAgICAgYXJpYS1sYWJlbD1cItCX0LDQv9C40YHQsNGC0YzRgdGPINC6INCc0LDQutGB0YPQtNGDINCyIERpa2lkaVwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIHsvKiBSZWQgc2xpZGluZyBmaWxsICovfVxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC0wIGJnLVsjQzgxMDJFXSB0cmFuc2xhdGUteC1bLTEwMCVdIGdyb3VwLWhvdmVyOnRyYW5zbGF0ZS14LTAgdHJhbnNpdGlvbi10cmFuc2Zvcm0gZHVyYXRpb24tMzUwIGVhc2Utb3V0XCIgLz5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHotMTAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTQgc206Z2FwLTZcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTYgaC0xNiByb3VuZGVkLWZ1bGwgb3ZlcmZsb3ctaGlkZGVuIHNocmluay0wIGJvcmRlci0yIGJvcmRlci1ibGFjay8xMCBncm91cC1ob3Zlcjpib3JkZXItd2hpdGUgdHJhbnNpdGlvbi1jb2xvcnMgYmctYmxhY2svNVwiPlxuICAgICAgICAgICAgICAgICAgPGltZ1xuICAgICAgICAgICAgICAgICAgICBzcmM9XCIvYXNzZXRzL2Fpc3R1ZGlvL0lNR18xOTc3X2NlNmIwNDg0LmpwZWdcIlxuICAgICAgICAgICAgICAgICAgICBhbHQ9XCLQkdCw0YXRgNC40LTQuNC90L7QsiDQnNCw0LrRgdGD0LRcIlxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC1mdWxsIG9iamVjdC1jb3ZlciBvYmplY3QtdG9wXCJcbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LWRpc3BsYXkgdGV4dC1sZyBzbTp0ZXh0LXhsIHRleHQtYmxhY2sgZ3JvdXAtaG92ZXI6dGV4dC13aGl0ZSB0cmFuc2l0aW9uLWNvbG9yc1wiPlxuICAgICAgICAgICAgICAgICAgICDQkdCw0YXRgNC40LTQuNC90L7QsiDQnNCw0LrRgdGD0LRcbiAgICAgICAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIG10LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtWyMxMjMwNkJdIGdyb3VwLWhvdmVyOnRleHQtd2hpdGUvOTAgdHJhbnNpdGlvbi1jb2xvcnNcIj5cbiAgICAgICAgICAgICAgICAgICAgICBCUkFORC3QsdCw0YDQsdC10YBcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtYmxhY2svNTAgZ3JvdXAtaG92ZXI6dGV4dC13aGl0ZS83MCB0cmFuc2l0aW9uLWNvbG9yc1wiPlxuICAgICAgICAgICAgICAgICAgICAgIMK3IDEwINC70LXRgiDQvtC/0YvRgtCwXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHotMTAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJoaWRkZW4gc206aW5saW5lIHRleHQteHMgZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1ibGFjay83MCBncm91cC1ob3Zlcjp0ZXh0LXdoaXRlIHRyYW5zaXRpb24tY29sb3JzXCI+XG4gICAgICAgICAgICAgICAgICDQl9Cw0L/QuNGB0LDRgtGM0YHRj1xuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTAgaC0xMCByb3VuZGVkLWZ1bGwgYmctYmxhY2svNSBncm91cC1ob3ZlcjpiZy13aGl0ZSB0ZXh0LWJsYWNrIGdyb3VwLWhvdmVyOnRleHQtWyNDODEwMkVdIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMFwiPlxuICAgICAgICAgICAgICAgICAgPEFycm93VXBSaWdodCBjbGFzc05hbWU9XCJ3LTUgaC01IGdyb3VwLWhvdmVyOnRyYW5zbGF0ZS14LTAuNSBncm91cC1ob3ZlcjotdHJhbnNsYXRlLXktMC41IHRyYW5zaXRpb24tdHJhbnNmb3JtXCIgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2E+XG5cbiAgICAgICAgICAgIHsvKiBSb3cgMjogU2lyb3poaWRpbiAqL31cbiAgICAgICAgICAgIDxhXG4gICAgICAgICAgICAgIGhyZWY9e0RJS0lESV9TSVJPWkhJRElOfVxuICAgICAgICAgICAgICB0YXJnZXQ9XCJfYmxhbmtcIlxuICAgICAgICAgICAgICByZWw9XCJub29wZW5lciBub3JlZmVycmVyXCJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZ3JvdXAgcmVsYXRpdmUgbWluLWgtWzk2cHhdIHAtNCBzbTpwLTUgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1ibGFjay8xNSByb3VuZGVkLXhsIHNoYWRvdy1zbSBob3Zlcjpib3JkZXItWyNDODEwMkVdIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtNCBvdmVyZmxvdy1oaWRkZW4gdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIGFjdGl2ZTpzY2FsZS1bMC45OV0gZm9jdXMtdmlzaWJsZTpvdXRsaW5lLTIgZm9jdXMtdmlzaWJsZTpvdXRsaW5lLVsjQzgxMDJFXVwiXG4gICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCLQl9Cw0L/QuNGB0LDRgtGM0YHRjyDQuiDQodC40YDQvtC20LjQtNC40L3RgyDQsiBEaWtpZGlcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC0wIGJnLVsjQzgxMDJFXSB0cmFuc2xhdGUteC1bLTEwMCVdIGdyb3VwLWhvdmVyOnRyYW5zbGF0ZS14LTAgdHJhbnNpdGlvbi10cmFuc2Zvcm0gZHVyYXRpb24tMzUwIGVhc2Utb3V0XCIgLz5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHotMTAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTQgc206Z2FwLTZcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTYgaC0xNiByb3VuZGVkLWZ1bGwgb3ZlcmZsb3ctaGlkZGVuIHNocmluay0wIGJvcmRlci0yIGJvcmRlci1ibGFjay8xMCBncm91cC1ob3Zlcjpib3JkZXItd2hpdGUgdHJhbnNpdGlvbi1jb2xvcnMgYmctYmxhY2svNVwiPlxuICAgICAgICAgICAgICAgICAgPGltZ1xuICAgICAgICAgICAgICAgICAgICBzcmM9XCIvYXNzZXRzL2Fpc3R1ZGlvL0lNR183NjA1XzJkYzE1NjE1LmpwZWdcIlxuICAgICAgICAgICAgICAgICAgICBhbHQ9XCLQn9Cw0YLQuNC00LjQvdC+0LIg0KHQuNGA0L7QttC40LTQuNC9XCJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtZnVsbCBvYmplY3QtY292ZXIgb2JqZWN0LXRvcFwiXG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1kaXNwbGF5IHRleHQtbGcgc206dGV4dC14bCB0ZXh0LWJsYWNrIGdyb3VwLWhvdmVyOnRleHQtd2hpdGUgdHJhbnNpdGlvbi1jb2xvcnNcIj5cbiAgICAgICAgICAgICAgICAgICAg0J/QsNGC0LjQtNC40L3QvtCyINCh0LjRgNC+0LbQuNC00LjQvVxuICAgICAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgbXQtMVwiPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1bI0M4MTAyRV0gZ3JvdXAtaG92ZXI6dGV4dC13aGl0ZS85MCB0cmFuc2l0aW9uLWNvbG9yc1wiPlxuICAgICAgICAgICAgICAgICAgICAgINCR0LDRgNCx0LXRgFxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ibGFjay81MCBncm91cC1ob3Zlcjp0ZXh0LXdoaXRlLzcwIHRyYW5zaXRpb24tY29sb3JzXCI+XG4gICAgICAgICAgICAgICAgICAgICAgwrcg0KDQtdC50YLQuNC90LMgNS4wXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHotMTAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJoaWRkZW4gc206aW5saW5lIHRleHQteHMgZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1ibGFjay83MCBncm91cC1ob3Zlcjp0ZXh0LXdoaXRlIHRyYW5zaXRpb24tY29sb3JzXCI+XG4gICAgICAgICAgICAgICAgICDQl9Cw0L/QuNGB0LDRgtGM0YHRj1xuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTAgaC0xMCByb3VuZGVkLWZ1bGwgYmctYmxhY2svNSBncm91cC1ob3ZlcjpiZy13aGl0ZSB0ZXh0LWJsYWNrIGdyb3VwLWhvdmVyOnRleHQtWyNDODEwMkVdIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMFwiPlxuICAgICAgICAgICAgICAgICAgPEFycm93VXBSaWdodCBjbGFzc05hbWU9XCJ3LTUgaC01IGdyb3VwLWhvdmVyOnRyYW5zbGF0ZS14LTAuNSBncm91cC1ob3ZlcjotdHJhbnNsYXRlLXktMC41IHRyYW5zaXRpb24tdHJhbnNmb3JtXCIgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2E+XG5cbiAgICAgICAgICAgIHsvKiBSb3cgMzogWmhhbXNoaWQgKi99XG4gICAgICAgICAgICA8YVxuICAgICAgICAgICAgICBocmVmPXtESUtJRElfWkhBTVNISUR9XG4gICAgICAgICAgICAgIHRhcmdldD1cIl9ibGFua1wiXG4gICAgICAgICAgICAgIHJlbD1cIm5vb3BlbmVyIG5vcmVmZXJyZXJcIlxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJncm91cCByZWxhdGl2ZSBtaW4taC1bOTZweF0gcC00IHNtOnAtNSBiZy13aGl0ZSBib3JkZXIgYm9yZGVyLWJsYWNrLzE1IHJvdW5kZWQteGwgc2hhZG93LXNtIGhvdmVyOmJvcmRlci1bI0M4MTAyRV0gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC00IG92ZXJmbG93LWhpZGRlbiB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgYWN0aXZlOnNjYWxlLVswLjk5XSBmb2N1cy12aXNpYmxlOm91dGxpbmUtMiBmb2N1cy12aXNpYmxlOm91dGxpbmUtWyNDODEwMkVdXCJcbiAgICAgICAgICAgICAgYXJpYS1sYWJlbD1cItCX0LDQv9C40YHQsNGC0YzRgdGPINC6INCW0LDQvNGI0LjQtNGDINCyIERpa2lkaVwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LTAgYmctWyNDODEwMkVdIHRyYW5zbGF0ZS14LVstMTAwJV0gZ3JvdXAtaG92ZXI6dHJhbnNsYXRlLXgtMCB0cmFuc2l0aW9uLXRyYW5zZm9ybSBkdXJhdGlvbi0zNTAgZWFzZS1vdXRcIiAvPlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgei0xMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNCBzbTpnYXAtNlwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xNiBoLTE2IHJvdW5kZWQtZnVsbCBvdmVyZmxvdy1oaWRkZW4gc2hyaW5rLTAgYm9yZGVyLTIgYm9yZGVyLWJsYWNrLzEwIGdyb3VwLWhvdmVyOmJvcmRlci13aGl0ZSB0cmFuc2l0aW9uLWNvbG9ycyBiZy1ibGFjay81XCI+XG4gICAgICAgICAgICAgICAgICA8aW1nXG4gICAgICAgICAgICAgICAgICAgIHNyYz1cIi9hc3NldHMvYWlzdHVkaW8vSU1HXzc2MDRfNjNlMjY0YzguanBlZ1wiXG4gICAgICAgICAgICAgICAgICAgIGFsdD1cItCR0LDRhdGA0LjQtNC40L3QvtCyINCW0LDQvNGI0LjQtFwiXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLWZ1bGwgb2JqZWN0LWNvdmVyIG9iamVjdC10b3BcIlxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtZGlzcGxheSB0ZXh0LWxnIHNtOnRleHQteGwgdGV4dC1ibGFjayBncm91cC1ob3Zlcjp0ZXh0LXdoaXRlIHRyYW5zaXRpb24tY29sb3JzXCI+XG4gICAgICAgICAgICAgICAgICAgINCR0LDRhdGA0LjQtNC40L3QvtCyINCW0LDQvNGI0LjQtFxuICAgICAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgbXQtMVwiPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1ibGFjay83NSBncm91cC1ob3Zlcjp0ZXh0LXdoaXRlLzkwIHRyYW5zaXRpb24tY29sb3JzXCI+XG4gICAgICAgICAgICAgICAgICAgICAg0J3QsNGH0LjQvdCw0Y7RidC40Lkg0LHQsNGA0LHQtdGAXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWJsYWNrLzUwIGdyb3VwLWhvdmVyOnRleHQtd2hpdGUvNzAgdHJhbnNpdGlvbi1jb2xvcnNcIj5cbiAgICAgICAgICAgICAgICAgICAgICDCtyDQlNC+0YHRgtGD0L/QvdCw0Y8g0YHRgtC+0LjQvNC+0YHRgtGMXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHotMTAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJoaWRkZW4gc206aW5saW5lIHRleHQteHMgZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1ibGFjay83MCBncm91cC1ob3Zlcjp0ZXh0LXdoaXRlIHRyYW5zaXRpb24tY29sb3JzXCI+XG4gICAgICAgICAgICAgICAgICDQl9Cw0L/QuNGB0LDRgtGM0YHRj1xuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTAgaC0xMCByb3VuZGVkLWZ1bGwgYmctYmxhY2svNSBncm91cC1ob3ZlcjpiZy13aGl0ZSB0ZXh0LWJsYWNrIGdyb3VwLWhvdmVyOnRleHQtWyNDODEwMkVdIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMFwiPlxuICAgICAgICAgICAgICAgICAgPEFycm93VXBSaWdodCBjbGFzc05hbWU9XCJ3LTUgaC01IGdyb3VwLWhvdmVyOnRyYW5zbGF0ZS14LTAuNSBncm91cC1ob3ZlcjotdHJhbnNsYXRlLXktMC41IHRyYW5zaXRpb24tdHJhbnNmb3JtXCIgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2E+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogT3V0bGluZSBCdXR0b246IEdlbmVyYWwgQm9va2luZyAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTggdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICAgIDxhXG4gICAgICAgICAgICAgIGhyZWY9e0RJS0lESV9HRU5FUkFMfVxuICAgICAgICAgICAgICB0YXJnZXQ9XCJfYmxhbmtcIlxuICAgICAgICAgICAgICByZWw9XCJub29wZW5lciBub3JlZmVycmVyXCJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHNtOnctYXV0byBweC04IHB5LTQgYm9yZGVyLTIgYm9yZGVyLWJsYWNrLzIwIGhvdmVyOmJvcmRlci1ibGFjayB0ZXh0LWJsYWNrIGZvbnQtc2VtaWJvbGQgdGV4dC14cyBzbTp0ZXh0LXNtIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgaG92ZXI6YmctYmxhY2sgaG92ZXI6dGV4dC13aGl0ZSB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDAgbWluLWgtWzQ4cHhdIHJvdW5kZWQtbGcgZm9jdXMtdmlzaWJsZTpvdXRsaW5lLTIgZm9jdXMtdmlzaWJsZTpvdXRsaW5lLVsjQzgxMDJFXVwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxzcGFuPtCX0LDQv9C40YHQsNGC0YzRgdGPINCyINCx0LDRgNCx0LXRgNGI0L7QvyAo0LvRjtCx0L7QuSDQvNCw0YHRgtC10YApPC9zcGFuPlxuICAgICAgICAgICAgICA8QXJyb3dVcFJpZ2h0IGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAgPC9hPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvc2VjdGlvbj5cblxuICAgICAgey8qIDA5LiBGQVEgKNCn0JDQodCi0KvQlSDQktCe0J/QoNCe0KHQqykgKi99XG4gICAgICA8c2VjdGlvbiBpZD1cImZhcVwiIGNsYXNzTmFtZT1cInB5LTEyIHNtOnB5LTE2IHB4LTQgc206cHgtOCBtYXgtdy03eGwgbXgtYXV0byByZWxhdGl2ZSBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgey8qIFBhcmFsbGF4IG91dGxpbmUgd2F0ZXJtYXJrICdGQVEnICovfVxuICAgICAgICA8ZGl2XG4gICAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgLXRvcC04IGxlZnQtMS8yIC10cmFuc2xhdGUteC0xLzIgc2VsZWN0LW5vbmUgcG9pbnRlci1ldmVudHMtbm9uZSBmb250LWRpc3BsYXkgdGV4dC1bMjJ2d10gbGVhZGluZy1ub25lIHRleHQtc3Ryb2tlLXN1YnRsZSB6LTBcIlxuICAgICAgICAgIHN0eWxlPXt7IHRyYW5zZm9ybTogYHRyYW5zbGF0ZSgtNTAlLCAkeyhzY3JvbGxZUG9zIC0gNTQwMCkgKiAwLjE0fXB4KWAgfX1cbiAgICAgICAgICBhcmlhLWhpZGRlbj1cInRydWVcIlxuICAgICAgICA+XG4gICAgICAgICAgRkFRXG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgei0xMCBtYXgtdy00eGwgbXgtYXV0b1wiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC14cyBzbTp0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ibGFjay82MCB0cmFja2luZy13aWRlciB1cHBlcmNhc2UgbWItM1wiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bI0M4MTAyRV0gZm9udC1ib2xkXCI+MDk8L3NwYW4+XG4gICAgICAgICAgICA8c3Bhbj4vPC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4+0JLQvtC/0YDQvtGB0Ysg0Lgg0L7RgtCy0LXRgtGLPC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPFJldmVhbE9uU2Nyb2xsIGFzPVwiaDJcIiBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBzbTp0ZXh0LTV4bCBmb250LWRpc3BsYXkgdGV4dC1ibGFjayBtYi0zIGxlYWRpbmctdGlnaHRcIj5cbiAgICAgICAgICAgINCn0JDQodCi0KvQlSDQktCe0J/QoNCe0KHQq1xuICAgICAgICAgIDwvUmV2ZWFsT25TY3JvbGw+XG4gICAgICAgICAgPFJldmVhbE9uU2Nyb2xsIGFzPVwicFwiIGRlbGF5PXsxMDB9IGNsYXNzTmFtZT1cInRleHQtYmxhY2svNzAgdGV4dC1iYXNlIHNtOnRleHQtbGcgbWItOFwiPlxuICAgICAgICAgICAg0JLRgdGRLCDRh9GC0L4g0LLQsNC20L3QviDQt9C90LDRgtGMINC/0LXRgNC10LQg0LLQuNC30LjRgtC+0Lwg0LIg0LHQsNGA0LHQtdGA0YjQvtC/IMKr0JLQvdC1INCy0YDQtdC80LXQvdC4wrtcbiAgICAgICAgICA8L1JldmVhbE9uU2Nyb2xsPlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgICAgICAgIHtGQVFfREFUQS5tYXAoKGl0ZW0sIGlkeCkgPT4ge1xuICAgICAgICAgICAgICBjb25zdCBpc09wZW4gPSBvcGVuRmFxID09PSBpZHg7XG4gICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgPFJldmVhbE9uU2Nyb2xsIGtleT17aWR4fSBkZWxheT17aWR4ICogNjB9PlxuICAgICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy13aGl0ZSBib3JkZXIgcm91bmRlZC14bCBvdmVyZmxvdy1oaWRkZW4gdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMjAwICR7XG4gICAgICAgICAgICAgICAgICAgICAgaXNPcGVuID8gJ2JvcmRlci1ibGFjay8zMCBzaGFkb3ctbWQgcmluZy0xIHJpbmctYmxhY2svNScgOiAnYm9yZGVyLWJsYWNrLzE1IHNoYWRvdy1zbSBob3Zlcjpib3JkZXItYmxhY2svMzAnXG4gICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0T3BlbkZhcShpc09wZW4gPyBudWxsIDogaWR4KX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcC01IHNtOnAtNiB0ZXh0LWxlZnQgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC00IGN1cnNvci1wb2ludGVyIHNlbGVjdC1ub25lIGZvY3VzLXZpc2libGU6b3V0bGluZS0yIGZvY3VzLXZpc2libGU6b3V0bGluZS1bI0M4MTAyRV1cIlxuICAgICAgICAgICAgICAgICAgICAgIGFyaWEtZXhwYW5kZWQ9e2lzT3Blbn1cbiAgICAgICAgICAgICAgICAgICAgICBhcmlhLWNvbnRyb2xzPXtgZmFxLWFuc3dlci0ke2lkeH1gfVxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1kaXNwbGF5IHRleHQtYmFzZSBzbTp0ZXh0LWxnIHRleHQtYmxhY2sgZm9udC1ib2xkIHRyYWNraW5nLXRpZ2h0XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5xfVxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2B3LTkgaC05IHJvdW5kZWQtZnVsbCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBzaHJpbmstMCB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0yMDAgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaXNPcGVuID8gJ2JnLVsjQzgxMDJFXSB0ZXh0LXdoaXRlJyA6ICdiZy1ibGFjay81IHRleHQtYmxhY2svNzAnXG4gICAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICB7aXNPcGVuID8gPE1pbnVzIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPiA6IDxQbHVzIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPn1cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAgICAgIGlkPXtgZmFxLWFuc3dlci0ke2lkeH1gfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGdyaWQgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIGVhc2Utb3V0ICR7XG4gICAgICAgICAgICAgICAgICAgICAgICBpc09wZW4gPyAnZ3JpZC1yb3dzLVsxZnJdIG9wYWNpdHktMTAwIHBiLTUgc206cGItNiBweC01IHNtOnB4LTYnIDogJ2dyaWQtcm93cy1bMGZyXSBvcGFjaXR5LTAgcHgtNSBzbTpweC02J1xuICAgICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHQtMiBib3JkZXItdCBib3JkZXItYmxhY2svOCB0ZXh0LXNtIHNtOnRleHQtYmFzZSB0ZXh0LWJsYWNrLzgwIGxlYWRpbmctcmVsYXhlZCBmb250LW5vcm1hbFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5hfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9SZXZlYWxPblNjcm9sbD5cbiAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIH0pfVxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIFByb21wdCB1bmRlciBGQVEgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC04IHAtNSBiZy1ibGFjay80IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ibGFjay84IGZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgaXRlbXMtc3RhcnQgc206aXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtNFwiPlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1kaXNwbGF5IHRleHQtc20gc206dGV4dC1iYXNlIHRleHQtYmxhY2sgYmxvY2sgZm9udC1ib2xkXCI+XG4gICAgICAgICAgICAgICAg0J7RgdGC0LDQu9C40YHRjCDQstC+0L/RgNC+0YHRiyDQv9C+INC30LDQv9C40YHQuCDQuNC70Lgg0YPRgdC70YPQs9Cw0Lw/XG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBzbTp0ZXh0LXNtIHRleHQtYmxhY2svNjBcIj5cbiAgICAgICAgICAgICAgICDQn9C+0LfQstC+0L3QuNGC0LUg0L3QsNC8INC40LvQuCDQvdCw0L/QuNGI0LjRgtC1INCyIFRlbGVncmFtIOKAlCDQvtGC0LLQtdGC0LjQvCDQsiDRgtC10YfQtdC90LjQtSDQvdC10YHQutC+0LvRjNC60LjRhSDQvNC40L3Rg9GCLlxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxhXG4gICAgICAgICAgICAgIGhyZWY9e1BIT05FX0xJTkt9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJ0bi1iYXJiZXIgcHgtNSBweS0yLjUgYmctYmxhY2sgdGV4dC13aGl0ZSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdHJhY2tpbmctd2lkZXIgdXBwZXJjYXNlIHdoaXRlc3BhY2Utbm93cmFwIHNoYWRvdy1zbSBmb2N1cy12aXNpYmxlOm91dGxpbmUtMiBmb2N1cy12aXNpYmxlOm91dGxpbmUtWyNDODEwMkVdXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYnRuLWZpbGxcIiAvPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB6LTEwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICA8c3Bhbj57UEhPTkVfTlVNQkVSfTwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPC9hPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvc2VjdGlvbj5cblxuICAgICAgey8qIDEwLiDQmtCe0J3QotCQ0JrQotCrICjQndCQINCh0JjQndCV0Jwg0KTQntCd0JUgIzEyMzA2Qiwg0KLQldCa0KHQoiDQkdCV0JvQq9CZLCDQkNCa0KbQldCd0KIgI0ZGNUM2QykgKi99XG4gICAgICA8c2VjdGlvblxuICAgICAgICByZWY9e2NvbnRhY3RzUmVmfVxuICAgICAgICBpZD1cImNvbnRhY3RzXCJcbiAgICAgICAgY2xhc3NOYW1lPVwicHktMTIgc206cHktMTYgcHgtNCBzbTpweC04IGJnLVsjMTIzMDZCXSB0ZXh0LXdoaXRlIHJlbGF0aXZlXCJcbiAgICAgID5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXgtdy03eGwgbXgtYXV0b1wiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC14cyBzbTp0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC13aGl0ZS82MCB0cmFja2luZy13aWRlciB1cHBlcmNhc2UgbWItM1wiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bI0ZGNUM2Q10gZm9udC1ib2xkXCI+MTA8L3NwYW4+XG4gICAgICAgICAgICA8c3Bhbj4vPC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4+0JrQvtC90YLQsNC60YLRizwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxSZXZlYWxPblNjcm9sbCBhcz1cImgyXCIgY2xhc3NOYW1lPVwidGV4dC0zeGwgc206dGV4dC01eGwgZm9udC1kaXNwbGF5IHRleHQtd2hpdGUgbWItOCBsZWFkaW5nLXRpZ2h0XCI+XG4gICAgICAgICAgICDQmtCQ0Jog0J3QkNChINCd0JDQmdCi0JhcbiAgICAgICAgICA8L1JldmVhbE9uU2Nyb2xsPlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXgtdy0zeGwgc3BhY2UteS02XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNiBiZy13aGl0ZS81IGJvcmRlciBib3JkZXItd2hpdGUvMTAgcm91bmRlZC1sZyBzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgPE1hcFBpbiBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtWyNGRjVDNkNdIHNocmluay0wIG10LTFcIiAvPlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHVwcGVyY2FzZSB0ZXh0LXdoaXRlLzYwIGZvbnQtbW9ubyBibG9ja1wiPtCQ0LTRgNC10YE8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgICAgICAgICDQn9C10YDQvNGMLCDQmtC+0LzRgdC+0LzQvtC70YzRgdC60LjQuSDQv9GA0L7RgdC/0LXQutGCLCA4N1xuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXdoaXRlLzcwIG10LTFcIj5cbiAgICAgICAgICAgICAgICAgICAg0KHQstC10YDQtNC70L7QstGB0LrQuNC5INGA0LDQudC+0L0sINC/0LXRgNC10LrRgNGR0YHRgtC+0Log0YEg0YPQu9C40YbQtdC5INCa0L7QvNC40L3RgtC10YDQvdCwXG4gICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtMyBwdC00IGJvcmRlci10IGJvcmRlci13aGl0ZS8xMFwiPlxuICAgICAgICAgICAgICAgIDxDbG9jayBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtWyNGRjVDNkNdIHNocmluay0wIG10LTFcIiAvPlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHVwcGVyY2FzZSB0ZXh0LXdoaXRlLzYwIGZvbnQtbW9ubyBibG9ja1wiPlxuICAgICAgICAgICAgICAgICAgICDQk9GA0LDRhNC40Log0YDQsNCx0L7RgtGLXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC13aGl0ZS85MCBzcGFjZS15LTAuNSBtdC0xXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+0J/QveKAk9Cn0YI6IDEwOjAwIOKAkyAyMjowMDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PtCf0YI6IDEwOjAwIOKAkyAxMzowMCDQuCAxNTowMCDigJMgMjI6MDA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj7QodCx4oCT0JLRgTogMTA6MDAg4oCTIDIyOjAwPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC13aGl0ZS81MCBibG9jayBtdC0xIGl0YWxpY1wiPlxuICAgICAgICAgICAgICAgICAgICDQl9Cw0L/QuNGB0Ywg0L/QviDQv9GA0LXQtNCy0LDRgNC40YLQtdC70YzQvdC+0Lkg0LTQvtCz0L7QstC+0YDRkdC90L3QvtGB0YLQuFxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTMgcHQtNCBib3JkZXItdCBib3JkZXItd2hpdGUvMTBcIj5cbiAgICAgICAgICAgICAgICA8UGhvbmUgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LVsjRkY1QzZDXSBzaHJpbmstMCBtdC0xXCIgLz5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB1cHBlcmNhc2UgdGV4dC13aGl0ZS82MCBmb250LW1vbm8gYmxvY2tcIj7QotC10LvQtdGE0L7QvTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxhXG4gICAgICAgICAgICAgICAgICAgIGhyZWY9e1BIT05FX0xJTkt9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1kaXNwbGF5IHRleHQtd2hpdGUgaG92ZXI6dGV4dC1bI0ZGNUM2Q10gdHJhbnNpdGlvbi1jb2xvcnMgYmxvY2sgbXQtMC41IHRhYnVsYXItbnVtcyBmb2N1cy12aXNpYmxlOm91dGxpbmUtMiBmb2N1cy12aXNpYmxlOm91dGxpbmUtd2hpdGVcIlxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICB7UEhPTkVfTlVNQkVSfVxuICAgICAgICAgICAgICAgICAgPC9hPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogMyBPdXRsaW5lIEFjdGlvbiBCdXR0b25zICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0zIGdhcC0zXCI+XG4gICAgICAgICAgICAgIDxhXG4gICAgICAgICAgICAgICAgaHJlZj17REdJU19VUkx9XG4gICAgICAgICAgICAgICAgdGFyZ2V0PVwiX2JsYW5rXCJcbiAgICAgICAgICAgICAgICByZWw9XCJub29wZW5lciBub3JlZmVycmVyXCJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJncm91cCB3LWZ1bGwgcHktNCBweC00IGJvcmRlciBib3JkZXItd2hpdGUvMzAgaG92ZXI6Ymctd2hpdGUgaG92ZXI6dGV4dC1bIzEyMzA2Ql0gYWN0aXZlOmJnLXdoaXRlIGFjdGl2ZTp0ZXh0LVsjMTIzMDZCXSB0ZXh0LXdoaXRlIGZvbnQtc2VtaWJvbGQgdGV4dC14cyB0cmFja2luZy13aWRlciB1cHBlcmNhc2UgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMjAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIG1pbi1oLVs0OHB4XSB0ZXh0LWNlbnRlciBmb2N1cy12aXNpYmxlOm91dGxpbmUtMiBmb2N1cy12aXNpYmxlOm91dGxpbmUtd2hpdGVcIlxuICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCLQntGC0LrRgNGL0YLRjCDQutCw0YDRgtC+0YfQutGDINCyIDLQk9CY0KFcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPE5hdmlnYXRpb24gY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LVsjRkY1QzZDXSBncm91cC1ob3Zlcjp0ZXh0LVsjMTIzMDZCXSBncm91cC1ob3Zlcjp0cmFuc2xhdGUteC0xIHRyYW5zaXRpb24tYWxsXCIgLz5cbiAgICAgICAgICAgICAgICA8c3Bhbj7QntGC0LrRgNGL0YLRjCDQsiAy0JPQmNChPC9zcGFuPlxuICAgICAgICAgICAgICA8L2E+XG5cbiAgICAgICAgICAgICAgPGFcbiAgICAgICAgICAgICAgICBocmVmPXtgaHR0cHM6Ly8yZ2lzLnJ1L3JvdXRlU2VhcmNoL3JzVHlwZS9jYXIvdG8vNTYuMjU4Niw1Ny45OTQyYH1cbiAgICAgICAgICAgICAgICB0YXJnZXQ9XCJfYmxhbmtcIlxuICAgICAgICAgICAgICAgIHJlbD1cIm5vb3BlbmVyIG5vcmVmZXJyZXJcIlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImdyb3VwIHctZnVsbCBweS00IHB4LTQgYm9yZGVyIGJvcmRlci13aGl0ZS8zMCBob3ZlcjpiZy13aGl0ZSBob3Zlcjp0ZXh0LVsjMTIzMDZCXSBhY3RpdmU6Ymctd2hpdGUgYWN0aXZlOnRleHQtWyMxMjMwNkJdIHRleHQtd2hpdGUgZm9udC1zZW1pYm9sZCB0ZXh0LXhzIHRyYWNraW5nLXdpZGVyIHVwcGVyY2FzZSB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgbWluLWgtWzQ4cHhdIHRleHQtY2VudGVyIGZvY3VzLXZpc2libGU6b3V0bGluZS0yIGZvY3VzLXZpc2libGU6b3V0bGluZS13aGl0ZVwiXG4gICAgICAgICAgICAgICAgYXJpYS1sYWJlbD1cItCf0L7RgdGC0YDQvtC40YLRjCDQvNCw0YDRiNGA0YPRgiDQuiDQsdCw0YDQsdC10YDRiNC+0L/Rg1wiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8c3Bhbj7Qn9C+0YHRgtGA0L7QuNGC0Ywg0LzQsNGA0YjRgNGD0YI8L3NwYW4+XG4gICAgICAgICAgICAgICAgPEFycm93VXBSaWdodCBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtWyNGRjVDNkNdIGdyb3VwLWhvdmVyOnRleHQtWyMxMjMwNkJdIGdyb3VwLWhvdmVyOnRyYW5zbGF0ZS14LTEgdHJhbnNpdGlvbi1hbGxcIiAvPlxuICAgICAgICAgICAgICA8L2E+XG5cbiAgICAgICAgICAgICAgPGFcbiAgICAgICAgICAgICAgICBocmVmPXtURUxFR1JBTV9VUkx9XG4gICAgICAgICAgICAgICAgdGFyZ2V0PVwiX2JsYW5rXCJcbiAgICAgICAgICAgICAgICByZWw9XCJub29wZW5lciBub3JlZmVycmVyXCJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJncm91cCB3LWZ1bGwgcHktNCBweC00IGJvcmRlciBib3JkZXItd2hpdGUvMzAgaG92ZXI6Ymctd2hpdGUgaG92ZXI6dGV4dC1bIzEyMzA2Ql0gYWN0aXZlOmJnLXdoaXRlIGFjdGl2ZTp0ZXh0LVsjMTIzMDZCXSB0ZXh0LXdoaXRlIGZvbnQtc2VtaWJvbGQgdGV4dC14cyB0cmFja2luZy13aWRlciB1cHBlcmNhc2UgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMjAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIG1pbi1oLVs0OHB4XSB0ZXh0LWNlbnRlciBmb2N1cy12aXNpYmxlOm91dGxpbmUtMiBmb2N1cy12aXNpYmxlOm91dGxpbmUtd2hpdGVcIlxuICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCLQndCw0YggVGVsZWdyYW0t0LrQsNC90LDQu1wiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8U2VuZCBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtWyNGRjVDNkNdIGdyb3VwLWhvdmVyOnRleHQtWyMxMjMwNkJdIGdyb3VwLWhvdmVyOnRyYW5zbGF0ZS14LTEgdHJhbnNpdGlvbi1hbGxcIiAvPlxuICAgICAgICAgICAgICAgIDxzcGFuPtCd0LDRiCBUZWxlZ3JhbTwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9hPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9zZWN0aW9uPlxuXG4gICAgICB7LyogRlVMTC1CTEVFRCA4UFggUE9MRSBMSU5FIEFCT1ZFIEZPT1RFUiAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIGgtMiBiYXJiZXItcG9sZS1zdHJpcGVcIiBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxuXG4gICAgICB7LyogMTAuINCk0KPQotCV0KAgKNCi0IHQnNCd0J4t0KHQmNCd0JjQmSAjMDgxNjMzINChINCS0J7QlNCv0J3Qq9CcINCX0J3QkNCa0J7QnCkgKi99XG4gICAgICA8Zm9vdGVyIGNsYXNzTmFtZT1cInJlbGF0aXZlIGJnLVsjMDgxNjMzXSB0ZXh0LXdoaXRlIHB0LTggcGItMTYgcHgtNCBzbTpweC04IG92ZXJmbG93LWhpZGRlblwiPlxuICAgICAgICB7LyogSHVnZSBjb250b3VyIHdhdGVybWFyayBjdXQgYnkgYm90dG9tIGVkZ2UgKi99XG4gICAgICAgIDxkaXZcbiAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSAtYm90dG9tLTEwIGxlZnQtMS8yIC10cmFuc2xhdGUteC0xLzIgc2VsZWN0LW5vbmUgcG9pbnRlci1ldmVudHMtbm9uZSBmb250LWRpc3BsYXkgdGV4dC1bMTZ2d10gbGVhZGluZy1ub25lIHdoaXRlc3BhY2Utbm93cmFwIHRyYWNraW5nLXRpZ2h0ZXIgdGV4dC1zdHJva2UtYmx1ZSBvcGFjaXR5LTUwIHotMFwiXG4gICAgICAgICAgYXJpYS1oaWRkZW49XCJ0cnVlXCJcbiAgICAgICAgPlxuICAgICAgICAgINCS0J3QlSDQktCg0JXQnNCV0J3QmFxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1heC13LTd4bCBteC1hdXRvIHB0LTYgcmVsYXRpdmUgei0xMCBmbGV4IGZsZXgtY29sIG1kOmZsZXgtcm93IGl0ZW1zLXN0YXJ0IG1kOml0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLThcIj5cbiAgICAgICAgICB7LyogTG9nbyBzaWduIGFuZCB3b3JkICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICAgIDxMb2dvVkIgc2l6ZT17NDR9IGNsYXNzTmFtZT1cImJvcmRlci13aGl0ZS8zMFwiIC8+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWRpc3BsYXkgdGV4dC14bCB0ZXh0LXdoaXRlIGJsb2NrXCI+0JLQndCVINCS0KDQldCc0JXQndCYPC9zcGFuPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtd2hpdGUvNjBcIj5cbiAgICAgICAgICAgICAgICDQn9C10YDQvNGMLCDQmtC+0LzRgdC+0LzQvtC70YzRgdC60LjQuSDQv9GA0L7RgdC/0LXQutGCLCA4N1xuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBMaW5rcyAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBnYXAtNiB0ZXh0LXhzIHRleHQtd2hpdGUvNzBcIj5cbiAgICAgICAgICAgIDxhXG4gICAgICAgICAgICAgIGhyZWY9e1RFTEVHUkFNX1VSTH1cbiAgICAgICAgICAgICAgdGFyZ2V0PVwiX2JsYW5rXCJcbiAgICAgICAgICAgICAgcmVsPVwibm9vcGVuZXIgbm9yZWZlcnJlclwiXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImhvdmVyOnRleHQtd2hpdGUgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICBUZWxlZ3JhbVxuICAgICAgICAgICAgPC9hPlxuICAgICAgICAgICAgPGFcbiAgICAgICAgICAgICAgaHJlZj17REdJU19VUkx9XG4gICAgICAgICAgICAgIHRhcmdldD1cIl9ibGFua1wiXG4gICAgICAgICAgICAgIHJlbD1cIm5vb3BlbmVyIG5vcmVmZXJyZXJcIlxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJob3Zlcjp0ZXh0LXdoaXRlIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgMtCT0JjQoVxuICAgICAgICAgICAgPC9hPlxuICAgICAgICAgICAgPGEgaHJlZj17UEhPTkVfTElOS30gY2xhc3NOYW1lPVwiaG92ZXI6dGV4dC13aGl0ZSB0cmFuc2l0aW9uLWNvbG9ycyB0YWJ1bGFyLW51bXNcIj5cbiAgICAgICAgICAgICAge1BIT05FX05VTUJFUn1cbiAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICAgIDxhXG4gICAgICAgICAgICAgIGhyZWY9e0RJS0lESV9HRU5FUkFMfVxuICAgICAgICAgICAgICB0YXJnZXQ9XCJfYmxhbmtcIlxuICAgICAgICAgICAgICByZWw9XCJub29wZW5lciBub3JlZmVycmVyXCJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1bI0ZGNUM2Q10gZm9udC1zZW1pYm9sZCBob3Zlcjp1bmRlcmxpbmVcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICDQntC90LvQsNC50L0t0LfQsNC/0LjRgdGMINCyIERpa2lkaVxuICAgICAgICAgICAgPC9hPlxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRFeHBvcnRNb2RhbE9wZW4odHJ1ZSl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTMgcHktMS41IHJvdW5kZWQtbGcgYmctd2hpdGUvMTAgaG92ZXI6YmctWyNDODEwMkVdIHRleHQtd2hpdGUgdGV4dC14cyBmb250LXNlbWlib2xkIHRyYWNraW5nLXdpZGVyIHVwcGVyY2FzZSB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlciBib3JkZXIgYm9yZGVyLXdoaXRlLzE1XCJcbiAgICAgICAgICAgICAgYXJpYS1sYWJlbD1cItCt0LrRgdC/0L7RgNGCINC4INGB0LrQsNGH0LjQstCw0L3QuNC1INC/0YDQvtC10LrRgtCwINCyINCw0YDRhdC40LLQtVwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxEb3dubG9hZCBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICAgICAgICAgIDxzcGFuPtCh0LrQsNGH0LDRgtGMINC/0YDQvtC10LrRgiAoLlpJUCk8L3NwYW4+XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBDb3B5cmlnaHQgJiBTY3JvbGwgdG8gVG9wIGJ1dHRvbiAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00XCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXdoaXRlLzQwIGZvbnQtbW9ub1wiPlxuICAgICAgICAgICAgICDCqSB7bmV3IERhdGUoKS5nZXRGdWxsWWVhcigpfSDCq9CS0L3QtSDQstGA0LXQvNC10L3QuMK7XG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIG9uQ2xpY2s9e3Njcm9sbFRvVG9wfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTMgcm91bmRlZC1mdWxsIGJnLXdoaXRlLzEwIGhvdmVyOmJnLVsjQzgxMDJFXSB0ZXh0LXdoaXRlIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyIG1pbi1oLVs0NHB4XSBtaW4tdy1bNDRweF0gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZm9jdXMtdmlzaWJsZTpvdXRsaW5lLTIgZm9jdXMtdmlzaWJsZTpvdXRsaW5lLXdoaXRlXCJcbiAgICAgICAgICAgICAgYXJpYS1sYWJlbD1cItCd0LDQstC10YDRhSDRgdGC0YDQsNC90LjRhtGLXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPEFycm93VXAgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Zvb3Rlcj5cblxuICAgICAgey8qIE1PQklMRSBTVElDS1kgQk9PS0lORyBCVVRUT04gKi99XG4gICAgICB7c2hvd1N0aWNreUJvb2tpbmcgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGJvdHRvbS0zIGluc2V0LXgtNCB6LTUwIG1kOmhpZGRlbiBhbmltYXRlLWluIGZhZGUtaW4gc2xpZGUtaW4tZnJvbS1ib3R0b20gZHVyYXRpb24tMzAwIHBiLVtlbnYoc2FmZS1hcmVhLWluc2V0LWJvdHRvbSldXCI+XG4gICAgICAgICAgPGFcbiAgICAgICAgICAgIGhyZWY9e0RJS0lESV9HRU5FUkFMfVxuICAgICAgICAgICAgdGFyZ2V0PVwiX2JsYW5rXCJcbiAgICAgICAgICAgIHJlbD1cIm5vb3BlbmVyIG5vcmVmZXJyZXJcIlxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiYnRuLWJhcmJlciB3LWZ1bGwgaC0xNCBiZy1ibGFjayB0ZXh0LXdoaXRlIHRleHQtY2VudGVyIGZvbnQtZGlzcGxheSB0ZXh0LXNtIHRyYWNraW5nLXdpZGVzdCB1cHBlcmNhc2Ugc2hhZG93LVswXzhweF8zMHB4X3JnYigwLDAsMCwwLjM1KV0gcm91bmRlZC1sZ1wiXG4gICAgICAgICAgICBhcmlhLWxhYmVsPVwi0JfQsNC/0LjRgdCw0YLRjNGB0Y8g0L7QvdC70LDQudC9INC90LAg0YHRgtGA0LjQttC60YNcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJ0bi1maWxsXCIgLz5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInJlbGF0aXZlIHotMTAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgPHNwYW4+0JfQsNC/0LjRgdCw0YLRjNGB0Y8g0L7QvdC70LDQudC9PC9zcGFuPlxuICAgICAgICAgICAgICA8QXJyb3dVcFJpZ2h0IGNsYXNzTmFtZT1cInctNCBoLTQgYnRuLWFycm93XCIgLz5cbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICA8L2E+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgey8qIEFVRElPIFBMQVlFUiAoNDRweCBmbG9hdGluZyBidXR0b24gYXQgYm90dG9tLWxlZnQgYWJvdmUgbW9iaWxlIHN0aWNreSkgKi99XG4gICAgICA8QXVkaW9QbGF5ZXIgLz5cblxuICAgICAgey8qIExJR0hUQk9YIE1PREFMICovfVxuICAgICAgPEdhbGxlcnlNb2RhbFxuICAgICAgICBpbWFnZXM9e2dhbGxlcnlJbWFnZXN9XG4gICAgICAgIGluaXRpYWxJbmRleD17Z2FsbGVyeUluZGV4fVxuICAgICAgICBpc09wZW49e2dhbGxlcnlPcGVufVxuICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRHYWxsZXJ5T3BlbihmYWxzZSl9XG4gICAgICAvPlxuXG4gICAgICB7LyogRVhQT1JUIC8gRE9XTkxPQUQgTU9EQUwgKi99XG4gICAgICA8RXhwb3J0TW9kYWxcbiAgICAgICAgaXNPcGVuPXtleHBvcnRNb2RhbE9wZW59XG4gICAgICAgIG9uQ2xvc2U9eygpID0+IHNldEV4cG9ydE1vZGFsT3BlbihmYWxzZSl9XG4gICAgICAvPlxuICAgIDwvZGl2PlxuICApO1xufVxuIl19